package com.sharemarket.shailendra.finvasia;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.CompletionStage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.OrderDetailNew;
import com.sharemarket.shailendra.RepositoryClass;
import com.sharemarket.shailendra.StockMarketUtil;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;

import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FinvasiaAutoTrader implements Runnable {
    private static final Logger logger = LogManager.getLogger(FinvasiaAutoTrader.class);
	public static String trackingscrip = "";
	
	@Override
	public void run() {
		try {
			logger.info("FinvasiaAutoTrader**---------------->");
			long i=0;
			long telegramMsgId = 0l;
			//String lasttimesktresp = null;

			while(i<999999999) {
				Calendar cal = Calendar.getInstance();
				if(CommonUtils.isTradingAllowedToday(cal)) {
					boolean canrun = false;
					int hr = cal.get(Calendar.HOUR_OF_DAY);
					if(hr < 9 || hr > 15) {
						i = 0;
					}else {
						if(hr == 15) {
							int mn = cal.get(Calendar.MINUTE);
							if(mn < 8) {
								canrun = true;
								i++;
							}
						}else {
							canrun =true;
							i++;
						}
					}
					try {
						if(canrun) {
			        		String commandfromtelegram = TelegramUtil.getLatestTelegramMsgFromChanel("bot5891414670:AAGmQKmDeNd_jqdEeaAyZBi8B4onJh_R26I");
			        		if(commandfromtelegram != null) {
			        			int xi = commandfromtelegram.indexOf("@@##@@");
			        			long telegramMsgIdcur = Long.valueOf(commandfromtelegram.substring(0, xi));
				        		//System.out.println(telegramMsgId+"="+telegramMsgIdcur+"%%%%%%=="+commandfromtelegram);
			        			if(telegramMsgIdcur > telegramMsgId) {
			        				telegramMsgId = telegramMsgIdcur;
				        			commandfromtelegram = commandfromtelegram.substring(xi+6);
				        			 if(commandfromtelegram.startsWith("status:") || commandfromtelegram.startsWith("Status:")) {
				        				 TelegramUtil.sendTelegramMsgToChanel("AutoTrader is live!!!Tracking%0A"+trackingscrip+"Pls place order in format:%0AStartWebSocket:%0AScrip:NIFTY23MAR23C18200%0AWaittime:2min%0ABuyPrice:29.8%0ATotalQty:150%0ATrailQty:50%0AStoploss:28%0ATrailUpBy:1.6%0ATrailUpBysmall:1%0Aapproach:1%0APrcentHike:0.02", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
					        		}else if(commandfromtelegram.startsWith("sell:") || commandfromtelegram.startsWith("Sell:")) {
				        				try {
				        					String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
				        					for (String orddata : oderDetailArrfromtelegram) {
				        						int inx = orddata.indexOf(':');
				        						String ky = orddata.substring(0, inx);
				        						if("Scrip".equalsIgnoreCase(ky)) {
				        							orddata = orddata.substring(inx+1).trim();
				        							int qty = StockMarketUtil.loadPositionBook(orddata);
				    		                		if(qty>0) {
					    		                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
					    		                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+orddata+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
					    		                        Request postRequest4sale = new Request.Builder()
					    		                                .url(RepositoryClass.placeOrder)
					    		                                .method("POST", body4sale)
					    		                                .addHeader("Content-Type", "application/json").build();
					    		                        App.client.newCall(postRequest4sale).execute();
					    		                        TelegramUtil.sendTelegramMsgToChanel("Sale Order Placed now as per ur request for:"+orddata+",qty="+qty, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				    		                		}else {
				    		                			TelegramUtil.sendTelegramMsgToChanel("Sorry!!!Sale Order NOT Placed as per ur request for:"+orddata+",qty="+qty, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				    		                		}
				    		                		trackingscrip = "";
				    		                		break;
				        						}
											}
				        				}catch(Exception px) {
				        					
				        				}
				        			}else if(commandfromtelegram.startsWith("Stop:") || commandfromtelegram.startsWith("stop:") || commandfromtelegram.startsWith("Stop :") || commandfromtelegram.startsWith("stop :") || commandfromtelegram.startsWith("StopWebSocket:")) {
				        				trackingscrip = "";
				        				disConnectWebSocket();
				        				TelegramUtil.sendTelegramMsgToChanel("Websocket closed now.", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				        			}else if(commandfromtelegram.startsWith("StartWebSocket:")) {
				        				TelegramUtil.sendTelegramMsgToChanel("Order picked for processing now.", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				        				String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
				        				String cd = null;
				        				int waittime = 2;
				        				Double buyprc = 0.0;
				        				Double stopls = 10.0;
				        				Double trailupby = 1000.0;
				        				Double trailupbysmall = 1000.0;
				        				Double percentHike = 0.022;
				        				Integer totqty = 0;
				        				Integer trailqty = 0;
				        				Integer approach = 1;
			        					for (String orddata : oderDetailArrfromtelegram) {
			        						int inx = orddata.indexOf(':');
			        						if(inx > -1) {
				        						String ky = orddata.substring(0, inx);
				        						if("Scrip".equalsIgnoreCase(ky)) {
				        							cd = orddata.substring(inx+1);
				        							cd = cd.trim();
				        						}else if("Waittime".equalsIgnoreCase(ky)) {
				        							waittime = Integer.valueOf(orddata.substring(inx+1, inx+2).trim());
				        						}else if("BuyPrice".equalsIgnoreCase(ky)) {
				        							buyprc = Double.valueOf(orddata.substring(inx+1).trim());
				        						}else if("Stoploss".equalsIgnoreCase(ky)) {
				        							stopls = Double.valueOf(orddata.substring(inx+1).trim());
				        						}else if("TrailUpBy".equalsIgnoreCase(ky)) {
				        							trailupby = Double.valueOf(orddata.substring(inx+1).trim());
				        						}else if("TrailUpBysmall".equalsIgnoreCase(ky)) {
				        							try {
				        								trailupbysmall = Double.valueOf(orddata.substring(inx+1).trim());
				        							}catch(Exception xp) {trailupbysmall = trailupby;}
				        						}else if("TotalQty".equalsIgnoreCase(ky)) {
				        							totqty = Integer.valueOf(orddata.substring(inx+1).trim());
				        						}else if("TrailQty".equalsIgnoreCase(ky)) {
				        							try {
				        								trailqty = Integer.valueOf(orddata.substring(inx+1).trim());
				        							}catch(Exception x) {trailqty = totqty;}
				        						}else if("approach".equalsIgnoreCase(ky)) {
				        							try {
				        								approach = Integer.valueOf(orddata.substring(inx+1).trim());
				        							}catch(Exception x) {approach = 1;}
				        						}else if("PrcentHike".equalsIgnoreCase(ky)) {
				        							try {
				        								percentHike = Double.valueOf(orddata.substring(inx+1).trim());
				        							}catch(Exception xp) {percentHike = 0.025;}
				        						}
			        						}
										}
			        					//validate all input and then proceed
			        					if(cd == null || cd.length() ==0 || waittime<1) {// || (totqty%25!=0) || (buyprc<stopls) || ((buyprc-stopls)<trailupby)) {
			        						trackingscrip = "";
			        						TelegramUtil.sendTelegramMsgToChanel("Order Placed can not placed as either cd is null or cd.length is 0 or waittime ls thn 1 or totqty not multiple of 25,50 or buyprc ls thn stopls or ((buyprc-stopls) less thn trailupby)", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			        					}else {
			        						placeOrder(cd, totqty, buyprc, stopls, trailupby, trailupbysmall, trailqty, waittime, null, false, percentHike, approach);
			        					}
				        			}
			        			}
			        		}
						}
					}catch(Exception px) {
						trackingscrip = "";
						logger.error("autotrader---", px);
					}
					try {Thread.sleep(10000);}catch(Exception ign) {}
				}else {
					i = 0;
				}
			}
		}catch(Exception xp) {
			trackingscrip = "";
			logger.error("autotrad----", xp);
		}
	}
	
	public void placeOrder(String cd, int totqty, double buyprc, double stopls, double trailupby, double trailupbysmall, int trailqty, int waittime, String scriptkn, boolean fakeorder, double saleprcnthikedefault, Integer approach) throws Exception {
		Integer nooforder = 15;
		int noOfLotValue = 0;
		int qtyIn1Lot = 0;
		if(trailupbysmall > trailupby || trailupbysmall < 0.25)
			trailupbysmall = trailupby;
		if(trailqty < 0)
			trailqty = totqty;
		if(cd.toUpperCase().startsWith("NIFTY")) {
			qtyIn1Lot = 50;
			noOfLotValue = totqty/qtyIn1Lot;
		}else if(cd.toUpperCase().startsWith("BANKNIFTY")) {
			qtyIn1Lot = 25;
			noOfLotValue = totqty/qtyIn1Lot;
		}else {
			qtyIn1Lot = totqty;
			noOfLotValue = totqty/qtyIn1Lot;
		}
		OrderDetailNew[] localOrderArr = new OrderDetailNew[15];
		for (int x=0; x<15; x++) {
    		localOrderArr[x]  = null;
		}
		if(noOfLotValue == 0)
			noOfLotValue=1;
		nooforder=noOfLotValue;
		int noOfLotInEachOrder = noOfLotValue/nooforder;
		Double prcMinus = (buyprc-stopls)/nooforder;
		Double stoplossforpositionload = 0.0;
        for(int xx=nooforder; xx > 0; xx--) {
            double buyPrcCurrent = buyprc - (prcMinus * (xx-1));
            if(xx == nooforder)
            	stoplossforpositionload = buyPrcCurrent-0.1;
            int quantity = noOfLotInEachOrder * qtyIn1Lot;
            if(xx > (nooforder-3))
            	quantity = 2 * noOfLotInEachOrder * qtyIn1Lot;
            //System.out.println((nooforder-xx)+",quantity="+quantity+",buyPrcCurrent="+buyPrcCurrent+",stopls=*"+stopls+",scodetkn:"+cd);
            OrderDetailNew ord = new OrderDetailNew(buyPrcCurrent, stopls+0.25, quantity);
            localOrderArr[nooforder-xx]  = ord;
        }
        TelegramUtil.sendTelegramMsgToChanel("Stoplossdetail:%0A"+cd+":"+stopls+":"+trailupby+":"+(buyprc+2.8)+"="+waittime, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
        if(approach == null || approach < 2) {
        	connectToWebSocketDefaultApproach(cd, totqty, trailqty, qtyIn1Lot, stopls, stoplossforpositionload, buyprc, trailupby, trailupbysmall, localOrderArr, nooforder, waittime, scriptkn, fakeorder, saleprcnthikedefault);
        }else {
        	connectToWebSocketTwo(cd, totqty, trailqty, qtyIn1Lot, stopls, stoplossforpositionload, buyprc, trailupby, trailupbysmall, localOrderArr, nooforder, waittime, scriptkn, fakeorder, saleprcnthikedefault);
        }
	}
	
    WebSocket ws = null;
    public void connectToWebSocketDefaultApproach(String scripnm, int totqty, int trailqty, int qtyIn1Lot, double stopls, double stoplossforpositionload, double buyprice, double trailupby, double trailupbysmall, OrderDetailNew[] localOrderArr, int nooforder, int waittime, String scriptkn, boolean fakeorder, double saleprcnthikedefault) {
    	try {
    		disConnectWebSocket();
    		String wsurl = "wss://api.shoonya.com/NorenWSTP/";
    		ws = HttpClient.newHttpClient().newWebSocketBuilder().buildAsync(URI.create(wsurl), new WebSocketClientAutoTradeDefaultApproach(scripnm, totqty, trailqty, qtyIn1Lot, stopls, stoplossforpositionload, buyprice, trailupby, trailupbysmall, localOrderArr, nooforder, waittime, scriptkn, fakeorder, saleprcnthikedefault))
                    .join();
    	}catch(Exception xp) {
    		trackingscrip = "";
    		logger.error("Error in socket", xp);
    	}
    }
    //String lasttimewssocketresprecievedat = null;
    public void connectToWebSocketTwo(String scripnm, int totqty, int trailqty, int qtyIn1Lot, double stopls, double stoplossforpositionload, double buyprice, double trailupby, double trailupbysmall, OrderDetailNew[] localOrderArr, int nooforder, int waittime, String scriptkn, boolean fakeorder, double saleprcnthikedefault) {
    	try {
    		disConnectWebSocket();
    		String wsurl = "wss://api.shoonya.com/NorenWSTP/";
    		ws = HttpClient.newHttpClient().newWebSocketBuilder().buildAsync(URI.create(wsurl), new WebSocketClientAutoTradeApproachTwo(scripnm, totqty, trailqty, qtyIn1Lot, stopls, stoplossforpositionload, buyprice, trailupby, trailupbysmall, localOrderArr, nooforder, waittime, scriptkn, fakeorder, saleprcnthikedefault))
                    .join();
    	}catch(Exception xp) {
    		trackingscrip = "";
    		logger.error("Error in socket", xp);
    	}
    }
    
    public void connectToWebSocketAgain() {
    	logger.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
    }
    
    public void disConnectWebSocket() {
    	try {
    		ws.sendClose(WebSocket.NORMAL_CLOSURE, "ok");
    	}catch(Exception xp) {
    		logger.error(xp);
    	}
    	try {
    		ws.abort();
    	}catch(Exception xp) {
    		logger.error(xp);
    	}
    	ws = null;
    }
    
	private static Object lockobj = new Object();
	
    private class WebSocketClientAutoTradeDefaultApproach implements WebSocket.Listener {
    	String scrip;
    	String scriptoken = "";
    	int totqty;
    	int totqty4waittime;
    	int trailqty;
    	int qtyIn1Lot;
    	double stopls;
    	int totqtyorig;
    	double buyprc;
    	double buyprcorig;
    	double trailupby;
    	double trailupbysmall;
    	OrderDetailNew[] localOrderArr;
    	int nooforder;
    	int waittime = -1;
    	Integer placeOrderAtCurBuyPrc = 1;
    	long orderpicktime = 0l;
    	boolean fakeorder = false;
    	double saleprcnthikedefault = 0.025;
    	double[] saleprcdefault = new double[] {1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0,1000.0};
    	List<String> saleOrderIdArr = null;
        public WebSocketClientAutoTradeDefaultApproach(String scripnm, int totqty, int trailqty, int qtyIn1Lot, double stopls, double stoplossforpositionload, double buyprice, double trailupby, double trailupbysmall, OrderDetailNew[] localOrderArr, int nooforder, int waittime, String scriptkn, boolean fakeorder, double saleprcnthikedefault) {
        	this.scrip = scripnm;
        	this.totqty = totqty;
        	this.trailqty = trailqty;
        	this.qtyIn1Lot = qtyIn1Lot;
        	this.stopls = stopls;
        	this.totqtyorig = totqty;
        	this.totqty4waittime = totqty;
        	this.buyprcorig = buyprice;
        	this.buyprc = buyprice;
        	this.trailupby = trailupby;
        	this.trailupbysmall = trailupbysmall;
        	this.localOrderArr = localOrderArr;
        	this.nooforder = nooforder;
        	this.waittime = waittime* 60 * 1000;
        	this.scriptoken = scriptkn;
        	this.fakeorder = fakeorder;
        	this.saleprcnthikedefault = saleprcnthikedefault;
        	saleOrderIdArr = new ArrayList<String>();
        }
    	@Override
    	public void onOpen(WebSocket webSocket) {
    	    WebSocket.Listener.super.onOpen(webSocket);
    	    webSocket.sendText("{\"t\":\"c\",\"uid\":\"FA66519\",\"actid\":\"FA66519\",\"source\":\"API\",\"susertoken\":\""+App.loginToken+"\"}", true);
    	}
    	
    	int count = 0;
    	@Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            try {
            	String rsp = data.toString();
                //System.out.println(":Auto onText received=" + data);
	            if(rsp.contains("\"t\": \"ck\",")) {
	            	placeOrderAtCurBuyPrc = 1;
	            	orderpicktime = System.currentTimeMillis();
	            	boolean retry = false;
	            	if(this.scriptoken == null) {
		            	try {
		            		this.scriptoken = FinvasiaUtil.getFinvasiaScripToken(scrip.toUpperCase(), "NFO");
		            		if(this.scriptoken == null)
		            			retry = true;
		            	}catch(Exception p) {
		            		retry = true;
		            	}
		            	if(retry == true)
		            		this.scriptoken = FinvasiaUtil.getFinvasiaScripToken(scrip.toUpperCase(), "NFO");
	            	}
	            	ws.sendText("{\"t\":\"t\",\"k\":\"NFO|"+this.scriptoken+"\"}", true);
	            	TelegramUtil.sendTelegramMsgToChanelAsync("approach=1.WebSocket started now for:"+scrip+",tkn="+this.scriptoken+",qty:"+this.totqty, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
	            }else if(rsp.contains("\"t\":\"tk\",") || rsp.contains("\"t\":\"tf\",")){
	                JSONObject json = new JSONObject(rsp);
	                String tkn = json.getString("tk");
	                String ltp = "";
	                try {
	                	ltp = json.getString("lp");
	                }catch(Exception x) {
	                	try {
	                		ltp = json.getString("bp1");
	                	}catch(Exception xx) {
	                		try {
	                			ltp = json.getString("sp1");
	                		}catch(Exception xi) {
	                			
	                		}
	                	}
	                }
	                if(ltp != null && ltp.trim().length()>0) {
	                	Double curval = Double.valueOf(ltp);
	                	if(this.scriptoken.equals(tkn)) {
	                		//place stoploss triggered order
		                	if(curval <= this.stopls && this.totqtyorig > 0) {
		                		StockMarketUtil.cancelAllOrder(saleOrderIdArr);
		                		int qty = StockMarketUtil.loadPositionBook(this.scrip);
		                		if(qty > -1)
		                			this.totqty = qty;
		                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
		                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+this.totqty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
		                        Request postRequest4sale = new Request.Builder()
		                                .url(RepositoryClass.placeOrder)
		                                .method("POST", body4sale)
		                                .addHeader("Content-Type", "application/json").build();
		                        App.client.newCall(postRequest4sale).execute();
		                        
		                		for(int i=0; i<15; i++) {
		                			this.localOrderArr[i] = null;
		                		}
		                        this.totqtyorig = 0;
		                        this.placeOrderAtCurBuyPrc = 0;
		                        this.totqty = 0;
		                        TelegramUtil.sendTelegramMsgToChanelAsync("StplsHit.Sale Order Placed now for:"+scrip+",qty="+this.totqty+"[q="+qty+"],p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
		                	}
		                	
		                	//checkwait time place sell order
            				for(int z=0; z<this.saleprcdefault.length;z++) {
                				if(curval > this.saleprcdefault[z]) {
	                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
	    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
	    	                        Request postRequest4sale = new Request.Builder()
	    	                                .url(RepositoryClass.placeOrder)
	    	                                .method("POST", body4sale)
	    	                                .addHeader("Content-Type", "application/json").build();
	    	                        Response response = App.client.newCall(postRequest4sale).execute();
	    	                        this.saleprcdefault[z] = 1000.0;
	    	                        this.totqty4waittime = this.totqty4waittime - qtyIn1Lot;
	    	                        getOrderNumber(response);
	    	                        TelegramUtil.sendTelegramMsgToChanelAsync("--Partial Sale Order Placed now for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
                				}
            				}
		                	
		                	if(this.placeOrderAtCurBuyPrc > 0) {
			                	synchronized(lockobj) {
				                	//check and place buyorder
				                	if(this.placeOrderAtCurBuyPrc > 0) {
				                		this.placeOrderAtCurBuyPrc = (StockMarketUtil.placeBuyOrderForLocalOrders(curval, this.scrip, App.loginToken, this.localOrderArr, this.nooforder, fakeorder, saleprcdefault, saleprcnthikedefault));
				                		if(this.placeOrderAtCurBuyPrc == 0) {
				                			StockMarketUtil.cancelAllOrder(saleOrderIdArr);
				                		}/*else if(this.placeOrderAtCurBuyPrc == 2) {
					                		System.out.println(curval+"---->");
					                		for(int z=0; z<this.saleprcdefault.length;z++) {
					                			System.out.print(this.saleprcdefault[z]+"=");
					                		}
					                		System.out.println();
				                		}*/
				                	}
			                	}
		                	}
			                	
			                	//checkwait time and cancel rest order
			                	if(this.waittime > -1) {
			                		if((System.currentTimeMillis() - orderpicktime) > this.waittime) {
				                		StockMarketUtil.cancelAllOrder(StockMarketUtil.getorderbookOrderNumber("B", this.scriptoken));
				                		int qty = StockMarketUtil.loadPositionBook(this.scrip);
				                		if(qty == totqtyorig) {
				                			//this.buyprc = (this.stopls + this.buyprc) / 2;
				                		}else {
				                			if(qty > -1) {
					                			//this.stopls = curval - trailupby;
					                			this.totqty = qty;
				                			}
				                		}
				                		this.waittime = -2;
				                		for(int i=0; i<this.nooforder; i++) {
				                			this.localOrderArr[i] = null;
				                		}
				                		TelegramUtil.sendTelegramMsgToChanelAsync("WaitTime over now for:"+scrip+",qty="+this.totqty+"[q="+qty+"],stopls:"+this.stopls+",buyat:"+this.buyprc, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				                		//load cancel orders//load position
			                		}else {
			                			if(curval > (this.buyprc+trailupby) && this.totqty4waittime > 0) {
			                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
			    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
			    	                        Request postRequest4sale = new Request.Builder()
			    	                                .url(RepositoryClass.placeOrder)
			    	                                .method("POST", body4sale)
			    	                                .addHeader("Content-Type", "application/json").build();
			    	                        Response response = App.client.newCall(postRequest4sale).execute();
			    	                        this.totqty4waittime = this.totqty4waittime - qtyIn1Lot;
			    	                        getOrderNumber(response);
			    	                        TelegramUtil.sendTelegramMsgToChanelAsync("Waittime.Partial Sale Order Placed now for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			                			}
			                		}
			                	}
			                	if(this.waittime == -2 && this.totqty > 0) {
			                		Double tmp = curval - trailupby;
			                        if(tmp > this.stopls) {
			                        	this.stopls = tmp;
			                        	//System.out.println(this.stopls +"<-->"+this.buyprc);
			                        }
			                        if(curval >= this.buyprcorig) {
			                        	trailupby = trailupbysmall;
			                        	this.buyprcorig = 10000.0;
			                        	this.buyprc = curval + trailupby;
			                        	checkandplacepartialsellorder(this.totqty, this.trailqty, this.qtyIn1Lot, "BuyPrc Reached.", curval);
			                        	//TelegramUtil.sendTelegramMsgToChanelAsync("BuyPrc Reached for Trailing prc for:"+scrip+",qty="+this.totqty+",stopls:"+this.stopls+",trailby:"+trailupby+",t:"+this.buyprc, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			                        }else if(curval >= this.buyprc) {
			                        	checkandplacepartialsellorder(this.totqty, this.trailqty, this.qtyIn1Lot, "", curval);
			                        	trailupby = trailupby - (curval*.008);
			                        	if(trailupby < 0.60) {
			                        		trailupby = 0.60;
			                        	}
			                        	this.buyprc = curval + trailupby;
			                        	int qty = StockMarketUtil.loadPositionBook(this.scrip);
			        	        		if(qty > -1) {
			        	        			this.totqty = qty;
			        	        		}
			        	        		TelegramUtil.sendTelegramMsgToChanelAsync("Trailing prc for:"+scrip+",qty="+this.totqty+",stopls:"+this.stopls+",trailby:"+trailupby+",t:"+this.buyprc, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			                        }
			                	}
	                	}
	                }
	            }
            }catch(Exception xp) {
            	logger.error("Some issue---", xp);
            }
            try {
	        	if(count ==0) { //if(curval <= stoplossforpositionload && this.totqty > 0) {
	        		int qty = StockMarketUtil.loadPositionBook(this.scrip);
	        		if(qty > -1) {
        				this.totqty = qty;
        				this.totqty4waittime = qty;
	        		}
	        	}
	        	count++;
	        	if(count > 30) {
	        		count = 0;
	        	}
            }catch(Exception xp) {
            	logger.error("position issue--", xp);
            }
            
            if(this.totqtyorig == 0) {
            	trackingscrip = "";
            	TelegramUtil.sendTelegramMsgToChanel("Stop:", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
            	TelegramUtil.sendTelegramMsgToChanel("Remove:%0A"+scrip, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
            	if(this.scriptoken != null)
            		ws.sendText("{\"t\":\"u\",\"k\":\""+this.scriptoken+"\"}", true);
            }else {
            	webSocket.request(1);
            }
            return null;
        }
    	
    	public void checkandplacepartialsellorder(int totqty, int trailqty, int qtyIn1Lot, String apndmsg, double curval) throws Exception {
    		if(totqty > trailqty) {
    			RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
                        "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
                Request postRequest4sale = new Request.Builder()
                        .url(RepositoryClass.placeOrder)
                        .method("POST", body4sale)
                        .addHeader("Content-Type", "application/json").build();
                Response response = App.client.newCall(postRequest4sale).execute();
                this.totqty = this.totqty - qtyIn1Lot;
                getOrderNumber(response);
                TelegramUtil.sendTelegramMsgToChanelAsync(apndmsg+"Partial Sale Order Placed aftr prft lvl hit for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
    		}
    	}
    	
    	public void getOrderNumber(Response response) {
    		try {
    			JSONObject json = new JSONObject(response.body().string());
    			saleOrderIdArr.add(json.getString("norenordno"));
    		}catch(Exception i) {
    			
    		}
    	}
    	
        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            System.out.println("Bad day! " + webSocket.toString()+", error="+error.getStackTrace());
            WebSocket.Listener.super.onError(webSocket, error);
        }
     }
	
    
    private class WebSocketClientAutoTradeApproachTwo implements WebSocket.Listener {
    	String scrip;
    	String scriptoken = "";
    	int totqty;
    	int totqty4waittime;
    	int trailqty;
    	int qtyIn1Lot;
    	double stopls;
    	int totqtyorig;
    	double buyprc;
    	double buyprcorig;
    	double trailupby;
    	double trailupbysmall;
    	OrderDetailNew[] localOrderArr;
    	int nooforder;
    	int waittime = -1;
    	Integer placeOrderAtCurBuyPrc = 1;
    	long orderpicktime = 0l;
    	boolean fakeorder = false;
    	double saleprcnthikedefault = 0.022;
    	double saleprcnthikedefaultNxt = 0.032;
    	double saleprcdefault = 1000.5;
    	double saleprcdefaultNxt = 1000.5;
    	List<String> saleOrderIdArr = null;
        public WebSocketClientAutoTradeApproachTwo(String scripnm, int totqty, int trailqty, int qtyIn1Lot, double stopls, double stoplossforpositionload, double buyprice, double trailupby, double trailupbysmall, OrderDetailNew[] localOrderArr, int nooforder, int waittime, String scriptkn, boolean fakeorder, double saleprcnthikedefault) {
        	this.scrip = scripnm;
        	this.totqty = totqty;
        	this.trailqty = trailqty;
        	this.qtyIn1Lot = qtyIn1Lot;
        	this.stopls = stopls;
        	this.totqtyorig = totqty;
        	this.totqty4waittime = totqty;
        	this.buyprcorig = buyprice;
        	this.buyprc = buyprice;
        	this.trailupby = trailupby;
        	this.trailupbysmall = trailupbysmall;
        	this.localOrderArr = localOrderArr;
        	this.nooforder = nooforder;
        	this.waittime = waittime* 60 * 1000;
        	this.scriptoken = scriptkn;
        	this.fakeorder = fakeorder;
        	this.saleprcnthikedefault = saleprcnthikedefault;
        	this.saleprcnthikedefaultNxt = saleprcnthikedefault+0.015;
        	saleOrderIdArr = new ArrayList<String>();
        }
    	@Override
    	public void onOpen(WebSocket webSocket) {
    	    WebSocket.Listener.super.onOpen(webSocket);
    	    webSocket.sendText("{\"t\":\"c\",\"uid\":\"FA66519\",\"actid\":\"FA66519\",\"source\":\"API\",\"susertoken\":\""+App.loginToken+"\"}", true);
    	}
    	
    	int count = 0;
    	@Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            try {
            	String rsp = data.toString();
                //System.out.println(":Auto onText received=" + data);
	            if(rsp.contains("\"t\": \"ck\",")) {
	            	placeOrderAtCurBuyPrc = 1;
	            	orderpicktime = System.currentTimeMillis();
	            	boolean retry = false;
	            	if(this.scriptoken == null) {
		            	try {
		            		this.scriptoken = FinvasiaUtil.getFinvasiaScripToken(scrip.toUpperCase(), "NFO");
		            		if(this.scriptoken == null)
		            			retry = true;
		            	}catch(Exception p) {
		            		retry = true;
		            	}
		            	if(retry == true)
		            		this.scriptoken = FinvasiaUtil.getFinvasiaScripToken(scrip.toUpperCase(), "NFO");
	            	}
	            	ws.sendText("{\"t\":\"t\",\"k\":\"NFO|"+this.scriptoken+"\"}", true);
	            	TelegramUtil.sendTelegramMsgToChanelAsync("ApproachTwo.WebSocket started now for:"+scrip+",tkn="+this.scriptoken+",qty:"+this.totqty, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
	            }else if(rsp.contains("\"t\":\"tk\",") || rsp.contains("\"t\":\"tf\",")){
	                JSONObject json = new JSONObject(rsp);
	                String tkn = json.getString("tk");
	                String ltp = "";
	                try {
	                	ltp = json.getString("lp");
	                }catch(Exception x) {
	                	try {
	                		ltp = json.getString("bp1");
	                	}catch(Exception xx) {
	                		try {
	                			ltp = json.getString("sp1");
	                		}catch(Exception xi) {
	                			
	                		}
	                	}
	                }
	                if(ltp != null && ltp.trim().length()>0) {
	                	Double curval = Double.valueOf(ltp);
	                	if(this.scriptoken.equals(tkn)) {
	                		//place stoploss triggered order
		                	if(curval <= this.stopls && this.totqtyorig > 0) {
		                		StockMarketUtil.cancelAllOrder(saleOrderIdArr);
		                		int qty = StockMarketUtil.loadPositionBook(this.scrip);
		                		if(qty > -1)
		                			this.totqty = qty;
		                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
		                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+this.totqty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
		                        Request postRequest4sale = new Request.Builder()
		                                .url(RepositoryClass.placeOrder)
		                                .method("POST", body4sale)
		                                .addHeader("Content-Type", "application/json").build();
		                        App.client.newCall(postRequest4sale).execute();
		                        
		                		for(int i=0; i<15; i++) {
		                			this.localOrderArr[i] = null;
		                		}
		                        this.totqtyorig = 0;
		                        this.placeOrderAtCurBuyPrc = 0;
		                        this.totqty = 0;
		                        TelegramUtil.sendTelegramMsgToChanelAsync("StplsHit.Sale Order Placed now for:"+scrip+",qty="+this.totqty+"[q="+qty+"],p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
		                	}
		                	
		                	//checkwait time place sell order
		                	if(this.waittime > -1) {
	                			if(this.totqty4waittime > 0) {
	                				if(curval > this.saleprcdefault) {
		                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
		    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
		    	                        Request postRequest4sale = new Request.Builder()
		    	                                .url(RepositoryClass.placeOrder)
		    	                                .method("POST", body4sale)
		    	                                .addHeader("Content-Type", "application/json").build();
		    	                        Response response = App.client.newCall(postRequest4sale).execute();
		    	                        this.totqty4waittime = this.totqty4waittime - qtyIn1Lot;
		    	                        saleprcdefault = curval + (curval * saleprcnthikedefault);
		    	                        getOrderNumber(response);
		    	                        TelegramUtil.sendTelegramMsgToChanelAsync("Waittime-saleprcdflt.Partial Sale Order Placed now for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
	                				}else if(curval > this.saleprcdefaultNxt) {
		                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
		    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
		    	                        Request postRequest4sale = new Request.Builder()
		    	                                .url(RepositoryClass.placeOrder)
		    	                                .method("POST", body4sale)
		    	                                .addHeader("Content-Type", "application/json").build();
		    	                        Response response = App.client.newCall(postRequest4sale).execute();
		    	                        this.totqty4waittime = this.totqty4waittime - qtyIn1Lot;
		    	                        saleprcdefault = curval + (curval * saleprcnthikedefault);
		    	                        saleprcdefaultNxt = curval + (curval * saleprcnthikedefaultNxt);
		    	                        getOrderNumber(response);
		    	                        TelegramUtil.sendTelegramMsgToChanelAsync("Waittime-saleprcdflt.Partial Sale Order Placed now for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
	                				}
	                			}
		                	}
		                	
		                	if(this.placeOrderAtCurBuyPrc > 0) {
			                	synchronized(lockobj) {
				                	//check and place buyorder
				                	if(this.placeOrderAtCurBuyPrc > 0) {
				                		this.placeOrderAtCurBuyPrc = (StockMarketUtil.placeBuyOrderForLocalOrders(curval, this.scrip, App.loginToken, this.localOrderArr, this.nooforder, fakeorder, null, this.saleprcnthikedefault));
				                		if(this.placeOrderAtCurBuyPrc == 2) {
				                			saleprcdefault = curval + (curval * saleprcnthikedefault);
				                			saleprcdefaultNxt = curval + (curval * saleprcnthikedefaultNxt);
				                		}else if(this.placeOrderAtCurBuyPrc == 0) {
				                			StockMarketUtil.cancelAllOrder(saleOrderIdArr);
				                		}
				                	}
			                	}
		                	}
			                	
			                	//checkwait time and cancel rest order
			                	if(this.waittime > -1) {
			                		if((System.currentTimeMillis() - orderpicktime) > this.waittime) {
				                		StockMarketUtil.cancelAllOrder(StockMarketUtil.getorderbookOrderNumber("B", this.scriptoken));
				                		int qty = StockMarketUtil.loadPositionBook(this.scrip);
				                		if(qty == totqtyorig) {
				                			this.buyprc = (this.stopls + this.buyprc) / 2;
				                		}else {
				                			if(qty > -1) {
					                			this.stopls = curval - trailupby;
					                			this.totqty = qty;
				                			}
				                		}
				                		this.waittime = -2;
				                		for(int i=0; i<this.nooforder; i++) {
				                			this.localOrderArr[i] = null;
				                		}
				                		TelegramUtil.sendTelegramMsgToChanelAsync("WaitTime over now for:"+scrip+",qty="+this.totqty+"[q="+qty+"],stopls:"+this.stopls+",buyat:"+this.buyprc, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				                		//load cancel orders//load position
			                		}else {
			                			if(curval > (this.buyprc+trailupby) && this.totqty4waittime > 0) {
			                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
			    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
			    	                        Request postRequest4sale = new Request.Builder()
			    	                                .url(RepositoryClass.placeOrder)
			    	                                .method("POST", body4sale)
			    	                                .addHeader("Content-Type", "application/json").build();
			    	                        Response response = App.client.newCall(postRequest4sale).execute();
			    	                        this.totqty4waittime = this.totqty4waittime - qtyIn1Lot;
			    	                        getOrderNumber(response);
			    	                        TelegramUtil.sendTelegramMsgToChanelAsync("Waittime.Partial Sale Order Placed now for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			    	                        /*
				                			int qty = StockMarketUtil.loadPositionBook(this.scrip);
				                			if(qty > 0) {
				                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
				    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
				    	                        Request postRequest4sale = new Request.Builder()
				    	                                .url(RepositoryClass.placeOrder)
				    	                                .method("POST", body4sale)
				    	                                .addHeader("Content-Type", "application/json").build();
				    	                        App.client.newCall(postRequest4sale).execute();
				    	                        this.totqty = this.totqty - qty;
				    	                        TelegramUtil.sendTelegramMsgToChanelAsync("Waittime.Partial Sale Order Placed now for:"+scrip+",qty="+qty, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				                			}
				                			*/
			                			}
			                		}
			                	}
			                	if(this.waittime == -2 && this.totqty > 0) {
			                		Double tmp = curval - trailupby;
			                        if(tmp > this.stopls) {
			                        	this.stopls = tmp;
			                        	//System.out.println(this.stopls +"<-->"+this.buyprc);
			                        }
			                        if(curval >= this.buyprcorig) {
			                        	trailupby = trailupbysmall;
			                        	this.buyprcorig = 10000.0;
			                        	this.buyprc = curval + trailupby;
			                        	checkandplacepartialsellorder(this.totqty, this.trailqty, this.qtyIn1Lot, "BuyPrc Reached.", curval);
			                        	//TelegramUtil.sendTelegramMsgToChanelAsync("BuyPrc Reached for Trailing prc for:"+scrip+",qty="+this.totqty+",stopls:"+this.stopls+",trailby:"+trailupby+",t:"+this.buyprc, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			                        }else if(curval >= this.buyprc) {
			                        	checkandplacepartialsellorder(this.totqty, this.trailqty, this.qtyIn1Lot, "", curval);
			                        	trailupby = trailupby - (curval*.008);
			                        	if(trailupby < 0.60) {
			                        		trailupby = 0.60;
			                        	}
			                        	this.buyprc = curval + trailupby;
			                        	int qty = StockMarketUtil.loadPositionBook(this.scrip);
			        	        		if(qty > -1) {
			        	        			this.totqty = qty;
			        	        		}
			        	        		TelegramUtil.sendTelegramMsgToChanelAsync("Trailing prc for:"+scrip+",qty="+this.totqty+",stopls:"+this.stopls+",trailby:"+trailupby+",t:"+this.buyprc, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			                        }else if(curval > this.saleprcdefault) {
			                        	checkandplacepartialsellorder(this.totqty, this.trailqty, this.qtyIn1Lot, "saleprcdflt-", curval);
		    	                        saleprcdefault = curval + (curval * saleprcnthikedefault);		    	                        
		                			}else if(curval > this.saleprcdefaultNxt) {
			                        	checkandplacepartialsellorder(this.totqty, this.trailqty, this.qtyIn1Lot, "saleprcdflt-", curval);
		    	                        saleprcdefault = curval + (curval * saleprcnthikedefault);	
		    	                        saleprcdefaultNxt = curval + (curval * saleprcnthikedefaultNxt);
		                			}
			                	}
		                	
		                	
	                	}
	                }
	            }
            }catch(Exception xp) {
            	logger.error("Some issue---", xp);
            }
            try {
	        	if(count ==0) { //if(curval <= stoplossforpositionload && this.totqty > 0) {
	        		int qty = StockMarketUtil.loadPositionBook(this.scrip);
	        		if(qty > -1) {
        				this.totqty = qty;
        				this.totqty4waittime = qty;
	        		}
	        	}
	        	count++;
	        	if(count > 30) {
	        		count = 0;
	        	}
            }catch(Exception xp) {
            	logger.error("position issue--", xp);
            }
            
            if(this.totqtyorig == 0) {
            	trackingscrip = "";
            	TelegramUtil.sendTelegramMsgToChanel("Stop:", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
            	TelegramUtil.sendTelegramMsgToChanel("Remove:%0A"+scrip, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
            	if(this.scriptoken != null)
            		ws.sendText("{\"t\":\"u\",\"k\":\""+this.scriptoken+"\"}", true);
            }else {
            	webSocket.request(1);
            }
            return null;
        }
    	
    	public void checkandplacepartialsellorder(int totqty, int trailqty, int qtyIn1Lot, String apndmsg, double curval) throws Exception {
    		if(totqty > trailqty) {
    			RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
                        "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qtyIn1Lot+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+this.scrip+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
                Request postRequest4sale = new Request.Builder()
                        .url(RepositoryClass.placeOrder)
                        .method("POST", body4sale)
                        .addHeader("Content-Type", "application/json").build();
                Response response = App.client.newCall(postRequest4sale).execute();
                this.totqty = this.totqty - qtyIn1Lot;
                getOrderNumber(response);
                TelegramUtil.sendTelegramMsgToChanelAsync(apndmsg+"Partial Sale Order Placed aftr prft lvl hit for:"+scrip+",qty="+qtyIn1Lot+",p:"+curval, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
    		}
    	}
    	
    	public void getOrderNumber(Response response) {
    		try {
    			JSONObject json = new JSONObject(response.body().string());
    			saleOrderIdArr.add(json.getString("norenordno"));
    		}catch(Exception i) {
    			
    		}
    	}
    	
        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            System.out.println("Bad day! " + webSocket.toString()+", error="+error.getStackTrace());
            WebSocket.Listener.super.onError(webSocket, error);
        }
     }

}
