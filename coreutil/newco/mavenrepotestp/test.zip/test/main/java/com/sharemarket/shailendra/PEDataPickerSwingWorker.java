package com.sharemarket.shailendra;

import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PEDataPickerSwingWorker extends SwingWorker {
	final static MediaType mediaType_JSON = MediaType.parse("application/json; charset=utf-8");
	private JTextField txtPrcPE;
	private String loginToken;
    private String scripToken;

    
	public PEDataPickerSwingWorker(String scripTokenVal, String loginToken, JTextField txtPrcPE) {
		this.loginToken = loginToken;
        scripToken = scripTokenVal;
        this.txtPrcPE = txtPrcPE;
    }

	@Override
	protected Object doInBackground() throws Exception {
		int cnt = 0;
        OkHttpClient client4prc = new OkHttpClient.Builder().hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        }).connectTimeout(2, TimeUnit.SECONDS)
                .readTimeout(2, TimeUnit.SECONDS)
                .writeTimeout(2, TimeUnit.SECONDS)
                .build();
        RequestBody body = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"token\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
        okhttp3.Request.Builder reqBuilder = new Request.Builder()
                .url("https://shoonyatrade.finvasia.com/NorenWClientTP/GetQuotes").addHeader("Content-Type", "application/json");
               
        while(isCancelled() == false && cnt<54000) {
        	String ltp = "";
            try {
                Request postRequest = reqBuilder.method("POST", body).build();
                Response response = client4prc.newCall(postRequest).execute();
                JSONObject json = new JSONObject(response.body().string());
                ltp = json.getString("lp");
                Double curValue = Double.valueOf(ltp);
                if("pe".equals(App.placeLocalOrdFor)) {
                	StockMarketUtil.placeBuyOrderForLocalOrders(curValue, scripToken, loginToken, App.localOrderArr, 15, false,null,0.025);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            txtPrcPE.setText(ltp);
			cnt = cnt + 1;
		}
		return null;
	}

}
