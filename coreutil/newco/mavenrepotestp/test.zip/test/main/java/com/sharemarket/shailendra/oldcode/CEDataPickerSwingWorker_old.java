package com.sharemarket.shailendra.oldcode;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.OrderDetailNew;
import com.sharemarket.shailendra.StockMarketUtil;

public class CEDataPickerSwingWorker_old extends SwingWorker {
	final static MediaType mediaType_JSON = MediaType.parse("application/json; charset=utf-8");
	private JTextField txtPrcCE;
	JTextField txtBxTargetProfit;
	JTextField txtBxStopLs;
	private String loginToken;
    private String scripToken;
    private Integer qtyIn1LotIdValue = 50;
    private Double pftPercentIdValue = 2.5;
    
    private Double targetProfitValue = 1000000.0;
    Double targetStpLsValue = 0.0000;
	Double targetStpLsUpByValue = 0.4;
	Integer noOfLot2SaleAtPftValue = 1;
	Integer noOfLot2SaleAtStplsValue = 0;
	Double stplsPriceStartPointValueNow = 0.0;
	Double stopLossTriggerPrcValueLocal = 200000.0;
	Double stopLoss1stTriggerPrcValueLocal = 200000.0;
    
	public CEDataPickerSwingWorker_old(String scripTokenVal, String loginToken, Integer qtyIn1LotIdValueData, Double pftPercentIdValue, JTextField txtPrcCE, JTextField txtTargetProfit, JTextField txtStopLs) {
		this.loginToken = loginToken;
        scripToken = scripTokenVal;
        qtyIn1LotIdValue = qtyIn1LotIdValueData;
        this.pftPercentIdValue = pftPercentIdValue;
        this.txtPrcCE = txtPrcCE;
        this.txtBxTargetProfit = txtTargetProfit;
        this.txtBxStopLs = txtStopLs;
    }

	@Override
	protected Object doInBackground() throws Exception {
		/*
		int cnt = 0;
        OkHttpClient client4prc = new OkHttpClient.Builder().hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        }).connectTimeout(2, TimeUnit.SECONDS)
                .readTimeout(2, TimeUnit.SECONDS)
                .writeTimeout(2, TimeUnit.SECONDS)
                .build();
        RequestBody body = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"token\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
        okhttp3.Request.Builder reqBuilder = new Request.Builder()
                .url("https://shoonyatrade.finvasia.com/NorenWClientTP/GetQuotes").addHeader("Content-Type", "application/json");
        
        List<String> orderids = null;
        
        while(isCancelled() == false && cnt<54000) {
        	String ltp = "";
        	try {
                Request postRequest = reqBuilder.method("POST", body).build();
                Response response = client4prc.newCall(postRequest).execute();
                JSONObject json = new JSONObject(response.body().string());
                ltp = json.getString("lp");
                Double curValue = Double.valueOf(ltp);
                
                if("ce".equals(App.placeLocalOrdFor)) {
                	if(curValue > stopLoss1stTriggerPrcValueLocal) {
                		for(int i=0; i<10; i++) {
                			OrderDetailNew od = App.localOrderArr[i];
                			if(od != null) {
                				if(curValue < od.getMxP() && curValue >= od.getMnP()) {
                					String ordPrc = App.df.format(od.getMnP());
                                    RequestBody body4buy = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n" +
                                            "\"prc\":\""+ordPrc+"\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+od.getQty()+"\",\r\n\"trantype\":\"B\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
                                    Request.Builder postRequestBuilder4buy = new Request.Builder()
                                            .url("https://shoonyatrade.finvasia.com/NorenWClientTP/PlaceOrder")
                                            .method("POST", body4buy)
                                            .addHeader("Content-Type", "application/json");
                                    Request postRequest4buy = postRequestBuilder4buy.build();
                                    client4prc.newCall(postRequest4buy).execute();
                                    App.localOrderArr[i] = null;
                					for(int ix=i+1; ix<10; ix++) {
                						postRequest4buy = postRequestBuilder4buy.build();
                                        client4prc.newCall(postRequest4buy).execute();
                                        App.localOrderArr[ix] = null;
                					}
                					break;
                				}
                			}
                		}
                	}
                }
                if(App.stplsPriceStrtPointValueNow == -1) {
                	scripToken = App.scripCodeStopLoss;
                	targetProfitValue = App.targetProfitIdValue;
                	targetStpLsValue = App.targetStpLsIdValue;
                	targetStpLsUpByValue = App.targetStpLsUpByIdValue;
                	noOfLot2SaleAtPftValue = App.noOfLot2SaleAtPftIdValue;
                	noOfLot2SaleAtStplsValue = App.noOfLot2SaleAtStplsIdValue;
                	stplsPriceStartPointValueNow = App.stplsPriceStrtPointValueNow;
                	stopLossTriggerPrcValueLocal = App.stopLossTriggerPrcValue;
                	stopLoss1stTriggerPrcValueLocal = App.stopLoss1stTriggerPrcValue;
                	App.stplsPriceStrtPointValueNow = 0.0;
                }

                if(App.stplsPriceStrtPointValueNow > 0) {
                	stplsPriceStartPointValueNow = App.stplsPriceStrtPointValueNow;
                	App.stplsPriceStrtPointValueNow = 0.0;
                }
                
                //System.out.println(curValue+"<>"+targetStpLsValue+","+noOfLot2SaleAtStplsValue+"="+stplsPriceStartPointValueNow);
                if(curValue > 1 && noOfLot2SaleAtStplsValue > 0) {// && App.checkBoxAutoXcuteOrderState == true) {
                	//System.out.println(curValue+"=curValue<-->*stopLoss1stTriggerPrcValueLocal="+stopLoss1stTriggerPrcValueLocal);
                    int updateUiFields = 0;
                    if(curValue <= targetStpLsValue) {
                        //place market order sale
                        int quantity = noOfLot2SaleAtStplsValue * qtyIn1LotIdValue;
                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+quantity+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
                        Request postRequest4sale = new Request.Builder()
                                .url("https://shoonyatrade.finvasia.com/NorenWClientTP/PlaceOrder")
                                .method("POST", body4sale)
                                .addHeader("Content-Type", "application/json").build();
                        client4prc.newCall(postRequest4sale).execute();
                        targetStpLsValue = -10.0;
                        targetProfitValue = 1000000.0;
                    	targetStpLsUpByValue = 0.4;
                    	noOfLot2SaleAtPftValue = 1;
                    	noOfLot2SaleAtStplsValue = 0;
                    	stplsPriceStartPointValueNow = 0.0;
                        updateUiFields = -1;
                        //App.checkBoxAutoXcuteOrderState = false;
                        //App.checkBoxAutoXcuteOrder.setSelected(false);
                    }else if(curValue <= stopLoss1stTriggerPrcValueLocal) {
                    	//fetch order from order box
                    	orderids = StockMarketUtil.loadorderbook();
                    	//load position
                    	Integer qty = StockMarketUtil.loadPositionBook(scripToken);
                    	noOfLot2SaleAtStplsValue = qty / qtyIn1LotIdValue;
                    }else if(curValue <= stopLossTriggerPrcValueLocal) {
                    	//cancelAllOrder
                    	if(orderids != null) {
                    		StockMarketUtil.cancelAllOrder(orderids);
                    	}
                    	//load position
                    	Integer qty = StockMarketUtil.loadPositionBook(scripToken);
                    	noOfLot2SaleAtStplsValue = qty / qtyIn1LotIdValue;
                    	//System.out.println(App.stplsPriceStrtPointValueNow+"<-->"+orderids+"="+noOfLot2SaleAtStplsValue);
                    }else if(curValue >= targetProfitValue && noOfLot2SaleAtStplsValue > 0) {
                        //place market order sale
                        int quantity = noOfLot2SaleAtPftValue * qtyIn1LotIdValue;
                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+quantity+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
                        Request postRequest4sale = new Request.Builder()
                                .url("https://shoonyatrade.finvasia.com/NorenWClientTP/PlaceOrder")
                                .method("POST", body4sale)
                                .addHeader("Content-Type", "application/json").build();
                        client4prc.newCall(postRequest4sale).execute();
                        noOfLot2SaleAtStplsValue = noOfLot2SaleAtStplsValue - noOfLot2SaleAtPftValue;
                        targetProfitValue = curValue + ((curValue*pftPercentIdValue)/100);
                        updateUiFields = 5;
                    }
                    if(stplsPriceStartPointValueNow > 1.0 && curValue > stplsPriceStartPointValueNow && updateUiFields > -1) {
                        Double tmp = curValue - targetStpLsUpByValue;
                        //System.out.println(stplsPriceStartPointValueNow+"=stplsPriceStartPointValueNow<-->*"+tmp+"="+targetStpLsValue);
                        if(tmp > targetStpLsValue) {
                        	targetStpLsValue = tmp;
                        	stopLoss1stTriggerPrcValueLocal = targetStpLsValue + (targetStpLsUpByValue*0.66);
                        	stopLossTriggerPrcValueLocal = targetStpLsValue + (targetStpLsUpByValue*0.34);
                        	App.targetStpLsIdValue = tmp;
                            updateUiFields = 5;
                        }
                    }
                    if(updateUiFields > 0 || updateUiFields == -1) {
                    	javax.swing.SwingUtilities.invokeLater(new Runnable() {
            		        public void run() {
            		        	String stpVal = targetStpLsValue+"";
            		        	stpVal = stpVal.length() > 5 ? stpVal.substring(0, 5) : stpVal;
                            	txtBxStopLs.setText(stpVal);
                            	String stpTVal = targetProfitValue+"";
                            	stpTVal = stpTVal.length() > 5 ? stpTVal.substring(0, 5) : stpTVal;
                            	txtBxTargetProfit.setText(stpTVal);
            		        }
            		    });
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            txtPrcCE.setText(ltp);
			cnt = cnt + 1;
		}
		*/
		return null;
	}

}
