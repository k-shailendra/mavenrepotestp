package com.sharemarket.shailendra.charting;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.TelegramUtil;

public class NiftyDataProcessor implements Runnable {
	private static final Logger logger = LogManager.getLogger(NiftyDataProcessor.class);
	private long prevvol = 0;
	
	@Override
	public void run() {
        try {
			Calendar cal = Calendar.getInstance();
			if(CommonUtils.isTradingAllowedToday(cal)) {
				int min = cal.get(Calendar.MINUTE);
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				if(hr >= 9 || hr <= 15) {
		            CookieHandler.setDefault(new CookieManager());
		            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000)).version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault())
		                    .build();
		            java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
		                    .setHeader("Accept-Encoding", "deflate, br")
		                    .setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")//.setHeader("Connection", "keep-alive")
		                    //.setHeader("Host", "www.nseindia.com")
		                    .setHeader("Referer", "https://www.nseindia.com/")
		                    .setHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
		                    .setHeader("Accept",
		                            "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
		                    .setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(55000)).GET();
		            HttpResponse<String> rootSiteResp = client.send(_reqBuilder.uri(URI.create("https://www.nseindia.com/")).build(), HttpResponse.BodyHandlers.ofString());
		            if (rootSiteResp.statusCode() == 200) {
		                String _rcddateurl = "https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%2050";
		                HttpResponse<String> resp = client.send(_reqBuilder.uri(URI.create(_rcddateurl)).build(), HttpResponse.BodyHandlers.ofString());
		                if (resp.statusCode() == 200) {
		                	String sb = resp.body();
		    		    	JSONObject _jnode = new JSONObject(sb);
		                    if (_jnode == null) {
		                        System.out.println("###############********************unable to fetch record date and financial result data from:" + _rcddateurl + ". _jnode:" + _jnode);
		                    } else {
		                    	JSONArray datanode = _jnode.getJSONArray("data");
		                        if (datanode != null) {
		        		    		for (int ix=0; ix<datanode.length();ix++) {
		        		    			JSONObject insider = datanode.getJSONObject(ix);
		        		    			String symbol = insider.getString("symbol");
		        		    			if("NIFTY 50".equalsIgnoreCase(symbol)) {
		        		    				long vol = insider.getLong("totalTradedVolume");
		        		    				logger.info("niftyVol--->c:"+vol+",p:"+prevvol);
		        		    				if(prevvol>0 && vol>0)
		        		    					TelegramUtil.sendTelegramMsg("niftyVol--->c:"+vol+",p:"+prevvol+"==>"+(vol/prevvol), "-446563244", false);
		        		    				else
		        		    					TelegramUtil.sendTelegramMsg("niftyVol--->c:"+vol+",p:"+prevvol, "-446563244", false);
		        		    				if(vol>0)
		        		    					prevvol = vol;
		        		    			}
		        		    		}
		                        }
		                    }
		                }
		            }
	            }
			}
        }catch(Exception px) {
	    	   
	    }		
	}

}
