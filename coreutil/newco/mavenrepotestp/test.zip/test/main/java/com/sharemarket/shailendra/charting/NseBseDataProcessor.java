package com.sharemarket.shailendra.charting;

import java.io.InputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Version;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.ConstantScrips;
import com.sharemarket.shailendra.charting.ScripChartService.TodaysScripPriceCheckerExecutor;
import com.sharemarket.shailendra.utils.AlgoUtils;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.NSEBSEUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
public class NseBseDataProcessor implements Runnable {
	Properties prop;
	public static boolean canrunbulkdealdatafetch = false;
	public static boolean isScripChartAllowed = false;
	public static boolean isScripResultAllowed = false;
	private static final Logger logger = LogManager.getLogger(NseBseDataProcessor.class);
	public NseBseDataProcessor(Properties codeTokenMap) {
		this.prop = codeTokenMap;
		isScripChartAllowed = false;
		isScripResultAllowed = false;
		canrunbulkdealdatafetch = false;
	}
	@Override
	public void run() {
		try {
			if (isScripResultAllowed) {
				logger.info("------++-------processFinancialResultsFromSELiveDate------+++---------");
				ScripChartService.processFinancialResultsFromBSELiveDate(prop);
			}
		} catch (Exception ign) {
			logger.error("----->", ign);
		}
		try {
			logger.info("NSEBSE app---------------->");
			Calendar cal = Calendar.getInstance();
			if (CommonUtils.isTradingAllowedToday(cal)) {
				int min = cal.get(Calendar.MINUTE);
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				try {
					if (isScripChartAllowed && hr >= 16 && (hr <= 17 && min <= 17)) {
						new ScripChartService().pickAndSend5PaisaScripChart();
					}
				} catch (Exception px) {
					px.printStackTrace();
				}
				try {
					if (hr > 19 && hr < 21 && canrunbulkdealdatafetch) {
						TelegramUtil.sendTelegramMsg("Starting bulk data picking......", "-446563244", false);
						NSEBSEUtil.processBulkDealFromNSEBSE();
					}
				} catch (Exception xp) {
					logger.error("----->", xp);
				}
			} else {
				System.out.println("------------------------------->Trading not allowed today:" + cal);
			}
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}
	public static Set<String> getNse100ScripsName() {
		Set<String> snames = new HashSet<String>();
		try {
			CookieHandler.setDefault(new CookieManager());
			HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000))
					.version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault()).build();
			java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
					.setHeader("Accept-Encoding", "deflate, br")
					.setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")// .setHeader("Connection",
// "keep-alive")
// .setHeader("Host", "www.nseindia.com")
					.setHeader("Referer", "https://www.nseindia.com/")
					.setHeader("User-Agent",
							"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
					.setHeader("Accept",
							"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
					.setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(35000)).GET();
			HttpResponse<String> rootSiteResp = client.send(
					_reqBuilder.uri(URI.create("https://www.nseindia.com/")).build(),
					HttpResponse.BodyHandlers.ofString());
			if (rootSiteResp.statusCode() == 200) {
				String _rcddateurl = "https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%20100";
				HttpResponse<String> resp = client.send(_reqBuilder.uri(URI.create(_rcddateurl)).build(),
						HttpResponse.BodyHandlers.ofString());
				if (resp.statusCode() == 200) {
					String sb = resp.body();
					JSONObject json = new JSONObject(sb);
					JSONArray jar = json.getJSONArray("data");
					if (jar != null) {
						for (int ix = 0; ix < jar.length(); ix++) {
							JSONObject insider = jar.getJSONObject(ix);
							String symbol = insider.getString("symbol");
							if ("NIFTY 100".equals(symbol) == false)
								snames.add(symbol);
						}
					}
				}
			}
		} catch (Exception px) {
		}
		return snames;
	}
	public static void pickAndProcessScripsLivePreSessionData() throws Exception {
		ObjectMapper OBJECT_MAPPER_JACKSON = new ObjectMapper();
		Map<String, Double> bseCodeTOPriceMap = new HashMap<>();
		Map<String, Double> bseCodeTOUCMap = new HashMap<>();
		Map<String, Double> bseCodeTOLCMap = new HashMap<>();
		CookieHandler.setDefault(new CookieManager());
		HttpClient client = HttpClient.newBuilder().version(java.net.http.HttpClient.Version.HTTP_1_1)
				.cookieHandler(CookieHandler.getDefault()).build();
		for (int pageno = 1; pageno < 10; pageno++) {
			try {
				java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
						.setHeader("Accept-Encoding", "deflate, br")
						.setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")// .setHeader("Connection",
// "keep-alive")
// .setHeader("Host", "www.nseindia.com")
						.setHeader("Referer", "https://www.bseindia.com/")
						.setHeader("User-Agent",
								"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
						.setHeader("Accept",
								"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng;q=0.8,application/signed-exchange;v=b3;q=0.9")
						.setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(35000)).GET();
				HttpResponse<String> rootSiteResproot = client.send(
						_reqBuilder.uri(URI.create("https://www.bseindia.com/")).build(),
						HttpResponse.BodyHandlers.ofString());
				HttpResponse<String> rootSiteResp = client.send(_reqBuilder.uri(URI.create(
						"https://api.bseindia.com/BseIndiaAPI/api/GetStkCurrMain/w?flag=Equity&ddlVal1=Index&ddlVal2=S%26P%20BSE%20200&m=0&pgN="
								+ pageno))
						.build(), HttpResponse.BodyHandlers.ofString());
				if (rootSiteResp.statusCode() == 200) {
					JsonNode _jnode = OBJECT_MAPPER_JACKSON.readTree(rootSiteResp.body());
					if (_jnode == null || _jnode.isArray() == false) {
						logger.info(
								"###############********************unable to fetch BSE presession trading data. _jnode:"
										+ _jnode);
					} else {
						int cnt = 0;
						for (JsonNode objNode : _jnode) {
							String symb = objNode.get("ScripName").asText().trim();
							bseCodeTOPriceMap.put(symb, objNode.get("Open").asDouble(0.0));
							bseCodeTOUCMap.put(symb, Double.valueOf(objNode.get("upperCircuit").asText()));
							bseCodeTOLCMap.put(symb, Double.valueOf(objNode.get("lowerCircuit").asText()));
							cnt = cnt + 1;
						}
						if (cnt < 28)
							break;
					}
				} else {
					logger.info(
							"###############********************unable to hit bse url to fetch BSE presession traded data.status:"
									+ rootSiteResp.statusCode());
				}
			} catch (Exception xp) {
				logger.error("@@@@Some issue during bse data fetching for presession@@@@@@@@", xp);
			}
		}
		CookieHandler.setDefault(new CookieManager());
		HttpClient clientN = HttpClient.newBuilder().version(java.net.http.HttpClient.Version.HTTP_1_1)
				.cookieHandler(CookieHandler.getDefault()).build();
		java.net.http.HttpRequest.Builder _reqBuilderN = HttpRequest.newBuilder()
				.setHeader("Accept-Encoding", "deflate, br")
				.setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")
// .setHeader("Connection", "keep-alive")
// .setHeader("Host", "www.nseindia.com")
				.setHeader("Referer", "https://www.nseindia.com/")
				.setHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
				.setHeader("Accept",
						"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
				.setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(40000)).GET();
		HttpResponse<String> rootSiteResp = clientN.send(
				_reqBuilderN.uri(URI.create("https://www.nseindia.com/")).build(),
				HttpResponse.BodyHandlers.ofString());
		if (rootSiteResp.statusCode() == 200) {
			String urltohit = "https://www.nseindia.com/api/market-data-pre-open?key=ALL";
			HttpResponse<String> resp = clientN.send(_reqBuilderN.uri(URI.create(urltohit)).build(),
					HttpResponse.BodyHandlers.ofString());
			if (resp.statusCode() == 200) {
				JsonNode _jnode = OBJECT_MAPPER_JACKSON.readTree(resp.body());
				if (_jnode == null) {
					logger.info("###############********************unable to fetch nse pression record date from:"
							+ urltohit + ". _jnode:" + _jnode);
				} else {
					JsonNode data = _jnode.get("data");
					if (data == null || data.isArray() == false || data.size() == 0) {
						logger.info(
								"###############********************no data present in nse pression record date from:"
										+ urltohit + ". data:" + data);
					} else {
						for (JsonNode nd : data) {
							Double lowerCP = 0.0;
							Double upperCP = 0.0;
							Double iep = 0.0;
							long trdvol = 0l;
							Double prev = 0.0;
							Double unltp = 0.0;
							String codedetail = "";
							String symb = "";
							JsonNode metadata = nd.get("metadata");
							symb = metadata.get("symbol").asText().trim();
							try {
								prev = metadata.get("previousClose").asDouble();
							} catch (Exception i) {
							}
							try {
								lowerCP = bseCodeTOLCMap.getOrDefault(symb, 0.0);
								if (lowerCP == 0.0)
									lowerCP = prev - (prev * 0.1);
							} catch (Exception i) {
							}
							try {
								upperCP = bseCodeTOUCMap.getOrDefault(symb, 0.0);
								if (upperCP == 0.0)
									upperCP = prev + (prev * 0.1);
							} catch (Exception i) {
							}
							iep = metadata.get("iep").asDouble();
							JsonNode pom = nd.get("detail").get("preOpenMarket");
							trdvol = pom.get("finalQuantity").asLong();
							int bqty = pom.get("atoBuyQty").asInt();
							int sqty = pom.get("atoSellQty").asInt();
							codedetail = symb + ":p=" + prev + "c=" + iep + ":" + bqty + ":" + sqty + ":" + trdvol;
							unltp = iep + (iep * 0.015);
							if ((Double.compare(unltp, upperCP) > 0))
								codedetail = codedetail + ":UC";
							boolean isdiff = false;
							Double bseprice = bseCodeTOPriceMap.getOrDefault(symb, 0.0);
							if (bseprice > 0.0) {
								Double diff = iep - bseprice;
								if (diff < 0.0) {
									diff = ((diff * -1) * 100) / iep;
								} else {
									diff = ((diff) * 100) / bseprice;
								}
								if (diff > 1) {
									codedetail = codedetail + "B:" + bseprice + ",N:" + iep;
									isdiff = true;
								}
							}
							if (sqty > 0 && (bqty > 10 * sqty || isdiff)) {
								if (isdiff)
									TelegramUtil.sendTelegramMsg(
											"<b><u>Pre:" + codedetail + ",t:" + (bqty / sqty) + "</u></b>",
											"-446563244", false);
								else
									TelegramUtil.sendTelegramMsg("Pre:" + codedetail + ",t:" + (bqty / sqty),
											"-446563244", false);
								codedetail = "$" + codedetail;
							}
						}
					}
				}
			}
		} else {
			logger.warn("Issue in fetching nse presession data");
		}
	}
}