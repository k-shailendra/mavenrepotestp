package com.sharemarket.shailendra.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.sharemarket.shailendra.RepositoryClass;
import com.sharemarket.shailendra.modals.BulkDealDetail;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SilentCssErrorHandler;
import com.gargoylesoftware.htmlunit.ThreadedRefreshHandler;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlRadioButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.html.HtmlSubmitInput;
import com.gargoylesoftware.htmlunit.html.HtmlTextInput;

public class NSEBSEUtil {
	
	public static void main(String []ar) {
		try {
			processBulkDealFromNSEBSE();
		}catch(Exception xp) {
			xp.printStackTrace();
		}
	}
	
	public static void processBulkDealFromNSEBSE() throws Exception {
		Map<String, Map<Date, List<BulkDealDetail>>> scripblkmap = new TreeMap<String, Map<Date,List<BulkDealDetail>>>();
		List<String> bullClientMembers = new ArrayList<String>();
		bullClientMembers.add("nippon");
		bullClientMembers.add("motilal");
		bullClientMembers.add("invesco");
		bullClientMembers.add("jpmorgan");
		bullClientMembers.add("dsp mutual");
		bullClientMembers.add("morgan");
		bullClientMembers.add("hdfc");
		bullClientMembers.add("axis");
		bullClientMembers.add("icici");
		bullClientMembers.add("singapore");

		try {
			processBulkDealFromTrendlyne(bullClientMembers, 1.2);
		}catch(Exception xp) {
			xp.printStackTrace();
		}
		try {
			//processBulkDealFromNSE(bullClientMembers, scripblkmap);
		}catch(Exception xp) {
			xp.printStackTrace();
		}
		//try { Thread.sleep(30000);}catch(Exception xp) {}
		try {
			//processBulkDealFromBSE(bullClientMembers, scripblkmap);
		}catch(Exception xp) {
			xp.printStackTrace();
		}
		/*
		if(scripblkmap.size() > 0) {
			Date curdate = new Date();
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DATE, -1);
			Date prevdate = c.getTime();
			
	    	String telemsg = "Bulk Trd 2day NSEBSE:%0A";
			telemsg = telemsg + curdate +"%0A";
			
			Iterator<Entry<String, Map<Date, List<BulkDealDetail>>>> it = scripblkmap.entrySet().iterator();
	    	while (it.hasNext()) {
	    		Entry<String, Map<Date, List<BulkDealDetail>>> en = it.next();
	    		String scode = en.getKey();
	    		Iterator<Entry<Date, List<BulkDealDetail>>> dtitr = en.getValue().entrySet().iterator();
	    		while(dtitr.hasNext()) {
	    			Entry<Date, List<BulkDealDetail>> te = dtitr.next();
	    			Date dt = te.getKey();
	    			if((prevdate.getDate() == dt.getDate() && prevdate.getMonth() == dt.getMonth()) || (curdate.getDate() == dt.getDate() && curdate.getMonth() == dt.getMonth())) {
	    				int net = 0;
	    				int netb = 0;
	    				int nets = 0;
	    				String cnt = "";
	    				String sctr = "";
	        			if(net > 0) {
	        				telemsg = telemsg + scode+"["+sctr+"-"+dt.getDate()+"-"+(dt.getMonth()+1)+"]%0A,NT:"+net+",B:"+netb+",S:"+nets+","+cnt+"%0A%0A";
			    			if(telemsg.length()>3800) {
			    				try {
			    					TelegramUtil.sendTelegramMsg(telemsg,"-1001539893897", true);
			    				}catch(Exception _e) {_e.printStackTrace();}
			    				try {Thread.sleep(5000);}catch(Exception _e) {}
			    		    	telemsg = "Bulk Trd 2day NSEBSE Nxt:%0A";
			    				telemsg = telemsg + curdate +"%0A";
			    			}
	        			}
	    			}
	    		}
	    	}
			if(telemsg.length()>20) {
				try {
					TelegramUtil.sendTelegramMsg(telemsg,"-1001539893897", true);
					Thread.sleep(5000);
				}catch(Exception _e) {_e.printStackTrace();}
			}
		}
		*/
		
	}
	
	public static void processBulkDealFromTrendlyne(List<String> bullClientMembers, Double percent) throws Exception {
        WebClient _webClient = null;
    	Map<String, StringBuffer> telemap = new TreeMap();
        try {
        	//_webClient = new WebClient(BrowserVersion.FIREFOX);
        	_webClient = new WebClient(BrowserVersion.CHROME);
        	
        	_webClient.getOptions().setDownloadImages(false);
        	_webClient.getOptions().setPopupBlockerEnabled(true);
            _webClient.getOptions().setRedirectEnabled(true);
            //webClient.getOptions().setPrintContentOnFailingStatusCode(false);
        	_webClient.getOptions().setCssEnabled(false);
        	_webClient.getOptions().setUseInsecureSSL(true);
        	_webClient.getCookieManager().setCookiesEnabled(true);
        	_webClient.getCache().setMaxSize(0);
        	_webClient.getCache().clear();
        	_webClient.getCookieManager().clearCookies();

        	_webClient.getOptions().setJavaScriptEnabled(false);
        	_webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        	_webClient.waitForBackgroundJavaScript(10000);
        	_webClient.getOptions().setThrowExceptionOnScriptError(false);
        	_webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        	
            SimpleDateFormat smf = new SimpleDateFormat("yyyy-MM-dd");
            for(int i=0; i<3; i=i+2) {
            	try {
		            Calendar c = Calendar.getInstance();
		            c.add(Calendar.DATE, -1*i);
		            String toDate = smf.format(c.getTime());
		            c.add(Calendar.DATE, -1);
		            String frmDate = smf.format(c.getTime());
		            HtmlPage myPage = (HtmlPage) (_webClient.getPage("https://trendlyne.com/portfolio/bulk-block-deals/all/?start_date="+frmDate+"&end_date="+toDate));
		            synchronized (myPage) {
		                try {
		                    myPage.wait(40000);
		                } catch (InterruptedException e) {
		                    e.printStackTrace();
		                }
		            }
		            //System.out.print(myPage.getElementById("bbdealTable").asXml());//.getVisibleText());
		            //System.out.println(((DomElement)(myPage.getElementById("bbdealTable").getByXPath("tbody").get(0))).asXml());
	
		            List<HtmlElement> rows=((DomElement)(myPage.getElementById("bbdealTable").getByXPath("tbody").get(0))).getElementsByTagName("tr");
		            for(int rnum=0;rnum<rows.size();rnum++) {
		            	try {
			            	List<HtmlElement> columns=rows.get(rnum).getElementsByTagName("td");
				            String scrp = "";
				            StringBuffer bf = new StringBuffer();
				            for(int cnum=0;cnum<columns.size();cnum++) {
				            	String col = columns.get(cnum).asText().replaceAll("\r", " ").replaceAll("\n", " ").trim();
				            	if(cnum == 0) {
				            		scrp = col;
				            	}else {
					            	if(cnum == 1) {
					            		String tcol = (col.length() < 10 ? col : col.substring(0, 10).trim());
			                			for(String bull : bullClientMembers) {
			                				if(col.toLowerCase().contains(bull.toLowerCase())) {
			                					tcol = "<b>"+tcol+"</b>";
			                					break;
			                				}
			                			}
			                			col = tcol;
					            	}
					            	if(cnum == 2) {
					            		if("NSE".equalsIgnoreCase(col)) {
					            			col = "N";
					            		}else {
					            			col = "B";
					            		}
					            	}
					            	if(cnum == 3) {
					            		if("Bulk".equalsIgnoreCase(col)) {
					            			col = "blk";
					            		}else {
					            			col = "blok";
					            		}
					            	}
					            	if(cnum == 4) {
					            		if("purchase".equalsIgnoreCase(col)) {
					            			col = "P";
					            		}else {
						            		col = "S";
					            		}
					            	}
					            	if(cnum == 5) {
					            		col = col.substring(0, 6).trim();
					            	}
					            	if(cnum == 8) {
					            		try {
						            		if(percent < Double.valueOf(col.substring(0, col.indexOf("%")).trim())) {
						            			col = "<b>"+col+"</b>";
						            		}
					            		}catch(Exception pxx) {}
					            		bf.append(col);
					            	}else {
					            		if(cnum == 7) {
					            			
					            		}else {
					            			bf.append(col+">");
					            		}
					            	}
				            	}
				            }
			            	bf.append("%0A");
				            StringBuffer bfr = telemap.getOrDefault(scrp, new StringBuffer());
				            bfr.append(bf);
				            telemap.put(scrp, bfr);
		            	}catch(Exception px) {
		            		px.printStackTrace();
		            	}
		            }
            }catch(Exception x) {}
	            
            }
            _webClient.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
        	//Iterator<StringBuffer> itr = telemap.values().iterator();
        	StringBuffer tl = new StringBuffer();
        	boolean sent = false;
        	for (Map.Entry<String, StringBuffer> entry : telemap.entrySet()) {
        		StringBuffer vl = entry.getValue();
        		String key = entry.getKey();
        		if(tl.length()+vl.length() < 3800) {
        			tl.append("%0A<b>"+key+"</b>%0A"+vl);
        		}else {
        			TelegramUtil.sendTelegramMsg(tl.toString(), "-446563244", false);
        			tl = new StringBuffer();
        			tl.append("%0A<b>"+key+"</b>%0A"+vl);
        			sent = true;
        		}
        	}
        	if(tl.length() > 10) {
        		TelegramUtil.sendTelegramMsg(tl.toString(), "-446563244", false);
        		sent = true;
        	}
        	if(sent == false)
        		TelegramUtil.sendTelegramMsg("Some issue in bulk data picking......", "-446563244", false);
        }catch(Exception xx) {
        	xx.printStackTrace();
        }
    
	}
	
	public static void processBulkDealFromBSE(List<String> bullClientMembers, Map<String, Map<Date, List<BulkDealDetail>>> scripblkmap) throws Exception {
        WebClient _webClient = null;
        try {
        	//_webClient = new WebClient(BrowserVersion.FIREFOX);
        	_webClient = new WebClient(BrowserVersion.CHROME);
        	
        	_webClient.getOptions().setDownloadImages(false);
        	_webClient.getOptions().setPopupBlockerEnabled(true);
            _webClient.getOptions().setRedirectEnabled(true);
            //webClient.getOptions().setPrintContentOnFailingStatusCode(false);
        	_webClient.getOptions().setCssEnabled(false);
        	_webClient.getOptions().setUseInsecureSSL(true);
        	_webClient.getCookieManager().setCookiesEnabled(true);
        	_webClient.getCache().setMaxSize(0);
        	_webClient.getCache().clear();
        	_webClient.getCookieManager().clearCookies();

        	_webClient.getOptions().setJavaScriptEnabled(false);
        	_webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        	_webClient.waitForBackgroundJavaScript(10000);
        	_webClient.getOptions().setThrowExceptionOnScriptError(false);
        	_webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        	
            HtmlPage myPage = (HtmlPage) (_webClient.getPage("https://www.bseindia.com/markets/equity/EQReports/BulknBlockDeals.aspx"));
            synchronized (myPage) {
                try {
                    myPage.wait(12000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            //System.out.print(myPage.asXml());//.getVisibleText());
            SimpleDateFormat smf = new SimpleDateFormat ("dd/MM/yyyy");
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            String toDate = smf.format(c.getTime());
            String day2day = new SimpleDateFormat ("ddMMMyyyy").format(c.getTime());
            c.add(Calendar.DATE, -7);
            String fromDate = smf.format(c.getTime());
            Date frmDate = smf.parse(fromDate);
            
            HtmlPage myPageAfterSubmit = null;
            List<HtmlForm> forms = myPage.getForms();
            for (HtmlForm htmlForm : forms) {
				if("form1".equals(htmlForm.getId())) {
					HtmlSelect selectbox = htmlForm.getSelectByName("ctl00$ContentPlaceHolder1$rblDT");
					selectbox.getOptionByText("Bulk Deal").setSelected(true);
					htmlForm.getInputByName("ctl00$ContentPlaceHolder1$chkAllMarket").setChecked(true);
					final HtmlTextInput textFieldFrom = htmlForm.getInputByName("ctl00$ContentPlaceHolder1$txtDate");
					final HtmlTextInput textFieldTo = htmlForm.getInputByName("ctl00$ContentPlaceHolder1$txtToDate");
					final HtmlSubmitInput button = htmlForm.getInputByName("ctl00$ContentPlaceHolder1$btnSubmit");
					
					textFieldFrom.type(fromDate);
					textFieldTo.type(toDate);
					_webClient.getOptions().setJavaScriptEnabled(true);
					myPageAfterSubmit = button.click();
					_webClient.waitForBackgroundJavaScript(10000);
					break;
				}
			}
            
            synchronized (myPageAfterSubmit) {
                try {
                	myPageAfterSubmit.wait(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            //System.out.print(myPageAfterSubmit.asXml());            
        	_webClient.getOptions().setJavaScriptEnabled(true);
            List<HtmlAnchor> anchors = myPageAfterSubmit.getAnchors();
            for (int i = 0; i < anchors.size(); ++i) {
            	HtmlAnchor anchor = anchors.get(i);
                if ("ContentPlaceHolder1_btndownload1".equals(anchor.getId())) {
                	Page p = anchor.click();
                	_webClient.waitForBackgroundJavaScript(5000);
                    synchronized (p) {
                        try {
                        	p.wait(5000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                	//com.gargoylesoftware.htmlunit.UnexpectedPage dataPageCsv = null;
                    Page dataPageCsv = null;
                	try {
                    	dataPageCsv = (_webClient.getPage("https://www.bseindia.com/markets/downloads/Bulk_"+day2day+".csv"));
                    	_webClient.waitForBackgroundJavaScript(10000);
                        synchronized (dataPageCsv) {
                            try {
                            	dataPageCsv.wait(10000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                	}catch(Exception xp) {
                		xp.printStackTrace();
                		try {Thread.sleep(10000);}catch(Exception px) {}
                		try {
	                		dataPageCsv = (_webClient.getPage("https://www.bseindia.com/markets/downloads/Bulk_"+day2day+".csv"));
	                    	_webClient.waitForBackgroundJavaScript(10000);
	                        synchronized (dataPageCsv) {
	                            try {
	                            	dataPageCsv.wait(10000);
	                            } catch (InterruptedException e) {
	                                e.printStackTrace();
	                            }
	                        }
                		}catch (Exception ex) { ex.printStackTrace();}
                	}
                	
                	if(dataPageCsv == null) {
                		try {
	                		dataPageCsv = (_webClient.getPage("https://www.bseindia.com/markets/downloads/Bulk_"+day2day+".csv"));
	                    	_webClient.waitForBackgroundJavaScript(10000);
	                        synchronized (dataPageCsv) {
	                            try {
	                            	dataPageCsv.wait(10000);
	                            } catch (InterruptedException e) {
	                                e.printStackTrace();
	                            }
	                        }
                		}catch (Exception ex) { ex.printStackTrace();}
                	}
                	
                	//WebResponse response = ((com.gargoylesoftware.htmlunit.UnexpectedPage)p).getWebResponse();
                	WebResponse responsecsv = dataPageCsv.getWebResponse();
                    //System.out.println(responsecsv.getContentLength()+","+responsecsv.getClass()); System.out.println(responsecsv.getStatusCode()); System.out.println(responsecsv.getContentType());
                    String cntnt = responsecsv.getContentAsString();
                    if(cntnt == null) {
                    	cntnt = responsecsv.getContentAsString();
                    }
                    if(cntnt == null) {
                    	com.gargoylesoftware.htmlunit.UnexpectedPage dataPageCsvR = (_webClient.getPage("https://www.bseindia.com/markets/downloads/Bulk_"+day2day+".csv"));
                    	_webClient.waitForBackgroundJavaScript(10000);
                        synchronized (dataPageCsvR) {
                            try {
                            	dataPageCsvR.wait(10000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    	responsecsv = dataPageCsvR.getWebResponse();
                        cntnt = responsecsv.getContentAsString();
                    }
                    System.out.println(cntnt);
                    if(cntnt != null) {
                        String []bulkdataarr = cntnt.split("\r\n");
                        if(bulkdataarr != null) {
                        	boolean doprocess = false;
                        	for(int ix = 1; ix<bulkdataarr.length; ix++) {
                    			String []record = bulkdataarr[ix].split(",");
                    			String date = record[0];
                    			if(frmDate.equals(smf.parse(date)) ||frmDate.before(smf.parse(date)) || doprocess) {
                    				doprocess = true;
                    				String scode = record[2].trim();
                        			Map<Date, List<BulkDealDetail>> dateblkmap = scripblkmap.get(scode);
                        			if(dateblkmap == null) {
                        				dateblkmap = new TreeMap<Date, List<BulkDealDetail>>();
                        				scripblkmap.put(scode, dateblkmap);
                        			}
                        			Date cdate = smf.parse(date);
                        			List<BulkDealDetail> blkarr = dateblkmap.get(cdate);
                        			if(blkarr == null) {
                        				blkarr = new ArrayList<BulkDealDetail>();
                        				dateblkmap.put(cdate, blkarr);
                        			}
                        			boolean pick = false;
                        			String cname = record[3].trim().toLowerCase();
                        			for(String bull : bullClientMembers) {
                        				if(cname.contains(bull.toLowerCase())) {
                        					pick = true;
                        					break;
                        				}
                        				
                        			}
                        			
                        			BulkDealDetail _cur = new BulkDealDetail();

                        			

                        			blkarr.add(_cur);
                    			}
                        	}
                        }
                    }
                    break;
                }
            }
            _webClient.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    
	}
	
	public static void processBulkDealFromNSE(List<String> bullClientMembers, Map<String, Map<Date, List<BulkDealDetail>>> scripblkmap) throws Exception {
        WebClient _webClient = null;
        /*
        try {
        	_webClient = new WebClient(BrowserVersion.FIREFOX);
        	//_webClient = new WebClient(BrowserVersion.CHROME);
        	
        	_webClient.getOptions().setDownloadImages(false);
        	_webClient.getOptions().setPopupBlockerEnabled(true);
            _webClient.getOptions().setRedirectEnabled(true);
            //webClient.getOptions().setPrintContentOnFailingStatusCode(false);
        	_webClient.getOptions().setCssEnabled(false);
        	_webClient.getOptions().setUseInsecureSSL(true);
        	_webClient.getCookieManager().setCookiesEnabled(true);
        	_webClient.getCache().setMaxSize(0);
        	_webClient.getCache().clear();
        	_webClient.getCookieManager().clearCookies();

        	_webClient.getOptions().setJavaScriptEnabled(false);
        	_webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        	_webClient.waitForBackgroundJavaScript(10000);
        	_webClient.getOptions().setThrowExceptionOnScriptError(false);
        	_webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        	
        	_webClient.addRequestHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0");
        	_webClient.addRequestHeader("Accept", "application/html");
        	_webClient.addRequestHeader("Accept-Language","en-US,en;q=0.5");
        	_webClient.addRequestHeader("accept-encoding","deflate, br");
        	_webClient.addRequestHeader("Connection","keep-alive");
        	_webClient.addRequestHeader("Referer","https://www1.nseindia.com/products/content/equities/equities/bulk.htm");

            SimpleDateFormat smf = new SimpleDateFormat ("dd-MM-yyyy");
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            String toDate = smf.format(c.getTime());
            SimpleDateFormat smfddMMM = new SimpleDateFormat ("dd-MMM-yyyy");
            String day2day = smfddMMM.format(c.getTime());
            c.add(Calendar.DATE, -7);
            String fromDate = smf.format(c.getTime());
            
            HtmlPage myPage = (HtmlPage) (_webClient.getPage("https://www1.nseindia.com/products/dynaContent/equities/equities/bulkdeals.jsp?dateRange=&fromDate="+fromDate+"&toDate="+toDate+"&dataType=Deals"));
            synchronized (myPage) {
                try {
                    myPage.wait(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            String bulkdata = myPage.getHtmlElementById("csvContentDiv").getTextContent();
            if(bulkdata != null) {
            	String []bulkdataarr = bulkdata.split(":");
            	if(bulkdataarr != null) {
            		for(int ix = 1; ix<bulkdataarr.length; ix++) {
            			String []record = bulkdataarr[ix].split(",\"");
            			String scode = record[1].replaceAll("\"", "").trim();
            			Map<Date, List<BulkDealDetail>> dateblkmap = scripblkmap.get(scode);
            			if(dateblkmap == null) {
            				dateblkmap = new TreeMap<Date, List<BulkDealDetail>>();
            				scripblkmap.put(scode, dateblkmap);
            			}
            			String date = record[0].replaceAll("\"", "");
            			Date cdate = smfddMMM.parse(date);
            			List<BulkDealDetail> blkarr = dateblkmap.get(cdate);
            			if(blkarr == null) {
            				blkarr = new ArrayList<BulkDealDetail>();
            				dateblkmap.put(cdate, blkarr);
            			}
            			String cname = record[3].replaceAll("\"", "").trim().toLowerCase();
            			String ctype = "O";
            			if(fpiMembers.containsKey(cname)) {
            				if(bullClientMembers.containsKey(cname)) {
            					ctype = "SF";
            				}else {
            					ctype = "F";
            				}
            			}else {
            				if(bullClientMembers.containsKey(cname)) {
            					ctype = "S";
            				}
            			}
            			
            			BulkDealDetail _cur = new BulkDealDetail();
            			//_cur.setDt(dt);
            			_cur.setDtD(date);
            			_cur.setExchange("NSE");
            			_cur.setNsecode(scode);
            			_cur.setFpiclientname(cname);
            			_cur.setClienttype(ctype);
            			_cur.setSector(nsecodeTonsdl.get(scode));
            			_cur.setQty(Integer.parseInt(record[5].replaceAll("\"", "").replaceAll(",", "")));
            			_cur.setBuyorsale(""+record[4].replaceAll("\"", "").charAt(0));
            			blkarr.add(_cur);
            		}
            	}
            }
            
            _webClient.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    */
	}

}
