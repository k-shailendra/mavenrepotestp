package com.sharemarket.shailendra.utils;
import java.io.BufferedReader;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;

public class TelegramUtil {
    private static final Logger logger = LogManager.getLogger(TelegramUtil.class);
	static ExecutorService executorService = Executors.newVirtualThreadPerTaskExecutor();

	public static void sendTelegramMsg(final String telegramMsgToSend, final String chatId, final Boolean isSendBeep)
	{
	    try
	    {
	    	executorService.execute(new Runnable() {
	    	    public void run() {
					try {
						String telegramMsg = telegramMsgToSend;
						boolean beep = false;
				    	if(isSendBeep == null) {
				    		beep = true;
				    	}else {
				    		beep = !isSendBeep;
				    	}
				    	if(telegramMsg != null) {
				    		telegramMsg = telegramMsg.replaceAll("&", "");
				    		telegramMsg = telegramMsg.replaceAll("#", "");
				    		//telegramMsg = telegramMsg.replaceAll("/", "");
				    		telegramMsg = telegramMsg.replaceAll("$", "");
							telegramMsg = telegramMsg.replaceAll("\\r", "");
							telegramMsg = telegramMsg.replaceAll("\\n", "");
							telegramMsg = telegramMsg.replaceAll("\\n/\\r", "");
				    		telegramMsg = telegramMsg.replaceAll(" H", " h");
							telegramMsg = telegramMsg.replaceAll("<BR>", "");
				    		//telegramMsg = telegramMsg.replaceAll(" h ", "h");
				    	}
				    	//log.info("---------------------------sending telegramMsg--------------------------------------------------telegramMsg:"+telegramMsg);
				    	String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/sendMessage?chat_id="+chatId+"&disable_notification="+isSendBeep+"&parse_mode=html&text="+telegramMsg;
				    	//String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/getUpdates";
				    	URL url = new URL(urlString);
				    	URLConnection conn = url.openConnection();
				    	int status = ((HttpURLConnection)conn).getResponseCode();
				    	if (status == HttpURLConnection.HTTP_OK) {
				    		//System.out.println("---------------------------telegram msg send successfully--------------------------------------------------");
				    	}else {
				    		//System.out.println(chatId+":chatId--------------------telegram msg send unsuccessful*****--------------------------------------------------status:"+status+":"+((HttpURLConnection)conn).getResponseMessage()+"=>"+telegramMsg);
				    	}
					}catch(Exception ix) {
						logger.error("error...", ix);
					}
	    	    }
	    	});
	    }catch (Exception e)
	    {
	        //e.printStackTrace();
	    }
	}
	
	public static void sendTelegramMsgToChanelAsync(final String telegramMsgToSend, final String chatId, final String botId, final Boolean isSendBeep)
	{
		try {
	    	executorService.execute(new Runnable() {
	    	    public void run() {
					try {
						String telegramMsg = telegramMsgToSend;
						boolean beep = false;
				    	if(isSendBeep == null) {
				    		beep = true;
				    	}else {
				    		beep = !isSendBeep;
				    	}
				    	if(telegramMsg != null) {
				    		telegramMsg = telegramMsg.replaceAll("&", "");
				    		telegramMsg = telegramMsg.replaceAll("#", "");
				    		//telegramMsg = telegramMsg.replaceAll("/", "");
				    		telegramMsg = telegramMsg.replaceAll("$", "");
							telegramMsg = telegramMsg.replaceAll("\\r", "");
							telegramMsg = telegramMsg.replaceAll("\\n", "");
							telegramMsg = telegramMsg.replaceAll("\\n/\\r", "");
				    		telegramMsg = telegramMsg.replaceAll(" H", " h");
							telegramMsg = telegramMsg.replaceAll("<BR>", "");
				    		//telegramMsg = telegramMsg.replaceAll(" h ", "h");
				    	}
				    	//log.info("---------------------------sending telegramMsg--------------------------------------------------telegramMsg:"+telegramMsg);
				    	String urlString = "https://api.telegram.org/"+botId+"/sendMessage?chat_id="+chatId+"&disable_notification="+isSendBeep+"&parse_mode=html&text="+telegramMsg;
				    	URL url = new URL(urlString);
				    	URLConnection conn = url.openConnection();
				    	((HttpURLConnection)conn).getResponseCode();
					}catch(Exception ix) {
						logger.error("error...", ix);
					}
	    	    }
	    	});
		}catch(Exception ix) {
			logger.error("xcption" , ix);
		}
	}
	
	public static boolean sendTelegramMsgToChanel(final String telegramMsgToSend, final String chatId, final String botId, final Boolean isSendBeep)
	{
		try {
			String telegramMsg = telegramMsgToSend;
			boolean beep = false;
	    	if(isSendBeep == null) {
	    		beep = true;
	    	}else {
	    		beep = !isSendBeep;
	    	}
	    	if(telegramMsg != null) {
	    		telegramMsg = telegramMsg.replaceAll("&", "");
	    		telegramMsg = telegramMsg.replaceAll("#", "");
	    		//telegramMsg = telegramMsg.replaceAll("/", "");
	    		telegramMsg = telegramMsg.replaceAll("$", "");
				telegramMsg = telegramMsg.replaceAll("\\r", "");
				telegramMsg = telegramMsg.replaceAll("\\n", "");
				telegramMsg = telegramMsg.replaceAll("\\n/\\r", "");
	    		telegramMsg = telegramMsg.replaceAll(" H", " h");
				telegramMsg = telegramMsg.replaceAll("<BR>", "");
	    		//telegramMsg = telegramMsg.replaceAll(" h ", "h");
	    	}
	    	//log.info("---------------------------sending telegramMsg--------------------------------------------------telegramMsg:"+telegramMsg);
	    	String urlString = "https://api.telegram.org/"+botId+"/sendMessage?chat_id="+chatId+"&disable_notification="+isSendBeep+"&parse_mode=html&text="+telegramMsg;
	    	URL url = new URL(urlString);
	    	URLConnection conn = url.openConnection();
	    	int status = ((HttpURLConnection)conn).getResponseCode();
	    	if (status == HttpURLConnection.HTTP_OK) {
	    		return true;
	    		//System.out.println("---------------------------telegram msg send successfully--------------------------------------------------");
	    	}else {
	    		return false;
	    		//System.out.println(chatId+":chatId--------------------telegram msg send unsuccessful*****--------------------------------------------------status:"+status+":"+((HttpURLConnection)conn).getResponseMessage()+"=>"+telegramMsg);
	    	}
		}catch(Exception ix) {
			logger.error("xcption" , ix);
		}
		return false;
	}
	
	public static String getLatestTelegramMsgFromChanel(String botId)
	{
	    try
	    {
	    	String urlString = "https://api.telegram.org/"+botId+"/getUpdates?limit=1&offset=-1";
	    	URL url = new URL(urlString);
	    	HttpURLConnection request = (HttpURLConnection)(url.openConnection());
	        request.setRequestMethod("GET");
	        request.setUseCaches(false);
	        request.setDoInput(true);
	        request.setDoOutput(true);
	        request.connect();
	        BufferedReader rd = new BufferedReader(new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
	    	StringBuilder sb = new StringBuilder();
	        String cp = null;
	        while ((cp = rd.readLine()) != null) {
	          sb.append(cp);
	        }
	        try {rd.close();}catch(Exception lx) {}
	    	JSONObject json = new JSONObject(sb.toString());
	    	JSONArray  resultarr = json.getJSONArray("result");
	    	if(resultarr != null) {
	    		int ln = resultarr.length();
	    		if (ln>0) {
	    			JSONObject jo = resultarr.getJSONObject(0);
    				String ll = jo.get("update_id")+"@@##@@"+jo.getJSONObject("channel_post").getString("text");
    		        //logger.info(chatId+"<>"+i+"==getLatestTelegramMsg====>"+ll);
    				return ll;
				}
	    	}
	    }catch (Exception e) {
	        logger.error("XXXX", e);
	    }
	    return null;
	}
	
	public static String getLatestTelegramMsgFromGroup(String chatId)
	{
	    try
	    {
	    	String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/getUpdates";
	    	URL url = new URL(urlString);
	    	HttpURLConnection request = (HttpURLConnection)(url.openConnection());
	        request.setRequestMethod("GET");
	        request.setUseCaches(false);
	        request.setDoInput(true);
	        request.setDoOutput(true);
	        request.connect();
	        BufferedReader rd = new BufferedReader(new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
	    	StringBuilder sb = new StringBuilder();
	        String cp = null;
	        while ((cp = rd.readLine()) != null) {
	          sb.append(cp);
	        }
	        try {rd.close();}catch(Exception lx) {}
	    	JSONObject json = new JSONObject(sb.toString());
	    	JSONArray  resultarr = json.getJSONArray("result");
	    	if(resultarr != null) {
	    		int ln = resultarr.length();
	    		for (int i=ln-1; i>-1; i--) {
	    			JSONObject jo = resultarr.getJSONObject(i);
	    			JSONObject mo = jo.getJSONObject("message");
	    			if(chatId.equals(mo.getJSONObject("chat").get("id")+"")) {
	    				String ll = jo.get("update_id")+"@@##@@"+mo.getString("text");
	    		        //logger.info(chatId+"<>"+i+"==getLatestTelegramMsg====>"+ll);
	    				return ll;
	    			}
				}
	    	}
	    }catch (Exception e) {
	    	logger.error("XXXX", e);
	    }
	    return null;
	}
	
	public static boolean sendTelegramImageMsgUsingBytes(String imagetrail, String fileName, byte[] telegramImageBytesToSend, String chatId) {
	    try
	    {
	    	String boundary =  "*****";
	    	String crlf = "\r\n";
	    	String twoHyphens = "--";
	    	
	    	//log.info("---------------------------sending telegramImageMsg----------------------------file:"+fileName);
	    	String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/sendPhoto";
	    	//String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/getUpdates";
	    	URL url = new URL(urlString);
	    	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    	
	    	conn.setDoInput(true);
	    	conn.setDoOutput(true);
	    	conn.setUseCaches(false);
	    	
	    	conn.setRequestMethod("POST");
	    	conn.setRequestProperty("Connection", "Keep-Alive");
	        conn.setRequestProperty("Cache-Control", "no-cache");
	        conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
	
	        java.io.DataOutputStream request = new java.io.DataOutputStream(conn.getOutputStream());
	        
	        request.writeBytes(twoHyphens + boundary + crlf);
	        request.writeBytes("Content-Disposition: form-data; name=\"chat_id\""+ crlf);
	        request.writeBytes("Content-Type: text/plain; charset=UTF-8" + crlf);
	        request.writeBytes(crlf);
	        request.writeBytes(chatId+ crlf);
	        request.flush();
	        request.writeBytes(twoHyphens + boundary + crlf);
	        request.writeBytes("Content-Disposition: form-data; name=\"caption\""+ crlf);
	        request.writeBytes("Content-Type: text/plain; charset=UTF-8" + crlf);
	        request.writeBytes(crlf);
	        request.writeBytes(imagetrail+ crlf);
	        request.flush();
	        
	        request.writeBytes(twoHyphens + boundary + crlf);
	        request.writeBytes("Content-Disposition: form-data; name=\"photo\";filename=\"" +fileName + "\"" + crlf);
	        request.writeBytes(crlf);
	        request.write(telegramImageBytesToSend);
	        request.writeBytes(crlf);
	        request.writeBytes(twoHyphens + boundary +twoHyphens + crlf);
	        request.flush();
	        request.close();
	    	
	    	int status = ((HttpURLConnection)conn).getResponseCode();
	    	if (status == HttpURLConnection.HTTP_OK) {
	    		System.out.println("---------------------------telegram Image msg send successfully--------------------------------------------------");
	    		conn.disconnect();
	    		return true;
	    	}else {
	    		System.out.println(chatId+":chatId------------------telegram Image msg send unsuccessful*****--------------------------------------------------status:"+status+":"+((HttpURLConnection)conn).getResponseMessage());
				return false;
	    	}
	    }
	    catch (Exception e)
	    {
	        e.printStackTrace();
			return false;
	    }
	}
	
	
	public static void sendTelegramImageMsg(String imagetrail, File telegramImageToSend, String chatId) {
	    try
	    {
	    	String boundary =  "*****";
	    	String crlf = "\r\n";
	    	String twoHyphens = "--";
	    	
	    	//log.info("---------------------------sending telegramImageMsg----------------------------file:"+telegramImageToSend.getAbsolutePath());
	    	String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/sendPhoto";
	    	//String urlString = "https://api.telegram.org/bot1423597493:AAHw0DRhE6q-8xCE3j_WTe1uFFBRr_Ac6xA/getUpdates";
	    	URL url = new URL(urlString);
	    	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    	
	    	conn.setDoInput(true);
	    	conn.setDoOutput(true);
	    	conn.setUseCaches(false);
	    	
	    	conn.setRequestMethod("POST");
	    	conn.setRequestProperty("Connection", "Keep-Alive");
	        conn.setRequestProperty("Cache-Control", "no-cache");
	        conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
	
	        java.io.DataOutputStream request = new java.io.DataOutputStream(conn.getOutputStream());
	        
	        request.writeBytes(twoHyphens + boundary + crlf);
	        request.writeBytes("Content-Disposition: form-data; name=\"chat_id\""+ crlf);
	        request.writeBytes("Content-Type: text/plain; charset=UTF-8" + crlf);
	        request.writeBytes(crlf);
	        request.writeBytes(chatId+ crlf);
	        request.flush();
	        request.writeBytes(twoHyphens + boundary + crlf);
	        request.writeBytes("Content-Disposition: form-data; name=\"caption\""+ crlf);
	        request.writeBytes("Content-Type: text/plain; charset=UTF-8" + crlf);
	        request.writeBytes(crlf);
	        request.writeBytes(imagetrail+ crlf);
	        request.flush();
	        
	        String fileName = telegramImageToSend.getName();
	        request.writeBytes(twoHyphens + boundary + crlf);
	        request.writeBytes("Content-Disposition: form-data; name=\"photo\";filename=\"" +fileName + "\"" + crlf);
	        request.writeBytes(crlf);
	        byte[] bytes = java.nio.file.Files.readAllBytes(telegramImageToSend.toPath());
	        request.write(bytes);
	        request.writeBytes(crlf);
	        request.writeBytes(twoHyphens + boundary +twoHyphens + crlf);
	        request.flush();
	        request.close();
	    	
	    	int status = ((HttpURLConnection)conn).getResponseCode();
	    	if (status == HttpURLConnection.HTTP_OK) {
	    		System.out.println("---------------------------telegram Image msg send successfully--------------------------------------------------");
	    		conn.disconnect();
	    	}else {
	    		System.out.println("---------------------------telegram Image msg send unsuccessful*****--------------------------------------------------status:"+status+":"+((HttpURLConnection)conn).getResponseMessage());
	    	}
	    }
	    catch (Exception e)
	    {
	        e.printStackTrace();
	    }
	}


}
