package com.sharemarket.shailendra.finvasia;

import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.RepositoryClass;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.TelegramUtil;

import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PositionBookProcessor implements Runnable {
    private static final Logger logger = LogManager.getLogger(PositionBookProcessor.class);

    RequestBody body4position = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
    Request.Builder postRequest4positionBuilder = new Request.Builder()
            .url(RepositoryClass.positionbook)
            .method("POST", body4position)
            .addHeader("Content-Type", "application/json");
    
    Map<String, double[]> stplsmap = new HashMap<>();
	long telegramMsgId = 0l;
	
	boolean shutdownTodayDone = false;
    
	@Override
	public void run() {
		try {
			Calendar cal = Calendar.getInstance();
			if(CommonUtils.isTradingAllowedToday(cal)) {
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				int mn = cal.get(Calendar.MINUTE);
				boolean canrun = false;
				if(hr <= 8 && shutdownTodayDone == false) {
					if(TelegramUtil.sendTelegramMsgToChanel("Shutdown:", "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false))
						shutdownTodayDone = true;
				}
				if(hr > 8 && hr < 16) {
					if(hr ==9 && mn >14) {
						canrun = true;
					}else if(hr == 15 && mn < 30) {
						canrun = true;
					}else if(hr>9 && hr<15) {
						canrun = true;
					}
					shutdownTodayDone = true;
				}
				if(canrun) {
					try {
						Request postRequest4position = postRequest4positionBuilder.build();
			        	Response response = App.client.newCall(postRequest4position).execute();
			        	String responseBody = response.body().string();
			        	if(responseBody != null && responseBody.startsWith("[")) {
				            JSONArray jsonArr = new JSONArray(responseBody);
				            if(jsonArr != null) {
				            	Integer netQty = 0;
				                int ln=jsonArr.length();
				                StringBuffer bf = new StringBuffer();
				                //Map<String, double[]> stplsmaptemp = new HashMap<>();
				                for (int i=0; i<ln; i++) {
				                    JSONObject json = jsonArr.getJSONObject(i);
				                    netQty = Integer.valueOf(json.getString("netqty"));
				                    if(netQty > 0) {
				                    	String nm = json.getString("tsym").trim();
				                    	double [] sl = stplsmap.get(nm.toLowerCase());
										if(sl == null) {
											bf.append(nm+",");
										}else {
											Double ltp = Double.valueOf(json.getString("lp"));
											if(ltp<=sl[0] || ltp >= sl[2]) {
			    		                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
			    		                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+netQty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+nm+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
			    		                        Request postRequest4sale = new Request.Builder()
			    		                                .url("https://shoonyatrade.finvasia.com/NorenWClientTP/PlaceOrder")
			    		                                .method("POST", body4sale)
			    		                                .addHeader("Content-Type", "application/json").build();
			    		                        App.client.newCall(postRequest4sale).execute();
			    		                        TelegramUtil.sendTelegramMsgToChanel("PositionWatcher.Sale Order Placed now for:"+nm+",qty="+netQty, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);;
			    		                        if(nm.equalsIgnoreCase(FinvasiaAutoTrader.trackingscrip)) {
			    		                        	TelegramUtil.sendTelegramMsgToChanel("Stop:", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			    		                        	FinvasiaAutoTrader.trackingscrip = "";
			    		                        }
											}else if(ltp > (sl[0]+sl[1])) {
												sl[0] = ltp - sl[1];
												stplsmap.put(nm.toLowerCase(), sl);
												TelegramUtil.sendTelegramMsgToChanel("PositionWatcher.Trailing prc for:"+nm+",qty="+netQty+",stopls:"+sl[0]+",trailby:"+sl[1], "@Optionpositionwatcherchanel", "bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M", false);
											}else {
												//stplsmaptemp.put(nm.toLowerCase(), sl);
											}
										}
				                    }
				                }
				                //stplsmap = stplsmaptemp;
				                if(bf.length() > 0) {
				                	TelegramUtil.sendTelegramMsgToChanel("Pls provide stoploss detail for:"+bf.toString()+" in format:%0Astoplossdetail:%0Aoptioncode:stoploss:trailprice:targetprofitprice", "@Optionpositionwatcherchanel", "bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M", false);
				                }
				            }
			        	}
					}catch(Exception xx) {
						logger.error("position--", xx);
					}
					
					String commandfromtelegram = TelegramUtil.getLatestTelegramMsgFromChanel("bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M");
        	        //System.out.println("getLatestTelegramMsg====>"+commandfromtelegram);
	        		if(commandfromtelegram != null) {
	        			int xi = commandfromtelegram.indexOf("@@##@@");
	        			long telegramMsgIdcur = Long.valueOf(commandfromtelegram.substring(0, xi));
	        			if(telegramMsgIdcur > telegramMsgId) {
	        				telegramMsgId = telegramMsgIdcur;
		        			commandfromtelegram = commandfromtelegram.substring(xi+6);
		    				if(commandfromtelegram.startsWith("shutdown:") || commandfromtelegram.startsWith("Shutdown:")) {
		    					shutdownbox();
			        		}else if(commandfromtelegram.startsWith("clear:") || commandfromtelegram.startsWith("Clear:") || commandfromtelegram.startsWith("stop:") || commandfromtelegram.startsWith("Stop:") || commandfromtelegram.startsWith("ok:") || commandfromtelegram.startsWith("Ok:") || commandfromtelegram.startsWith("k:") || commandfromtelegram.startsWith("K:")) {
			        			stplsmap.clear();
			        		}
		    				else if(commandfromtelegram.startsWith("remove:") || commandfromtelegram.startsWith("Remove:")) {
		    					String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
		        				int ky = 0;
	        					for (String orddata : oderDetailArrfromtelegram) {
	        						if(ky > 0) {
		        						stplsmap.remove(orddata.toLowerCase());
	        						}
	        						ky++;
								}
		    				}
		    				else if(commandfromtelegram.startsWith("status:") || commandfromtelegram.startsWith("Status:")) {
		    					String watch = "%0AWatching:"+stplsmap.keySet().stream().collect(Collectors.joining(","));
		    					TelegramUtil.sendTelegramMsgToChanel("PositionWatcher is live!!!To Stop, msg 'clear' or to watch, Pls provide stoploss detail in format:%0Astoplossdetail:%0Aoptioncode:stoploss:trailprice:targetprofitprice. like:%0AStoplossdetail:%0ANIFTY29MAR23C17100:5.30:2%0AWIPRO27APR23C360:4.30:2"+watch, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
			        		}
		    				else if(commandfromtelegram.startsWith("stoplossdetail:") || commandfromtelegram.startsWith("Stoplossdetail:")) {
		    					String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
		        				Double stopls = 10.0;
		        				Double trailupby = 1000.0;
		        				double target = 1000.0;
		        				String ky = null;
	        					for (String orddata : oderDetailArrfromtelegram) {
	        						int inx = orddata.indexOf(':');
	        						int inxnxt = orddata.indexOf(':', inx+1);
	        						int inxlst = orddata.lastIndexOf(':');
	        						if(inxlst > inx) {
		        						ky = orddata.substring(0, inx);
		        						stopls = Double.valueOf(orddata.substring(inx+1, inxnxt).trim());
		        						trailupby = Double.valueOf(orddata.substring(inxnxt+1, inxlst).trim());
		        						target = Double.valueOf(orddata.substring(inxlst+1).trim());
		        						stplsmap.put(ky.toLowerCase(), new double[] {stopls, trailupby, target});
	        						}
								}
		    				}
	        			}
	        		}
				}
			}
		}catch(Exception px) {
			logger.error("position check", px);
		}
	}
	
	public void shutdownbox() throws Exception {
		TelegramUtil.sendTelegramMsgToChanel("ShutingDown!!!", "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
		 System.exit(0);
	}

}
