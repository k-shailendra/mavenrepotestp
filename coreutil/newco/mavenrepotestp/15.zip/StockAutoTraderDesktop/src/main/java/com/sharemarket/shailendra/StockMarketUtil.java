package com.sharemarket.shailendra;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class StockMarketUtil {
    public final static MediaType mediaType_JSON = MediaType.parse("application/json; charset=utf-8");
    public static OkHttpClient client = new OkHttpClient.Builder().hostnameVerifier(new HostnameVerifier() {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }).connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .build();
	
	public static Integer placeBuyOrderForLocalOrders(Double curValue, String scripToken, String loginToken, OrderDetailNew[] orders, int orderlength, boolean fakeorder, double[] saleprcdefault, double saleprcnthikedefault) throws Exception{
		Integer noLocalOrder = 0;
		if(fakeorder == false) {
			for(int i=0; i<orderlength; i++) {
				OrderDetailNew od = orders[i];
				if(od != null) {
					noLocalOrder = 1;
					//System.out.println(curValue+"<>"+od.getMxP()+":"+od.getMnP()+"->"+i);
					if(curValue <= od.getMxP() && curValue > od.getMnP()) {
						//String ordPrc = App.df.format(od.getMnP());
						String ord = "jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n" +
	                            "\"prc\":\""+curValue+"\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+od.getQty()+"\",\r\n\"trantype\":\"B\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken;
	                    RequestBody body4buy = RequestBody.create(ord, mediaType_JSON);
	                    Request.Builder postRequestBuilder4buy = new Request.Builder()
	                            .url(RepositoryClass.placeOrder)
	                            .method("POST", body4buy)
	                            .addHeader("Content-Type", "application/json");
	                    Request postRequest4buy = postRequestBuilder4buy.build();
	                    client.newCall(postRequest4buy).execute();
	                    orders[i] = null;
	                    curValue = curValue + (curValue * saleprcnthikedefault);
	                    if(saleprcdefault != null)
	                    	saleprcdefault[i] = curValue;
						for(int ix=i+1; ix<orderlength; ix++) {
							if(orders[ix] != null) {
								postRequest4buy = postRequestBuilder4buy.build();
								client.newCall(postRequest4buy).execute();
		                        orders[ix] = null;
			                    if(saleprcdefault != null)
			                    	saleprcdefault[ix] = curValue;
							}
						}
						noLocalOrder = 2;
						break;
					}
				}
			}
		}
		return noLocalOrder;
	}
	
    public static Integer loadPositionBook(String scripCodeStopLoss) throws Exception {
    	try {
    		return getPositionCount(scripCodeStopLoss);
    	}catch(Exception ig) {
    		try {
    			return getPositionCount(scripCodeStopLoss);
    		}catch(Exception px) {
    			px.printStackTrace();
    		}
    	}
    	return -1;
    }
    
    private static Integer getPositionCount(String scripCodeStopLoss) throws Exception {
    	Request postRequest4position = App.postRequest4positionBuilderFromUtil.build();
    	Response response = client.newCall(postRequest4position).execute();
    	String responseBody = response.body().string();
    	if(responseBody.startsWith("[")) {
            JSONArray jsonArr = new JSONArray(responseBody);
            if(jsonArr != null) {
            	Integer netQty = 0;
                int ln=jsonArr.length();
                for (int i=0; i<ln; i++) {
                    JSONObject json = jsonArr.getJSONObject(i);
                    netQty = Integer.valueOf(json.getString("netqty"));
                    if(netQty > 0) {
                    	String nm = json.getString("tsym").trim();
                    	if(nm.equalsIgnoreCase(scripCodeStopLoss)) {
                    		return netQty;
                    	}
                    }
                }
            }
    	}
    	return -1;
    }
	
    static RequestBody body4order = RequestBody.create("jData={\r\n\"uid\":\"FA66519\"\r\n}&jKey="+App.loginToken, mediaType_JSON); 
    static Request.Builder postRequest4orderBuilderFromUtil = new Request.Builder().url(RepositoryClass.orderbook).method("POST", body4order).addHeader("Content-Type", "application/json");
    
    public static List<String> getorderbookOrderNumber(String transactionTypeBuyOrSell) {
    	try {
            Request postRequest4order = postRequest4orderBuilderFromUtil.build();
            Response response = client.newCall(postRequest4order).execute();
            JSONArray jsonArr = new JSONArray(response.body().string());
            if(jsonArr != null) {
                int ln=jsonArr.length();
                List<String> exchangeOrdIdtmp = new ArrayList<>();
                for (int i=0; i<ln;i++) {
                    JSONObject json = jsonArr.getJSONObject(i);
                    String ttype = json.getString("trantype");
                    if(transactionTypeBuyOrSell.equals(ttype)) {
                    	exchangeOrdIdtmp.add(json.getString("norenordno"));
                    }
                }
                return exchangeOrdIdtmp;
            }
    	}catch(Exception x) {
    		x.printStackTrace();
    	}
    	return null;
    }
    
    public static void cancelAllOrder(List<String> exchangeOrdIds) {
    	try {
    		if(exchangeOrdIds != null) {
    			for (String id : exchangeOrdIds) {
    				RequestBody body4cancelorder = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"norenordno\":\""+id+"\"\r\n}&jKey="+App.loginToken, mediaType_JSON);
    	            Request postRequest4cancel = new Request.Builder()
    	                    .url(RepositoryClass.cancelorder)
    	                    .method("POST", body4cancelorder)
    	                    .addHeader("Content-Type", "application/json").build();
    	            client.newCall(postRequest4cancel).execute();
				}
    		}
    	}catch(Exception x) {
    		x.printStackTrace();
    	}
    }
    
    public static String calculateOptionExpiryDate() {
    	String xp = null;
    	try {
    		Calendar cal = Calendar.getInstance();
    		while(cal.get(Calendar.DAY_OF_WEEK) != Calendar.THURSDAY) {
    			cal.add(Calendar.DAY_OF_MONTH, 1);
    		}
    		int dt = cal.get(Calendar.DAY_OF_MONTH);
    		if(dt < 10)
    			xp = "0"+dt;
    		else
    			xp = ""+dt;
    		int mnth = cal.get(Calendar.MONTH);
    		switch(mnth) {
    			case 0:
    				xp = xp+"JAN";
    				break;
    			case 1:
    				xp = xp+"FEB";
    				break;
    			case 2:
    				xp = xp+"MAR";
    				break;
    			case 3:
    				xp = xp+"APR";
    				break;
    			case 4:
    				xp = xp+"MAY";
    				break;
    			case 5:
    				xp = xp+"JUN";
    				break;
    			case 6:
    				xp = xp+"JUL";
    				break;
    			case 7:
    				xp = xp+"AUG";
    				break;
    			case 8:
    				xp = xp+"SEP";
    				break;
    			case 9:
    				xp = xp+"OCT";
    				break;
    			case 10:
    				xp = xp+"NOV";
    				break;
    			case 11:
    				xp = xp+"DEC";
    				break;
    		}
    		xp = xp + (cal.get(Calendar.YEAR)+"").substring(2);	
    	}catch(Exception px) {
    		px.printStackTrace();
    	}
    	return xp;
    }

}
