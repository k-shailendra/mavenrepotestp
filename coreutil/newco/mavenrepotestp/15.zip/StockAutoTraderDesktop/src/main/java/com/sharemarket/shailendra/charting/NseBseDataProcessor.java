package com.sharemarket.shailendra.charting;

import java.io.InputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Version;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.ConstantScrips;
import com.sharemarket.shailendra.charting.ScripChartService.TodaysScripPriceCheckerExecutor;
import com.sharemarket.shailendra.utils.AlgoUtils;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.NSEBSEUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;

public class NseBseDataProcessor implements Runnable {
	Properties prop;
	Boolean canrunbulkdealdatafetch = true;
    private static final Logger logger = LogManager.getLogger(NseBseDataProcessor.class);
	
	public NseBseDataProcessor(Properties codeTokenMap) {
		this.prop = codeTokenMap;
	}
	
	@Override
	public void run() {
		try {
			logger.info("NSEBSE app---------------->");
			Calendar cal = Calendar.getInstance();
			if(CommonUtils.isTradingAllowedToday(cal)) {
				int min = cal.get(Calendar.MINUTE);
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				/*
				try {
		            if(hr == 9 || hr == 15) {
		            	for(int i=0; i< 30; i++) {
			            	if(min < 8) {
			            		Thread.sleep(60000);
			            	}
			            	if((min >= 8 && min < 22)) {
			            		if(hr == 15) {
			                    	ScripChartService.todaysScripPrcChange(4.8, false);
			                    }else {
			                    	ScripChartService.todaysScripPrcChange(0.7, true);
			                    }
			            	}
		            		cal = Calendar.getInstance();
		        			min = cal.get(Calendar.MINUTE);
		            	}
		            }
				}catch(Exception px) {
					px.printStackTrace();
				}
				*/
				
				try {
					if(hr <= 19)
						canrunbulkdealdatafetch = true;
					if(hr > 19 && canrunbulkdealdatafetch) {
						TelegramUtil.sendTelegramMsg("Starting bulk data picking......", "-446563244", false);
						NSEBSEUtil.processBulkDealFromNSEBSE();
						canrunbulkdealdatafetch = false;
						try {
					    	logger.info("-------------processFinancialResultsFromBSELiveDate---------------");
					    	ScripChartService.processFinancialResultsFromBSELiveDate(prop);
					    }catch(Exception ign) {
					    	logger.error("----->", ign);
					    }
					}
				}catch(Exception xp) {
					logger.error("----->", xp);
				}
				
				/*
				InputStream is = null;
			    try {
			    	CookieHandler.setDefault(new CookieManager());
			    	HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000)).version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault()).build();
	                java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
	                        .setHeader("Accept-Encoding", "deflate, br")
	                        .setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")//.setHeader("Connection", "keep-alive")
	                        //.setHeader("Host", "www.nseindia.com")
	                        .setHeader("Referer", "https://www.nseindia.com/")
	                        .setHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
	                        .setHeader("Accept",
	                                "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng;q=0.8,application/signed-exchange;v=b3;q=0.9")
	                        .setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(35000)).GET();
	                HttpResponse<String> rootSiteResp = client.send(_reqBuilder.uri(URI.create("https://www.nseindia.com/")).build(), HttpResponse.BodyHandlers.ofString());
	                if (rootSiteResp.statusCode() == 200) {
	                	String _rcddateurl = "https://www.nseindia.com/api/corporates-pit?";
	                	HttpResponse<String> resp = client.send(_reqBuilder.uri(URI.create(_rcddateurl)).build(), HttpResponse.BodyHandlers.ofString());
	                	if (resp.statusCode() == 200) {
	                		String sb = resp.body();
	        		    	JSONObject json = new JSONObject(sb);
	        		    	JSONArray  jar = json.getJSONArray("data");
	        		    	if(jar != null) {
	        		    		Map<String, Map<String, Integer>> scrpmap = new HashMap<>();
	        		    		for (int ix=0; ix<jar.length();ix++) {
	        		    			JSONObject insider = jar.getJSONObject(ix);
	        		    			String symbol = insider.getString("symbol");
	        		    			String date = insider.getString("date").substring(0, 10);
	        		    			String ttype = insider.getString("tdpTransactionType");
	        		    			int qty = Integer.valueOf(insider.getString("secAcq"));
	        		    			
	        		    			Map<String, Integer> dtmap = scrpmap.getOrDefault(symbol, new HashMap<String, Integer>());
	        		    			int count = dtmap.getOrDefault(date, 0);
	        		    			if("Sell".equalsIgnoreCase(ttype)) {
	        		    				count = count - qty;
	        		    			}else if("Buy".equalsIgnoreCase(ttype)) {
	        		    				count = count + qty;
	        		    			}
	        		    			dtmap.put(date, count);
	        		    			scrpmap.put(symbol, dtmap);
	        					}
	        		    		
	        		    		StringBuffer insiderT = new StringBuffer("InsiderTrade:%0A");
	        		    		
	        		    		for (Map.Entry<String,Map<String, Integer>> entryMap : scrpmap.entrySet()) {
	        		    			for (Map.Entry<String, Integer> entry : entryMap.getValue().entrySet()) {
	        		    				String symb = entryMap.getKey();
	        		    				String dt = entry.getKey();
	        		    				int qty = entry.getValue();
	        		    				if(prop.containsKey(symb)) {
	        		    					if(qty > 100000) {
	        		    						insiderT.append(dt+":"+symb+":"+qty+"%0A");
	        		    					}
	        		    				}else {
	        		    					if(qty > 300000) {
	        		    						insiderT.append(dt+":"+symb+":"+qty+"%0A");
	        		    					}
	        		    				}
	        			    		}
	        		    		}
	        		            try {
	        		            	if(insiderT.length() > 18)
	        		            		TelegramUtil.sendTelegramMsg(insiderT.toString(), "-485376339", false);
	        		            } catch (Exception _exp) {
	        		                System.out.println("ERROR#################Some issue 5paisa chart picker telegram msg for scrips sending.");
	        		                _exp.printStackTrace();
	        		            }
	        		    	}
	                	}
	                }
			    } catch(Exception ign) {
			    	ign.printStackTrace();
			    }
			    finally {
			      try { is.close(); }catch(Exception ig) {}
			    }
			    try {
			    	System.out.println("-------------processFinancialResultsFromBSELiveDate---------------");
			    	ScripChartService.processFinancialResultsFromBSELiveDate(prop);
			    }catch(Exception ign) {
			    	ign.printStackTrace();
			    }
			    */
			}else {
				System.out.println("------------------------------->Trading not allowed today:"+cal);
			}
		}catch(Throwable t) {
			t.printStackTrace();
		}
	}
	
	public static Set<String> getNse100ScripsName() {
		Set<String> snames = new HashSet<String>();
		try {
	    	CookieHandler.setDefault(new CookieManager());
	    	HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000)).version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault()).build();
            java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
                    .setHeader("Accept-Encoding", "deflate, br")
                    .setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")//.setHeader("Connection", "keep-alive")
                    //.setHeader("Host", "www.nseindia.com")
                    .setHeader("Referer", "https://www.nseindia.com/")
                    .setHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
                    .setHeader("Accept",
                            "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
                    .setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(35000)).GET();
            HttpResponse<String> rootSiteResp = client.send(_reqBuilder.uri(URI.create("https://www.nseindia.com/")).build(), HttpResponse.BodyHandlers.ofString());
            if (rootSiteResp.statusCode() == 200) {
            	String _rcddateurl = "https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%20100";
                HttpResponse<String> resp = client.send(_reqBuilder.uri(URI.create(_rcddateurl)).build(), HttpResponse.BodyHandlers.ofString());
                if (resp.statusCode() == 200) {
            		String sb = resp.body();
    		    	JSONObject json = new JSONObject(sb);
    		    	JSONArray  jar = json.getJSONArray("data");
    		    	if(jar != null) {
    		    		for (int ix=0; ix<jar.length();ix++) {
    		    			JSONObject insider = jar.getJSONObject(ix);
    		    			String symbol = insider.getString("symbol");
    		    			if("NIFTY 100".equals(symbol) == false)
    		    				snames.add(symbol);
    		    		}
    		    	}
                }
            }
		}catch(Exception px) {
			
		}
		return snames;
	}

}
