package com.sharemarket.shailendra.finvasia;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.ConstantScrips;
import com.sharemarket.shailendra.RepositoryClass;
import com.sharemarket.shailendra.StockMarketUtil;
import com.sharemarket.shailendra.utils.AlgoUtils;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;

import okhttp3.Request;
import okhttp3.RequestBody;

public class FinvasiaAlgoCalculator4OptionNifty implements Runnable {
    private static final Logger logger = LogManager.getLogger(FinvasiaAlgoCalculator.class);
	String algoName;
	Map<String, String> codeTokenMap;
	Integer candleTime;
	Integer dataPickGapInMonth;
	String telegramchanelId;
	boolean pricevolumecheck = false;
	Map<String, String> codeTokenMapForLowerTimeCandle;
	String telegramTitle;
	
	long telegramMsgId = 0;
	
	FinvasiaAutoTrader finvasiaAutoTrader = null;
	double stplsprcnt = 0.06;
	double buyprcmnsprcnt = 0.05;
	int waittime = 2;
	
	public FinvasiaAlgoCalculator4OptionNifty(String algoName, Map<String, String> codeTokenMap, Integer candleTime, Integer dataPickGapInMonth, String telegramchanelId, String telegramTitle, Map<String, String> codeTokenMapForLowerTimeCandle, boolean pricevolumecheck, FinvasiaAutoTrader autotrader, double stplsprcnt, double buyprcmnsprcnt, int waittime) {
		this.algoName = algoName;
		this.codeTokenMap = codeTokenMap;
		this.candleTime = candleTime;
		this.dataPickGapInMonth = dataPickGapInMonth;
		this.telegramchanelId = telegramchanelId;
		this.telegramTitle = telegramTitle;
		this.codeTokenMapForLowerTimeCandle = codeTokenMapForLowerTimeCandle;
		this.pricevolumecheck = pricevolumecheck;
		
		this.finvasiaAutoTrader = autotrader;
		this.buyprcmnsprcnt = buyprcmnsprcnt;
		this.stplsprcnt = stplsprcnt;
		this.waittime = waittime;
	}
	
	@Override
	public void run() {
		try {
			Calendar cal = Calendar.getInstance();
			if(CommonUtils.isTradingAllowedToday(cal)) {
				int mn = cal.get(Calendar.MINUTE);
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				boolean canrun = false;
				if(hr > 8 && hr < 16) {
					if(hr ==9 && mn >14) {
						canrun = true;
					}else if(hr == 15 && mn < 16) {
						canrun = true;
					}else if(hr>9 && hr<15) {
						canrun = true;
					}
				}
				if(canrun) {
					 //nifty option trade
					Iterator<Entry<String, String>> codeTokenitrt = codeTokenMap.entrySet().iterator();
					while(codeTokenitrt.hasNext()) {
						Entry<String, String> entry = codeTokenitrt.next();
						if("Fakeorder".equalsIgnoreCase(entry.getKey()) == false) {
							String nOptioncut = entry.getKey().substring(11);
							if(FinvasiaAutoTrader.trackingscrip.length() < 2) {
								try {
									checkandplaceorder(nOptioncut, entry.getValue(), entry.getKey(), stplsprcnt, buyprcmnsprcnt, codeTokenMap.containsKey("Fakeorder"), 300, 50);
								}catch(Exception px) {
									logger.error("some issue in order creation--->", px);
								}
							}
						}
					}
				}
			}
		}catch(Throwable t) {
			logger.error(t);
		}
	}
	
	private void checkandplaceorder(String nOptioncut, String niftytoken, String niftyscrip, double stplsprcnt, double buyprcmnsprcnt, boolean fakeorder, int totQtyy, int trailQty) throws Exception {
		boolean orderplaced = false;
		Calendar cal = Calendar.getInstance();
		Long endTimeInSec = cal.getTimeInMillis()/1000;
		cal.add(Calendar.MONTH, dataPickGapInMonth*-1);
		Long stTimeInSec = cal.getTimeInMillis()/1000;
		
		String dataresp = FinvasiaUtil.getTimeSeriesData(stTimeInSec, endTimeInSec, niftytoken, candleTime, "NFO");
		JSONArray jsonA = new JSONArray(dataresp);
		JSONObject obj = jsonA.getJSONObject(1);
		Double p1 = obj.getDouble("intc");
		Double o1 = obj.getDouble("into");
		JSONObject obj2 = jsonA.getJSONObject(2);
		Double p2 = obj2.getDouble("intc");
		Double o2 = obj2.getDouble("into");
		JSONObject obj3 = jsonA.getJSONObject(3);
		Double p3 = obj3.getDouble("intc");
		Double o3 = obj3.getDouble("into");
		
		JSONObject obj4 = jsonA.getJSONObject(4);
		Double p4 = obj4.getDouble("intc");
		Double o4 = obj4.getDouble("into");
		
		JSONObject obj5 = jsonA.getJSONObject(5);
		Double p5 = obj5.getDouble("intc");
		Double o5 = obj5.getDouble("into");
		
		JSONObject obj0 = jsonA.getJSONObject(0);
		double h0 = obj0.getDouble("inth");
		double l0 = obj0.getDouble("intl");
		double o0 = obj0.getDouble("into");
		double c0 = obj0.getDouble("intc");
		boolean isapply = false;
		if((o1>p1&&o2>p2&&o3>p3&&o4>p4) || ((((h0 - l0)/h0)*100) > 15))
			isapply = true;
		try {
			if(o0>c0) {
				if(isapply){
					double d = h0-o0;
					double d1 = c0-l0;
					if((d1/1.5 > (o0-c0))&& (d < (o0-c0))) {
						orderplaced = true;
						placeorder(niftyscrip, niftytoken, this.telegramTitle+":HAMMER", stplsprcnt, buyprcmnsprcnt, fakeorder, totQtyy, trailQty);
					}
				}
			}else {
				if(isapply){
					if(c0 > ((o1+p1)/2)) {
						orderplaced = true;
						placeorder(niftyscrip, niftytoken, this.telegramTitle+"MayUp", stplsprcnt, buyprcmnsprcnt, fakeorder, totQtyy, trailQty);
					}
				} 
			}
		}catch(Exception px) {
			logger.error("****************************ISSUE from order**************************", px);
		}
		
		
		if(orderplaced == false && pricevolumecheck) {
    		long intv1 = obj.getLong("intv");

    		long intv2 = obj2.getLong("intv");
    		Double l2 = obj2.getDouble("intl");

    		long intv3 = obj3.getLong("intv");
    		Double l3 = obj3.getDouble("intl");
    		String msg = null;
    		if(nOptioncut.contains("c")||nOptioncut.contains("C")) {
        		if((intv3 > intv2*1.3) && (intv2 > intv1*1.26)) {
        			if(p1<p2&&p1<l2&&p2<p3&&p2<l3&&(o1>p1)&&(o2>p2)&&(o3>p3)) {
        				msg = "p1p2p3";
        			}
        		}
        		if(msg == null) {
            		long intv4 = obj4.getLong("intv");
            		Double l4 = obj4.getDouble("intl");
            		if((intv4 > intv3*1.3) && (intv3 > intv2*1.26)) {
            			if(p2<p3&&p2<l3&&p3<p4&&p3<l4&&(o2>p2)&&(o3>p3)&&(o4>p4)) {
            				msg = "p2p3p4";
            			}
            		}
            		if(msg == null) {
                		long intv5 = obj5.getLong("intv");
                		if((intv5 > intv4) && (intv4 > intv3) && ((intv3 > intv2)||(intv3 < intv2)) && (intv2 > intv1)) {
                			if(p1<p2&&p2<p3&&p3<p4&&p4<p5&&(o1>p1)&&(o2>p2)&&(o3>p3)&&(o4>p4)&&(o5>p5)) {
                				msg = "p1p2p3p4p5";
                			}
                		}
            		}
        		}
    		}else if(nOptioncut.contains("p")||nOptioncut.contains("P")) {
        		if((intv1 > intv2*1.3) && (intv2 > intv3*1.26)) {
        			if(p1<p2&&p1<l2&&p2<p3&&p2<l3&&(o1>p1)&&(o2>p2)&&(o3>p3)) {
        				msg = "p1p2p3";
        			}
        		}
        		if(msg == null) {
            		long intv4 = obj4.getLong("intv");
            		Double l4 = obj4.getDouble("intl");
            		if((intv2 > intv3*1.3) && (intv3 > intv4*1.26)) {
            			if(p2<p3&&p2<l3&&p3<p4&&p3<l4&&(o2>p2)&&(o3>p3)&&(o4>p4)) {
            				msg = "p2p3p4";
            			}
            		}
            		if(msg == null) {
                		long intv5 = obj5.getLong("intv");
                		if((intv5 < intv4) && (intv4 < intv3) && ((intv3 < intv2) || (intv3 > intv2)) && (intv2 < intv1)) {
                			if(p1<p2&&p2<p3&&p3<p4&&p4<p5&&(o1>p1)&&(o2>p2)&&(o3>p3)&&(o4>p4)&&(o5>p5)) {
                				msg = "p1p2p3p4p5";
                			}
                		}
            		}
        		}
    		}
    		obj = jsonA.getJSONObject(0);
    		Double p = obj.getDouble("intc");
    		Double o = obj.getDouble("into");
    		if(p > o && p > p1 && msg != null) {
    			orderplaced = true;
    			placeorder(niftyscrip, niftytoken, this.telegramTitle+msg, stplsprcnt, buyprcmnsprcnt, fakeorder, totQtyy, trailQty);
    		}
		}
		
		if(orderplaced == false && "TEMA".equals(algoName)) {
			if((p1<p2&&p2<p3&&(o1>p1)&&(o2>p2)&&(o3>p3)) || (p1<p2&&p2<o3&&p3<p4&&p4<p5&&(o1>p1)&&(p2>o2)&&(o3>p3)&&(o4>p4)&&(o5>p5))) {
				List<Double> clsarr = new ArrayList<>();
	        	List<Double> lowarr = new ArrayList<>();
	        	List<Double> clsarr1 = new ArrayList<>();
	        	for(int i = jsonA.length() -1; i>-1; i--) {
	        		obj = jsonA.getJSONObject(i);
	        		Double cl = obj.getDouble("intc");
	        		clsarr.add(cl);
	        		lowarr.add(obj.getDouble("intl"));
	        		clsarr1.add(cl);
	        	}
	        	int ln = clsarr.size();
	        	Double clsprc = clsarr.get(ln-1);								            	
	        	clsarr = AlgoUtils.calculateEMA(4, clsarr);
	        	lowarr = AlgoUtils.calculateEMA(22, lowarr);
	        	clsarr1 = AlgoUtils.calculateEMA(11, clsarr1);
	        	
	        	ln = clsarr.size();
	            	Double em1cls = clsarr.get(ln-1);
	            	Double em1clsprev = clsarr.get(ln-2);
	            	Double em11clsprev = clsarr.get(ln-3);
	            	ln = lowarr.size();
	            	Double em1lwr = lowarr.get(ln-1);
	            	Double em1lwrprev = lowarr.get(ln-2);
	            	ln = clsarr1.size();
	            	Double em1high = clsarr1.get(ln-1);
	            	Double em1highprev = clsarr1.get(ln-2);
	            	
	            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
	            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
	            	clsarr1 = AlgoUtils.calculateEMA(11, clsarr1);
	            	
	            	ln = clsarr.size();
	            	Double em2cls = clsarr.get(ln-1);
	            	Double em2clsprev = clsarr.get(ln-2);
	            	Double em22clsprev = clsarr.get(ln-3);
	            	ln = lowarr.size();
	            	Double em2lwr = lowarr.get(ln-1);
	            	Double em2lwrprev = lowarr.get(ln-2);
	            	ln = clsarr1.size();
	            	Double em2high = clsarr1.get(ln-1);
	            	Double em2highprev = clsarr1.get(ln-2);
	            	
	            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
	            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
	            	clsarr1 = AlgoUtils.calculateEMA(11, clsarr1);
	            	
		        	ln = clsarr.size();
		        	int j = lowarr.size()-6;
		        	boolean canproceed = true;
		        	for(int i=ln-6; i<ln; i++) {
		        		Double lc = clsarr.get(i);
		        		Double ll = lowarr.get(j);
		        		if(lc > ll) {
		        			canproceed = false;
		        			break;
		        		}
		        		j++;
		        	}
		        	if(canproceed) {
		            	ln = clsarr.size();
		            	Double em3cls = clsarr.get(ln-1);
		            	Double em3clsprev = clsarr.get(ln-2);
		            	Double em33clsprev = clsarr.get(ln-3);
		            	ln = lowarr.size();
		            	Double em3lwr = lowarr.get(ln-1);
		            	Double em3lwrprev = lowarr.get(ln-2);
		            	ln = clsarr1.size();
		            	Double em3high = clsarr1.get(ln-1);
		            	Double em3highprev = clsarr1.get(ln-2);
		            	
		            	Double tema1 = (3*em1cls) - (3*em2cls) + em3cls;
		            	Double tema1prev = (3*em1clsprev) - (3*em2clsprev) + em3clsprev;
		            	Double tema11prev = (3*em11clsprev) - (3*em22clsprev) + em33clsprev;
		            	Double tema2 = (3*em1lwr) - (3*em2lwr) + em3lwr;
		            	Double tema2prev = (3*em1lwrprev) - (3*em2lwrprev) + em3lwrprev;
		            	Double tema3 = (3*em1high) - (3*em2high) + em3high;
		            	Double tema3prev = (3*em1highprev) - (3*em2highprev) + em3highprev;
		            	
		            	if(tema1prev < tema2prev && tema1 > tema1prev && tema1 > tema2) {
		            		placeorder(niftyscrip, niftytoken, this.telegramTitle+"4c-22l", stplsprcnt, buyprcmnsprcnt, fakeorder, totQtyy, trailQty);
		            	}else if(tema1prev < tema3prev && tema1 > tema1prev && tema1 > tema3) {
		            		placeorder(niftyscrip, niftytoken, this.telegramTitle+"4c-11c", stplsprcnt, buyprcmnsprcnt, fakeorder, totQtyy, trailQty);
		            	}
		        	}
			}
		}
	}
	
	private void placeorder(String niftyscrip, String niftytoken, String telemsg, double stplsprcnt, double buyprcmnsprcnt, boolean fakeorder, int totqty, int trailQty) throws Exception {
		Double buyprc = -1.0;
		try {
			buyprc = FinvasiaUtil.getLTPValueOf(niftytoken, "NFO");
			buyprc = buyprc - buyprc*buyprcmnsprcnt;
		}catch(Exception px) { logger.error("issue----", px); }
		Double stpls = buyprc - buyprc*stplsprcnt;
		Double trlupby = buyprc - stpls;
		Double trlupbysml = trlupby/1.7;
		FinvasiaAutoTrader.trackingscrip = niftyscrip;
		
		Double saleprcnthikedefault = App.PRCENTHIKE;//(stplsprcnt/(totqty/trailQty));
		if(saleprcnthikedefault == null || saleprcnthikedefault < 0.015) {
			saleprcnthikedefault = 0.017;
			if(fakeorder == false)
				finvasiaAutoTrader.placeOrder(niftyscrip, totqty, buyprc, stpls, trlupby, trlupbysml, trailQty, this.waittime, niftytoken, fakeorder, saleprcnthikedefault, App.APPROACH);
		}else {
			if(fakeorder == false)
				finvasiaAutoTrader.placeOrder(niftyscrip, totqty, buyprc, stpls, trlupby, trlupbysml, trailQty, this.waittime, niftytoken, fakeorder, saleprcnthikedefault, App.APPROACH);
		}
		
		TelegramUtil.sendTelegramMsgToChanel("OrderPlaced:%0AStartWebSocket:%0AScrip:"+niftyscrip+"%0AWaittime:"+this.waittime+"%0ABuyPrice:"+App.df.format(buyprc)+"%0ATotalQty:"+totqty+"%0ATrailQty:"+trailQty+"%0AStoploss:"+App.df.format(stpls)+"%0ATrailUpBy:"+App.df.format(trlupby)+"%0ATrailUpBysmall:"+App.df.format(trlupbysml)+"%0Aapproach:"+App.APPROACH+"%0APrcentHike:"+saleprcnthikedefault, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
		TelegramUtil.sendTelegramMsgToChanel(telemsg, "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
	}
	
	private void onPricecandle() throws Exception {
		boolean orderplaced = false;
		/*
		if(temp.equalsIgnoreCase(time)) {
			Double low = obj.getDouble("intl");
			Double cprc = obj.getDouble("intc");
			Double opn = obj.getDouble("into");
			if(opn == low &&  opn < cprc) {
				Double buyprc = -1.0;
				try {
					buyprc = FinvasiaUtil.getLTPValueOf(entry.getValue(), "NFO");
				}catch(Exception px) { logger.error("issue----", px); }
				Double stpls = buyprc - buyprc*0.05;
				//if(opn > stpls)
					//stpls = opn;
				Double trlupby = buyprc - stpls;
				Double trlupbysml = trlupby/1.7;
				FinvasiaAutoTrader.trackingscrip = entry.getKey();
				orderplaced = true;
				finvasiaAutoTrader.placeOrder(entry.getKey(), 150, buyprc, stpls, trlupby, trlupbysml, 50, 2, entry.getValue());
				TelegramUtil.sendTelegramMsgToChanel("Ccandle order placed with scrip="+entry.getKey()+",TotalQty=150,TrailQty:50%0ABuyPrice="+buyprc+",Stoploss:"+stpls+",TrailUpBy:"+trlupby+",TrailUpBysmall:"+trlupbysml+",Waittime:2min", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			}
		}
		if(orderplaced == false) {
			JSONObject objprev = jsonA.getJSONObject(1);
			Double oprev = objprev.getDouble("into");
			Double cprc = obj.getDouble("intc");
			if(obj.getDouble("into") < cprc) {
				if(objprev.getDouble("intc") == objprev.getDouble("inth")) {
					Double buyprc = -1.0;
					try {
						buyprc = FinvasiaUtil.getLTPValueOf(entry.getValue(), "NFO");
					}catch(Exception px) { logger.error("issue----", px); }
					Double stpls = buyprc - buyprc*0.05;
					//if(oprev > stpls)
						//stpls = oprev;
					Double trlupby = buyprc - stpls;
					Double trlupbysml = trlupby/1.7;
					FinvasiaAutoTrader.trackingscrip = entry.getKey();
					//finvasiaAutoTrader.placeOrder(entry.getKey(), 150, buyprc, stpls, trlupby, trlupbysml, 50, 2, entry.getValue());
					TelegramUtil.sendTelegramMsgToChanel("Pcandle order placed with scrip="+entry.getKey()+",TotalQty=150,TrailQty:50%0ABuyPrice="+buyprc+",Stoploss:"+stpls+",TrailUpBy:"+trlupby+",TrailUpBysmall:"+trlupbysml+",Waittime:2min", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				}else if((oprev == objprev.getDouble("intl") && oprev < objprev.getDouble("intc"))) {
					Double buyprc = -1.0;
					try {
						buyprc = FinvasiaUtil.getLTPValueOf(entry.getValue(), "NFO");
					}catch(Exception px) { logger.error("issue----", px); }
					Double stpls = buyprc - buyprc*0.05;
					//if(oprev > stpls)
						//stpls = oprev;
					Double trlupby = buyprc - stpls;
					Double trlupbysml = trlupby/1.7;
					FinvasiaAutoTrader.trackingscrip = entry.getKey();
					//finvasiaAutoTrader.placeOrder(entry.getKey(), 150, buyprc, stpls, trlupby, trlupbysml, 50, 2, entry.getValue());
					TelegramUtil.sendTelegramMsgToChanel("Phcandle order placed with scrip="+entry.getKey()+",TotalQty=150,TrailQty:50%0ABuyPrice="+buyprc+",Stoploss:"+stpls+",TrailUpBy:"+trlupby+",TrailUpBysmall:"+trlupbysml+",Waittime:2min", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
				}
			}
		}
		*/
	}

}
