package com.sharemarket.shailendra.finvasia;

import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.RepositoryClass;
import com.sharemarket.shailendra.StockMarketUtil;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.TelegramUtil;

import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PositionBookProcessor implements Runnable {
    private static final Logger logger = LogManager.getLogger(PositionBookProcessor.class);

    RequestBody body4position = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
    Request.Builder postRequest4positionBuilder = new Request.Builder()
            .url(RepositoryClass.positionbook)
            .method("POST", body4position)
            .addHeader("Content-Type", "application/json");
    
    Map<String, double[]> stplsmap = new HashMap<>();
    Map<String, Long> stplsmapWaitTime = new HashMap<>();
    Map<String, List<String>> sellOrderMap = null;
	long telegramMsgId = 0l;
	
	private int counting = 0;
	
	boolean shutdownTodayDone = false;
    
	@Override
	public void run() {
		try {
			Calendar cal = Calendar.getInstance();
			if(CommonUtils.isTradingAllowedToday(cal)) {
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				int mn = cal.get(Calendar.MINUTE);
				boolean canrun = false;
				if(hr <= 8 && shutdownTodayDone == false) {
					if(TelegramUtil.sendTelegramMsgToChanel("Shutdown:", "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false))
						shutdownTodayDone = true;
				}
				if(hr > 8 && hr < 16) {
					if(hr ==9 && mn >14) {
						canrun = true;
					}else if(hr == 15 && mn < 30) {
						canrun = true;
					}else if(hr>9 && hr<15) {
						canrun = true;
					}
					shutdownTodayDone = true;
				}
				if(canrun) {
					List<String> checkOrderBookFor = new java.util.ArrayList<>();
					String responseBody = null;
					try {
						Request postRequest4position = postRequest4positionBuilder.build();
			        	Response response = App.client.newCall(postRequest4position).execute();
			        	responseBody = response.body().string();
			        	if(responseBody != null && responseBody.startsWith("[")) {
				            JSONArray jsonArr = new JSONArray(responseBody);
				            if(jsonArr != null) {
				            	Integer netQty = 0;
				                int ln=jsonArr.length();
				                boolean ismissingStpLoss = false;
				                StringBuffer bf = new StringBuffer();
				                bf.append("%0Astoplossdetail:");
				                //Map<String, double[]> stplsmaptemp = new HashMap<>();
				                for (int i=0; i<ln; i++) {
				                    JSONObject json = jsonArr.getJSONObject(i);
				                    netQty = Integer.valueOf(json.getString("netqty"));
				                    if(netQty > 0) {
				                    	String nm = json.getString("tsym").trim();
				                    	Double ltp = Double.valueOf(json.getString("lp"));
				                    	double [] sl = stplsmap.get(nm.toLowerCase());
										if(sl == null) {
											bf.append("%0A"+nm+":"+App.df.format(ltp-1)+":0.7:"+App.df.format(ltp+2.8)+"=3");
											ismissingStpLoss = true;
										}else {
											if(ltp<=sl[0] || ltp >= sl[2]) {
												try {
													if(sellOrderMap != null) {
														List<String> saleIds = sellOrderMap.get(nm);
														if(saleIds != null)
															StockMarketUtil.cancelAllOrder(saleIds);
													}
												}catch(Exception tx) {
													tx.printStackTrace();
												}
												
			    		                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
			    		                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+netQty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+nm+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
			    		                        Request postRequest4sale = new Request.Builder()
			    		                                .url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
			    		                                .method("POST", body4sale)
			    		                                .addHeader("Content-Type", "application/json").build();
			    		                        App.client.newCall(postRequest4sale).execute();
			    		                        TelegramUtil.sendTelegramMsgToChanel("PositionWatcher.Sale Order Placed now for:"+nm+",qty="+netQty, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);;
			    		                        if(nm.equalsIgnoreCase(FinvasiaAutoTrader.trackingscrip)) {
			    		                        	TelegramUtil.sendTelegramMsgToChanel("Stop:", "@Option2playChanel", "bot6213071043:AAGnTfXkCZZrFvgZM1z_dMpJ45_lb2Eud9s", false);
			    		                        	FinvasiaAutoTrader.trackingscrip = "";
			    		                        }
											}else {
												long waitTime = stplsmapWaitTime.get(nm.toLowerCase());
												long curTime = cal.getTimeInMillis();
												if(((curTime+60*1000) > waitTime) && (netQty < 1)) {
													stplsmapWaitTime.remove(nm.toLowerCase());
													stplsmap.remove(nm.toLowerCase());
													TelegramUtil.sendTelegramMsgToChanel("PositionWatcher.Removed scrip:"+nm+",qty="+netQty+",stopls:"+sl[0]+",trailby:"+sl[1], "@Optionpositionwatcherchanel", "bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M", false);
												}else if(curTime > waitTime && (ltp > (sl[0]+sl[1]))) {
													sl[0] = ltp - sl[1];
													stplsmap.put(nm.toLowerCase(), sl);
													TelegramUtil.sendTelegramMsgToChanel("PositionWatcher.Trailing prc for:"+nm+",qty="+netQty+",stopls:"+sl[0]+",trailby:"+sl[1], "@Optionpositionwatcherchanel", "bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M", false);
												}
											}
										}
				                    	checkOrderBookFor.add(nm);
				                    }
				                }
				                //stplsmap = stplsmaptemp;
				                if(ismissingStpLoss) {
				                	TelegramUtil.sendTelegramMsgToChanel("Pls provide stoploss for:"+bf.toString(), "@Optionpositionwatcherchanel", "bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M", false);
				                }
				            }
			        	}
					}catch(Exception xx) {
						logger.error("position--", xx);
					}
					
					if(counting > 1)
						counting = 0;
					if(counting < 1) {
						sellOrderMap = StockMarketUtil.getorderbookOrderNumberOfScrips("S", checkOrderBookFor);
					}
					counting = counting + 1;
					String commandfromtelegram = TelegramUtil.getLatestTelegramMsgFromChanel("bot5725176452:AAHeFeqJnD0h0T1QRiZOG7YBclNt5u7Ay5M");
        	        System.out.println(responseBody+" position getLatestTelegramMsg====>"+commandfromtelegram);
	        		if(commandfromtelegram != null) {
	        			int xi = commandfromtelegram.indexOf("@@##@@");
	        			long telegramMsgIdcur = Long.valueOf(commandfromtelegram.substring(0, xi));
	        			if(telegramMsgIdcur > telegramMsgId) {
	        				telegramMsgId = telegramMsgIdcur;
		        			commandfromtelegram = commandfromtelegram.substring(xi+6);
		    				if(commandfromtelegram.startsWith("shutdown:") || commandfromtelegram.startsWith("Shutdown:")) {
		    					shutdownbox();
			        		}else if(commandfromtelegram.startsWith("clear:") || commandfromtelegram.startsWith("Clear:") || commandfromtelegram.startsWith("stop:") || commandfromtelegram.startsWith("Stop:") || commandfromtelegram.startsWith("ok:") || commandfromtelegram.startsWith("Ok:") || commandfromtelegram.startsWith("k:") || commandfromtelegram.startsWith("K:")) {
			        			stplsmap.clear();
			        		}
		    				else if(commandfromtelegram.startsWith("remove:") || commandfromtelegram.startsWith("Remove:")) {
		    					String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
		        				int ky = 0;
	        					for (String orddata : oderDetailArrfromtelegram) {
	        						if(ky > 0) {
		        						stplsmap.remove(orddata.toLowerCase());
	        						}
	        						ky++;
								}
		    				}
		    				else if(commandfromtelegram.startsWith("status:") || commandfromtelegram.startsWith("Status:")) {
		    					String watch = "%0AWatching:"+stplsmap.keySet().stream().collect(Collectors.joining(","));
		    					TelegramUtil.sendTelegramMsgToChanel("PositionWatcher is live!!!To Stop, msg 'clear' or to watch, Pls provide stoploss detail in format:%0Astoplossdetail:%0Aoptioncode:stoploss:trailprice:targetprofitprice=waittimeinmin. like:%0AStoplossdetail:%0ANIFTY29MAR23C17100:5.30:2=2%0AWIPRO27APR23C360:4.30:2=5"+watch, "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
			        		}
		    				else if(commandfromtelegram.startsWith("stoplossdetail:") || commandfromtelegram.startsWith("Stoplossdetail:")) {
		    					String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
		        				Double stopls = 10.0;
		        				Double trailupby = 1000.0;
		        				double target = 1000.0;
		        				String ky = null;
	        					for (String orddata : oderDetailArrfromtelegram) {
	        						int inx = orddata.indexOf(':');
	        						int inxlst = orddata.lastIndexOf(':');
	        						if(inxlst > inx) {
		        						int inxnxt = orddata.indexOf(':', inx+1);
	        							int inxwttime = orddata.lastIndexOf('=');
	        							if(inxwttime < 1) {
	        								stplsmapWaitTime.put(ky.toLowerCase(), (cal.getTimeInMillis() + 300000));
	        							}else {
	        								Long waitTime = cal.getTimeInMillis() + (1000*60*Integer.valueOf(orddata.substring(inxwttime+1).trim()));
	        								stplsmapWaitTime.put(ky.toLowerCase(), waitTime);
	        							}
		        						
		        						ky = orddata.substring(0, inx);
		        						stopls = Double.valueOf(orddata.substring(inx+1, inxnxt).trim());
		        						trailupby = Double.valueOf(orddata.substring(inxnxt+1, inxlst).trim());
		        						target = Double.valueOf(orddata.substring(inxlst+1, inxwttime).trim());
		        						stplsmap.put(ky.toLowerCase(), new double[] {stopls, trailupby, target});
	        						}
								}
		    				}
	        			}
	        		}
				}
			}
		}catch(Exception px) {
			logger.error("position check", px);
		}
	}
	
	public void shutdownbox() throws Exception {
		TelegramUtil.sendTelegramMsgToChanel("ShutingDown!!!", "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);
		 System.exit(0);
	}

}
