package com.sharemarket.shailendra.charting;

import java.net.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Version;
import java.text.SimpleDateFormat;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.DefaultResourceCache;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.cos.COSObject;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.documentinterchange.markedcontent.PDPropertyList;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.color.PDColorSpace;
import org.apache.pdfbox.pdmodel.graphics.pattern.PDAbstractPattern;
import org.apache.pdfbox.pdmodel.graphics.shading.PDShading;
import org.apache.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.ConstantScrips;
import com.sharemarket.shailendra.utils.TelegramUtil;
public class ScripChartService {
	public void pickAndSendScripChart() throws Exception {
		System.out.println("------------calling pickAndSendScripChart--------");
		Properties propconfig = new Properties();
		propconfig.put("geckodriverlocation", "D:\\\\chhuimui\\\\selenium\\\\geckodriver.exe");
		propconfig.put("firefoxlocation", "C:\\\\Program Files\\\\Mozilla Firefox\\\\firefox.exe");
		propconfig.put("firefoxprofilewithlocation",
				"D:\\\\chhuimui\\\\selenium\\\\firefox5paisaprofiles\\\\hour4Min15");
		propconfig.put("firefoxprofilewithlocation1day", "D:\\\\chhuimui\\\\selenium\\\\firefox5paisaprofiles\\\\day1");
		propconfig.put("firefoxprofilewithlocation1week",
				"D:\\\\chhuimui\\\\selenium\\\\firefox5paisaprofiles\\\\week1");
		propconfig.put("awsserverurl", "https://real-nails-add-103-70-80-30.loca.lt/api/scrips/chart");
		propconfig.put("charturl",
				"https://charts.5paisa.com/ChartIq_Sw/advance.html?type=overview&period=1&range=d&appName=5PTRADES&appVer=5.11.0.0&osName=TTWEB&exchange=nse&exchType=C&symbol=?symbol&scripCode=?scripcode&loginId=?loginid");
		Properties prop = new Properties();
		prop.putAll(ConstantScrips.scripsMap);
		// String scripFor15Mins = calculate1DayEMACalculation(prop);
		// calculate15MinEMACalculation(prop, scripFor15Mins);
		// InsiderTradeExecutor insdrtemp = new InsiderTradeExecutor(prop);
		// new Thread(insdrtemp).start();
		// For execution
		int runcnt = 0;
		String scripFor15MinMidDay = null;
		for (; runcnt < 10000; runcnt++) {
			// any new scrip addition from telegram
			try {
				String scripcodefromtelegram = TelegramUtil.getLatestTelegramMsgFromGroup("-753403607");
				if (scripcodefromtelegram != null) {
					if (scripcodefromtelegram.contains("#") == true && scripcodefromtelegram.contains("@") == true) {
						String[] scripcodeArrfromtelegram = scripcodefromtelegram.split("\n");
						if (scripcodeArrfromtelegram != null) {
							for (String scripwithisin : scripcodeArrfromtelegram) {
								int inx = scripwithisin.indexOf('@');
								String name = scripwithisin.substring(0, inx);
								prop.put(name, scripwithisin.substring(inx + 1));
							}
						}
					}
				}
			} catch (Exception xp) {
				xp.printStackTrace();
			}
			Calendar cal = Calendar.getInstance();
			int hr = cal.get(Calendar.HOUR_OF_DAY);
			int min = cal.get(Calendar.MINUTE);
			if (hr < 9 || hr > 16) {
				runcnt = 0;
				System.out.print(min + "--waiting 15 min-->" + runcnt);
				// todayAlreadyResultProcessedScripCodes.clear();
				try {
					Thread.sleep(1000 * 60 * 15);
				} catch (Exception pz) {
					pz.printStackTrace();
				}
			}
			if (hr == 9) {
				if ((min >= 13 && min < 15))
					todaysScripPrcChange(0.7, true);
				else if (min >= 15 && min < 22) {
					TodaysScripPriceCheckerExecutor tt = new TodaysScripPriceCheckerExecutor(0.7, true);
					new Thread(tt).start();
				}
			} else if ((hr == 15 && (min >= 5 && min < 22))) {
				TodaysScripPriceCheckerExecutor tt = new TodaysScripPriceCheckerExecutor(4.8, false);
				new Thread(tt).start();
			}
			if (hr >= 9 && hr < 16) {
				if (hr == 9) {
					if (min >= 15) {
						// niftyBankNiftyPriceVolumeProcessor(false);
						scripFor15MinMidDay = null;
						String scripFor15Min = calculate1DayEMACalculation(prop);
						calculate15MinEMACalculation(prop, scripFor15Min);
						// String scripFor15Min = calculate1DayEMACalculationUsingHeinkeinAshi(prop);
						// calculate15MinEMACalculationUsingHeinkeinAshi(prop, scripFor15Min);
					}
				} else if (hr == 15) {
					scripFor15MinMidDay = null;
					if (min < 44) {
						// niftyBankNiftyPriceVolumeProcessor(true);
						String scripFor15Min = calculate1DayEMACalculation(prop);
						calculate15MinEMACalculation(prop, scripFor15Min);
						// String scripFor15Min = calculate1DayEMACalculationUsingHeinkeinAshi(prop);
						// calculate15MinEMACalculationUsingHeinkeinAshi(prop, scripFor15Min);
					}
				} else {
					// niftyBankNiftyPriceVolumeProcessor(false);
					if (scripFor15MinMidDay == null) {
						scripFor15MinMidDay = calculate1DayEMACalculation(prop);
						calculate15MinEMACalculation(prop, scripFor15MinMidDay);
					} else {
						calculate15MinEMACalculation(prop, scripFor15MinMidDay);
						scripFor15MinMidDay = null;
					}
					// String scripFor15Min = calculate1DayEMACalculationUsingHeinkeinAshi(prop);
					// calculate15MinEMACalculationUsingHeinkeinAshi(prop, scripFor15Min);
				}
				try {
					Thread.sleep(1000 * 60 * 15);
				} catch (Exception pz) {
					pz.printStackTrace();
				}
			}
			if (hr == 11 && min < 17) {
				InsiderTradeExecutor insdr = new InsiderTradeExecutor(prop);
				new Thread(insdr).start();
				// chart5paisa(prop, propconfig);
			}
			if (hr == 16) {
				runcnt = 0;
				if (min < 17) {
					InsiderTradeExecutor insdr = new InsiderTradeExecutor(prop);
					new Thread(insdr).start();
					candleCalculation(prop);
					// chartZerodha(configFileLocation+"/config-scripchart.properties");
					chart5paisa(prop, propconfig);
					// todayAlreadyResultProcessedScripCodes.clear();
					try {
						Thread.sleep(1000 * 60 * 60 * 14);
					} catch (Exception pz) {
						pz.printStackTrace();
					}
				}
			}
		}
	}
	public void pickAndSend5PaisaScripChart() throws Exception {
		System.out.println("------------calling pickAndSendScripChart--------");
		Properties propconfig = new Properties();
		propconfig.put("edgedriverlocation", "C:\\selenium\\\\msedgedriver.exe");
		propconfig.put("edgeprofilewithlocation1day", "C:\\\\selenium\\\\\\day1edge");
		propconfig.put("geckodriverlocation", "C:\\selenium\\\\geckodriver.exe");
		propconfig.put("firefoxlocation", "C:\\\\Program Files\\\\Mozilla Firefox\\\\firefox.exe");
		propconfig.put("firefoxprofilewithlocation", "C:\\\\selenium\\\\\\hour4Min15");
		propconfig.put("firefoxprofilewithlocation1day", "C:\\\\selenium\\\\\\day1");
		propconfig.put("firefoxprofilewithlocation1week", "C:\\\\selenium\\\\\\week1");
		propconfig.put("awsserverurl", "https://real-nails-add-103-70-80-30.loca.lt/api/scrips/chart");
		propconfig.put("charturl",
				"https://tradechart.5paisa.com/ChartIQ_8.3/advance.html?type=overview&period=1&range=d&appName=5PTRADES&appVer=5.11.6.0&exchange=nse&exchType=C&symbol=?symbol&scripCode=?scripcode&loginId=?loginid");
		Properties prop = new Properties();
		prop.putAll(ConstantScrips.scripsMap);
		try {
			String scripcodefromtelegram = TelegramUtil.getLatestTelegramMsgFromGroup("-753403607");
			if (scripcodefromtelegram != null) {
				if (scripcodefromtelegram.contains("#") == true && scripcodefromtelegram.contains("@") == true) {
					String[] scripcodeArrfromtelegram = scripcodefromtelegram.split("\n");
					if (scripcodeArrfromtelegram != null) {
						for (String scripwithisin : scripcodeArrfromtelegram) {
							int inx = scripwithisin.indexOf('@');
							String name = scripwithisin.substring(0, inx);
							prop.put(name, scripwithisin.substring(inx + 1));
						}
					}
				}
			}
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		chart5paisa(prop, propconfig);
	}
	String loginid = "54610235";
	public void calculate15MinEMACalculation(Properties prop, String scripFor15Min) {
		StringBuffer ema15MinCandle = new StringBuffer("<b>EMA9-21-15MinCandle:%0A</b>");
		StringBuffer downup15min = new StringBuffer("<b>15MinCandleContinous:%0A</b>");
		Calendar cal = Calendar.getInstance();
		long to = (Long) (cal.getTimeInMillis() / 1000);
		cal.add(Calendar.DATE, -80);
		long from = (Long) (cal.getTimeInMillis() / 1000);
		String[] scripcodeArrfromtelegram = null;
		try {
			String scripcodefromtelegram = TelegramUtil.getLatestTelegramMsgFromGroup("-753403607");
			if (scripcodefromtelegram != null) {
				if (scripcodefromtelegram.contains("#") == false)
					scripcodeArrfromtelegram = scripcodefromtelegram.split("\n");
			}
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		if (scripcodeArrfromtelegram != null && scripcodeArrfromtelegram.length > 0) {
			ema15MinCandle.append("<i>TelegramScrip:%0A</i>");
			for (String scode : scripcodeArrfromtelegram) {
				try {
					String val = (String) prop.get(scode);
					// System.out.println(scode+"-->processing for 15 min data--->"+val);
					URL url;
					if ("NIFTY".equalsIgnoreCase(scode))
						url = new URL(
								"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
										+ from + "&to=" + to + "&countback=350&currencyCode=INR");
					else if (val != null && val.startsWith("#")) {
						// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+URLEncoder.encode(scode,"UTF-8")+"&resolution=15&from="+from+"&to="+to);
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ URLEncoder.encode(scode, "UTF-8") + "&resolution=15&from=" + from + "&to=" + to
								+ "&countback=350&currencyCode=INR");
					} else {
						// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+val.substring(0,
						// val.indexOf('#'))+"&resolution=15&from="+from+"&to="+to);
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ val.substring(0, val.indexOf('#')) + "&resolution=15&from=" + from + "&to=" + to
								+ "&countback=350&currencyCode=INR");
					}
					HttpURLConnection request = (HttpURLConnection) (url.openConnection());
					request.setRequestMethod("GET");
					request.setUseCaches(false);
					request.setDoInput(true);
					request.setDoOutput(true);
					request.connect();
					BufferedReader rd = new BufferedReader(
							new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
					StringBuilder sb = new StringBuilder();
					String cp = null;
					while ((cp = rd.readLine()) != null) {
						sb.append(cp);
					}
					JSONObject json = new JSONObject(sb.toString());
					JSONArray clsarr = json.getJSONArray("c");
					JSONArray lowarr = json.getJSONArray("l");
					JSONArray volarr = json.getJSONArray("v");
					JSONArray opnarr = json.getJSONArray("o");
					JSONArray higharr = json.getJSONArray("h");
					if (clsarr != null) {
						int ln = clsarr.length();
						try {
							Double chngp = 0.0;
							chngp = ((higharr.getDouble(ln - 1) - lowarr.getDouble(ln - 1)) / higharr.getDouble(ln - 1))
									* 100;
							if ("NIFTY".equalsIgnoreCase(scode) == false) {
								if (chngp > .2) {
									if (opnarr.getDouble(ln - 1) > clsarr.getDouble(ln - 1))
										downup15min
												.append("<b>" + scode + "=" + App.df.format(chngp) + "%change</b>%0A");
									else
										downup15min
												.append("<b>" + scode + "=-" + App.df.format(chngp) + "%change</b>%0A");
								}
							} else {
								if (chngp > 1) {
									if (opnarr.getDouble(ln - 1) > clsarr.getDouble(ln - 1))
										downup15min
												.append("<b>" + scode + "=" + App.df.format(chngp) + "%change</b>%0A");
									else
										downup15min
												.append("<b>" + scode + "=-" + App.df.format(chngp) + "%change</b>%0A");
								}
							}
							/*
							 * if(opnarr.getDouble(ln-1) > lowarr.getDouble(ln-1)) { chngp =
							 * ((opnarr.getDouble(ln-1) -
							 * lowarr.getDouble(ln-1))/opnarr.getDouble(ln-1))*100; } if(chngp < 2.6 &&
							 * (higharr.getDouble(ln-1) > opnarr.getDouble(ln-1))) { chngp =
							 * ((higharr.getDouble(ln-1) -
							 * opnarr.getDouble(ln-1))/opnarr.getDouble(ln-1))*100; }else { chngp = chngp *
							 * -1; } if(chngp > 2.6 || chngp < -2.6) {
							 * downup15min.append("<b>"+scode+"="+App.df.format(chngp)+"%change</b>%0A"); }
							 */
						} catch (Exception ppx) {
							ppx.printStackTrace();
						}
						// down trend
						if ("NIFTY".equalsIgnoreCase(scode) == false) {
							int downcnt = 0;
							int upcnt = 0;
							int mn = 0;
							try {
								if (ln > 4)
									mn = ln - 4;
								for (int i = ln - 1; i > mn; i--) {
									long pvol = volarr.getLong(i - 1);
									long cvol = volarr.getLong(i);
									double vtimes = (cvol * 1.0) / pvol;
									if (vtimes > 4) {
										downup15min.append(scode + "-v=" + App.df.format(vtimes));
									}
									if (vtimes > 1.4) {
										if ((opnarr.getDouble(i) > clsarr.getDouble(i))) {
											if (i == ln - 1) {
												if ((clsarr.getDouble(i) < lowarr.getDouble(i - 1))) {
													downcnt = downcnt + 1;
												}
											} else {
												if ((clsarr.getDouble(i) < clsarr.getDouble(i - 1))) {
													downcnt = downcnt + 1;
												}
											}
										} else if ((opnarr.getDouble(i) < clsarr.getDouble(i))) {
											if (i == ln - 1) {
												if ((clsarr.getDouble(i) > lowarr.getDouble(i - 1))) {
													upcnt = upcnt + 1;
												}
											} else {
												if ((clsarr.getDouble(i) > clsarr.getDouble(i - 1))) {
													upcnt = upcnt + 1;
												}
											}
										}
									}
								}
								if ((downcnt > 2 || upcnt > 2) && ln > 0) {
									downup15min.append(scode + ",dt=" + downcnt + ",ut=" + upcnt + "%0A");
								}
							} catch (Exception px) {
								px.printStackTrace();
							}
						} else {
							int downcnt = 0;
							int upcnt = 0;
							int mn = 0;
							try {
								if (ln > 4)
									mn = ln - 4;
								for (int i = ln - 1; i > mn; i--) {
									if ((opnarr.getDouble(i) > clsarr.getDouble(i))) {
										if (i == ln - 1) {
											if ((clsarr.getDouble(i) < lowarr.getDouble(i - 1))) {
												downcnt = downcnt + 1;
											}
										} else {
											if ((clsarr.getDouble(i) < clsarr.getDouble(i - 1))) {
												downcnt = downcnt + 1;
											}
										}
									} else if ((opnarr.getDouble(i) < clsarr.getDouble(i))) {
										if (i == ln - 1) {
											if ((clsarr.getDouble(i) > lowarr.getDouble(i - 1))) {
												upcnt = upcnt + 1;
											}
										} else {
											if ((clsarr.getDouble(i) > clsarr.getDouble(i - 1))) {
												upcnt = upcnt + 1;
											}
										}
									}
								}
								if ((downcnt > 2 || upcnt > 2) && ln > 0) {
									downup15min.append(scode + ",dt=" + downcnt + ",ut=" + upcnt + "%0A");
								}
							} catch (Exception px) {
								px.printStackTrace();
							}
						}
						int period = 5;
						double smooth = 2.0 / (1 + period);
						Double sma = 0.0;
						Double prevEma = 0.0;
						Double ema = 0.0;
						int period21 = 13;
						double smooth21 = 2.0 / (1 + period21);
						Double sma21 = 0.0;
						Double prevEma21 = 0.0;
						Double ema21 = 0.0;
						for (int i = 0; i < ln; i++) {
							if (i < period) {
								sma = sma + clsarr.getDouble(i);
							} else {
								if (i == period) {
									prevEma = sma / period;
								} else {
									prevEma = ema;
								}
								ema = ((clsarr.getDouble(i) * smooth) + (prevEma * (1 - smooth)));
							}
							if (i < period21) {
								sma21 = sma21 + lowarr.getDouble(i);
							} else {
								if (i == period21) {
									prevEma21 = sma21 / period21;
								} else {
									prevEma21 = ema21;
								}
								ema21 = ((lowarr.getDouble(i) * smooth21) + (prevEma21 * (1 - smooth21)));
							}
						}
						if (ema > ema21 && prevEma < prevEma21)
							ema15MinCandle.append(scode + ",");
						// System.out.println(cntDown+"-->"+clsarr.getDouble(ln-1)+"=1Day-Code:"+code+"ema9Prev:"+prevEma+",ema9:"+ema+",ema21Prev:"+prevEma21+",ema21:"+ema21);
					}
				} catch (Exception ix) {
					ix.printStackTrace();
				}
			}
			ema15MinCandle.append("%0A");
		}
		// 4 red candle wala
		try {
			String[] scripcodeArrfrom1dayArr = null;
			if (scripFor15Min != null)
				scripcodeArrfrom1dayArr = scripFor15Min.split(",");
			if (scripcodeArrfrom1dayArr != null && scripcodeArrfrom1dayArr.length > 0) {
				ema15MinCandle.append("<i>Candle1DayDownScrip:%0A</i>");
				for (String scode : scripcodeArrfrom1dayArr) {
					try {
						boolean canprocess = true;
						if (scode == null || scode.trim().length() == 0)
							canprocess = false;
						if (canprocess) {
							if (scripcodeArrfromtelegram != null) {
								for (String scrp : scripcodeArrfromtelegram) {
									if (scrp.equalsIgnoreCase(scode)) {
										canprocess = false;
										break;
									}
								}
							}
						}
						if (canprocess == true) {
							String val = (String) prop.get(scode);
							System.out.println(scode + "-->processing for 15 min data--->" + val);
							URL url;
							if ("NIFTY".equalsIgnoreCase(scode))
								url = new URL(
										"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
												+ from + "&to=" + to + "&countback=350&currencyCode=INR");
							else if (val != null && val.startsWith("#")) {
								// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+URLEncoder.encode(scode,"UTF-8")+"&resolution=15&from="+from+"&to="+to);
								url = new URL(
										"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
												+ URLEncoder.encode(scode, "UTF-8") + "&resolution=15&from=" + from
												+ "&to=" + to + "&countback=350&currencyCode=INR");
							} else {
								// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+val.substring(0,
								// val.indexOf('#'))+"&resolution=15&from="+from+"&to="+to);
								url = new URL(
										"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
												+ val.substring(0, val.indexOf('#')) + "&resolution=15&from=" + from
												+ "&to=" + to + "&countback=350&currencyCode=INR");
							}
							HttpURLConnection request = (HttpURLConnection) (url.openConnection());
							request.setRequestMethod("GET");
							request.setUseCaches(false);
							request.setDoInput(true);
							request.setDoOutput(true);
							request.connect();
							BufferedReader rd = new BufferedReader(
									new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
							StringBuilder sb = new StringBuilder();
							String cp = null;
							while ((cp = rd.readLine()) != null) {
								sb.append(cp);
							}
							JSONObject json = new JSONObject(sb.toString());
							JSONArray clsarr = json.getJSONArray("c");
							JSONArray lowarr = json.getJSONArray("l");
							if (clsarr != null) {
								int ln = clsarr.length();
								int period = 5;
								double smooth = 2.0 / (1 + period);
								Double sma = 0.0;
								Double prevEma = 0.0;
								Double ema = 0.0;
								int period21 = 13;
								double smooth21 = 2.0 / (1 + period21);
								Double sma21 = 0.0;
								Double prevEma21 = 0.0;
								Double ema21 = 0.0;
								for (int i = 0; i < ln; i++) {
									if (i < period) {
										sma = sma + clsarr.getDouble(i);
									} else {
										if (i == period) {
											prevEma = sma / period;
										} else {
											prevEma = ema;
										}
										ema = ((clsarr.getDouble(i) * smooth) + (prevEma * (1 - smooth)));
									}
									if (i < period21) {
										sma21 = sma21 + lowarr.getDouble(i);
									} else {
										if (i == period21) {
											prevEma21 = sma21 / period21;
										} else {
											prevEma21 = ema21;
										}
										ema21 = ((lowarr.getDouble(i) * smooth21) + (prevEma21 * (1 - smooth21)));
									}
								}
								if (ema > ema21 && prevEma < prevEma21)
									ema15MinCandle.append(scode + ",");
								// System.out.println(cntDown+"-->"+clsarr.getDouble(ln-1)+"=1Day-Code:"+code+"ema9Prev:"+prevEma+",ema9:"+ema+",ema21Prev:"+prevEma21+",ema21:"+ema21);
							}
						}
					} catch (Exception ix) {
						ix.printStackTrace();
					}
				}
				ema15MinCandle.append("%0A");
			}
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		try {
			TelegramUtil.sendTelegramMsg(ema15MinCandle.toString(), "-485376339", false);
		} catch (Exception ix) {
			ix.printStackTrace();
		}
		try {
			TelegramUtil.sendTelegramMsg(downup15min.toString(), "-485376339", false);
		} catch (Exception ix) {
			ix.printStackTrace();
		}
	}
	public void calculate15MinEMACalculationUsingHeinkeinAshi(Properties prop, String scripFor15Min) {
		StringBuffer ema15MinCandle = new StringBuffer("<b>EMA9-21-15MinHeinAshiCandle:%0A</b>");
		Calendar cal = Calendar.getInstance();
		long to = (Long) (cal.getTimeInMillis() / 1000);
		cal.add(Calendar.DATE, -80);
		long from = (Long) (cal.getTimeInMillis() / 1000);
		String[] scripcodeArrfromtelegram = null;
		try {
			String scripcodefromtelegram = TelegramUtil.getLatestTelegramMsgFromGroup("-753403607");
			if (scripcodefromtelegram != null)
				scripcodeArrfromtelegram = scripcodefromtelegram.split("\n");
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		if (scripcodeArrfromtelegram != null && scripcodeArrfromtelegram.length > 0) {
			ema15MinCandle.append("<i>TelegramScrip:%0A</i>");
			for (String scode : scripcodeArrfromtelegram) {
				try {
					String val = (String) prop.get(scode);
					// System.out.println(scode+"-->processing for 15 min data--->"+val);
					URL url;
					if ("NIFTY".equalsIgnoreCase(scode))
						url = new URL(
								"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
										+ from + "&to=" + to);
					else if (val != null && val.startsWith("#")) {
						// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+URLEncoder.encode(scode,"UTF-8")+"&resolution=15&from="+from+"&to="+to);
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ URLEncoder.encode(scode, "UTF-8") + "&resolution=15&from=" + from + "&to=" + to);
					} else {
						// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+val.substring(0,
						// val.indexOf('#'))+"&resolution=15&from="+from+"&to="+to);
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ val.substring(0, val.indexOf('#')) + "&resolution=15&from=" + from + "&to=" + to);
					}
					HttpURLConnection request = (HttpURLConnection) (url.openConnection());
					request.setRequestMethod("GET");
					request.setUseCaches(false);
					request.setDoInput(true);
					request.setDoOutput(true);
					request.connect();
					BufferedReader rd = new BufferedReader(
							new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
					StringBuilder sb = new StringBuilder();
					String cp = null;
					while ((cp = rd.readLine()) != null) {
						sb.append(cp);
					}
					JSONObject json = new JSONObject(sb.toString());
					JSONArray opnarrNormalCandle = json.getJSONArray("o");
					JSONArray clsarrNormalCandle = json.getJSONArray("c");
					JSONArray lowarrNormalCandle = json.getJSONArray("l");
					JSONArray higharrNormalCandle = json.getJSONArray("h");
					/* convert to heinkin */
					int len = clsarrNormalCandle.length();
					Double cH = (opnarrNormalCandle.getDouble(0) + clsarrNormalCandle.getDouble(0)
							+ higharrNormalCandle.getDouble(0) + lowarrNormalCandle.getDouble(0)) / 4;
					Double oH = (opnarrNormalCandle.getDouble(0) + clsarrNormalCandle.getDouble(0)) / 2;
					// Double hH = higharrNormalCandle.getDouble(0);
					Double lH = lowarrNormalCandle.getDouble(0);
					JSONArray opnarr = new JSONArray();
					JSONArray clsarr = new JSONArray();
					JSONArray lowarr = new JSONArray();
					// JSONArray higharr = new JSONArray();
					opnarr.put(0, oH);
					clsarr.put(0, cH);
					lowarr.put(0, lH);
					for (int x = 1; x < len; x++) {
						cH = (opnarrNormalCandle.getDouble(x) + clsarrNormalCandle.getDouble(x)
								+ higharrNormalCandle.getDouble(x) + lowarrNormalCandle.getDouble(x)) / 4;
						oH = (opnarr.getDouble(x - 1) + clsarr.getDouble(x - 1)) / 2;
						lH = 0.0;
						if (lowarrNormalCandle.getDouble(x) < cH && lowarrNormalCandle.getDouble(x) < oH)
							lH = lowarrNormalCandle.getDouble(x);
						else if (cH < lowarrNormalCandle.getDouble(x) && cH < oH)
							lH = cH;
						else if (oH < lowarrNormalCandle.getDouble(x) && oH < cH)
							lH = lowarrNormalCandle.getDouble(x);
						opnarr.put(x, oH);
						clsarr.put(x, cH);
						lowarr.put(x, lH);
					}
					if (clsarr != null) {
						int ln = clsarr.length();
						int period = 9;
						double smooth = 2.0 / (1 + period);
						Double sma = 0.0;
						Double prevEma = 0.0;
						Double ema = 0.0;
						int period21 = 21;
						double smooth21 = 2.0 / (1 + period21);
						Double sma21 = 0.0;
						Double prevEma21 = 0.0;
						Double ema21 = 0.0;
						for (int i = 0; i < ln; i++) {
							if (i < period) {
								sma = sma + clsarr.getDouble(i);
							} else {
								if (i == period) {
									prevEma = sma / period;
								} else {
									prevEma = ema;
								}
								ema = ((clsarr.getDouble(i) * smooth) + (prevEma * (1 - smooth)));
							}
							if (i < period21) {
								sma21 = sma21 + lowarr.getDouble(i);
							} else {
								if (i == period21) {
									prevEma21 = sma21 / period21;
								} else {
									prevEma21 = ema21;
								}
								ema21 = ((lowarr.getDouble(i) * smooth21) + (prevEma21 * (1 - smooth21)));
							}
						}
						if (ema > ema21 && prevEma < prevEma21)
							ema15MinCandle.append(scode + ",");
						// System.out.println(cntDown+"-->"+clsarr.getDouble(ln-1)+"=1Day-Code:"+code+"ema9Prev:"+prevEma+",ema9:"+ema+",ema21Prev:"+prevEma21+",ema21:"+ema21);
					}
				} catch (Exception ix) {
					ix.printStackTrace();
				}
			}
			ema15MinCandle.append("%0A");
		}
		// 4 red candle wala
		try {
			String[] scripcodeArrfrom1dayArr = null;
			if (scripFor15Min != null)
				scripcodeArrfrom1dayArr = scripFor15Min.split(",");
			if (scripcodeArrfrom1dayArr != null && scripcodeArrfrom1dayArr.length > 0) {
				ema15MinCandle.append("<i>Candle1DayDownScrip:%0A</i>");
				for (String scode : scripcodeArrfrom1dayArr) {
					try {
						boolean canprocess = true;
						if (scripcodeArrfromtelegram != null) {
							for (String scrp : scripcodeArrfromtelegram) {
								if (scrp.equalsIgnoreCase(scode)) {
									canprocess = false;
									break;
								}
							}
						}
						if (canprocess == true) {
							String val = (String) prop.get(scode);
							// System.out.println(scode+"-->processing for 15 min data--->"+val);
							URL url;
							if ("NIFTY".equalsIgnoreCase(scode))
								url = new URL(
										"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
												+ from + "&to=" + to);
							else if (val != null && val.startsWith("#")) {
								// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+URLEncoder.encode(scode,"UTF-8")+"&resolution=15&from="+from+"&to="+to);
								url = new URL(
										"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
												+ URLEncoder.encode(scode, "UTF-8") + "&resolution=15&from=" + from
												+ "&to=" + to);
							} else {
								// System.out.print("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+val.substring(0,
								// val.indexOf('#'))+"&resolution=15&from="+from+"&to="+to);
								url = new URL(
										"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
												+ val.substring(0, val.indexOf('#')) + "&resolution=15&from=" + from
												+ "&to=" + to);
							}
							HttpURLConnection request = (HttpURLConnection) (url.openConnection());
							request.setRequestMethod("GET");
							request.setUseCaches(false);
							request.setDoInput(true);
							request.setDoOutput(true);
							request.connect();
							BufferedReader rd = new BufferedReader(
									new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
							StringBuilder sb = new StringBuilder();
							String cp = null;
							while ((cp = rd.readLine()) != null) {
								sb.append(cp);
							}
							JSONObject json = new JSONObject(sb.toString());
							JSONArray opnarrNormalCandle = json.getJSONArray("o");
							JSONArray clsarrNormalCandle = json.getJSONArray("c");
							JSONArray lowarrNormalCandle = json.getJSONArray("l");
							JSONArray higharrNormalCandle = json.getJSONArray("h");
							/* convert to heinkin */
							int len = clsarrNormalCandle.length();
							Double cH = (opnarrNormalCandle.getDouble(0) + clsarrNormalCandle.getDouble(0)
									+ higharrNormalCandle.getDouble(0) + lowarrNormalCandle.getDouble(0)) / 4;
							Double oH = (opnarrNormalCandle.getDouble(0) + clsarrNormalCandle.getDouble(0)) / 2;
							// Double hH = higharrNormalCandle.getDouble(0);
							Double lH = lowarrNormalCandle.getDouble(0);
							JSONArray opnarr = new JSONArray();
							JSONArray clsarr = new JSONArray();
							JSONArray lowarr = new JSONArray();
							// JSONArray higharr = new JSONArray();
							opnarr.put(0, oH);
							clsarr.put(0, cH);
							lowarr.put(0, lH);
							for (int x = 1; x < len; x++) {
								cH = (opnarrNormalCandle.getDouble(x) + clsarrNormalCandle.getDouble(x)
										+ higharrNormalCandle.getDouble(x) + lowarrNormalCandle.getDouble(x)) / 4;
								oH = (opnarr.getDouble(x - 1) + clsarr.getDouble(x - 1)) / 2;
								lH = 0.0;
								if (lowarrNormalCandle.getDouble(x) < cH && lowarrNormalCandle.getDouble(x) < oH)
									lH = lowarrNormalCandle.getDouble(x);
								else if (cH < lowarrNormalCandle.getDouble(x) && cH < oH)
									lH = cH;
								else if (oH < lowarrNormalCandle.getDouble(x) && oH < cH)
									lH = lowarrNormalCandle.getDouble(x);
								opnarr.put(x, oH);
								clsarr.put(x, cH);
								lowarr.put(x, lH);
							}
							if (clsarr != null) {
								int ln = clsarr.length();
								int period = 9;
								double smooth = 2.0 / (1 + period);
								Double sma = 0.0;
								Double prevEma = 0.0;
								Double ema = 0.0;
								int period21 = 21;
								double smooth21 = 2.0 / (1 + period21);
								Double sma21 = 0.0;
								Double prevEma21 = 0.0;
								Double ema21 = 0.0;
								for (int i = 0; i < ln; i++) {
									if (i < period) {
										sma = sma + clsarr.getDouble(i);
									} else {
										if (i == period) {
											prevEma = sma / period;
										} else {
											prevEma = ema;
										}
										ema = ((clsarr.getDouble(i) * smooth) + (prevEma * (1 - smooth)));
									}
									if (i < period21) {
										sma21 = sma21 + lowarr.getDouble(i);
									} else {
										if (i == period21) {
											prevEma21 = sma21 / period21;
										} else {
											prevEma21 = ema21;
										}
										ema21 = ((lowarr.getDouble(i) * smooth21) + (prevEma21 * (1 - smooth21)));
									}
								}
								if (ema > ema21 && prevEma < prevEma21)
									ema15MinCandle.append(scode + ",");
								// System.out.println(cntDown+"-->"+clsarr.getDouble(ln-1)+"=1Day-Code:"+code+"ema9Prev:"+prevEma+",ema9:"+ema+",ema21Prev:"+prevEma21+",ema21:"+ema21);
							}
						}
					} catch (Exception ix) {
						ix.printStackTrace();
					}
				}
				ema15MinCandle.append("%0A");
			}
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		try {
			TelegramUtil.sendTelegramMsg(ema15MinCandle.toString(), "-485376339", false);
		} catch (Exception ix) {
			ix.printStackTrace();
		}
	}
	public String calculate1DayEMACalculationUsingHeinkeinAshi(Properties prop) {
		String scripFor15Min = "";
		StringBuffer ema1DayCandle = new StringBuffer("<b>EMA9-21-1DayHeinAshiCandle:%0A</b>");
		StringBuffer downtren1DayCandle = new StringBuffer("<b>DownTrenCanStartFor-1DayHeinAshiCandle:%0A</b>");
		Calendar cal = Calendar.getInstance();
		long to = (Long) (cal.getTimeInMillis() / 1000);
		cal.add(Calendar.DATE, -365);
		long from = (Long) (cal.getTimeInMillis() / 1000);
		try {
			Iterator<Entry<Object, Object>> it = prop.entrySet().iterator();
			while (it.hasNext()) {
				String code = "";
				try {
					Entry<Object, Object> en = it.next();
					code = (String) (en.getKey());
					String val = (String) (en.getValue());
					URL url;
					if ("NIFTY".equalsIgnoreCase(code))
						url = new URL(
								"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
										+ from + "&to=" + to);
					else if (val != null && val.startsWith("#"))
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ URLEncoder.encode(code, "UTF-8") + "&resolution=1D&from=" + from + "&to=" + to);
					else
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ val.substring(0, val.indexOf('#')) + "&resolution=1D&from=" + from + "&to=" + to);
					HttpURLConnection request = (HttpURLConnection) (url.openConnection());
					request.setRequestMethod("GET");
					request.setUseCaches(false);
					request.setDoInput(true);
					request.setDoOutput(true);
					request.connect();
					BufferedReader rd = new BufferedReader(
							new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
					StringBuilder sb = new StringBuilder();
					String cp = null;
					while ((cp = rd.readLine()) != null) {
						sb.append(cp);
					}
					JSONObject json = new JSONObject(sb.toString());
					JSONArray opnarrNormalCandle = json.getJSONArray("o");
					JSONArray clsarrNormalCandle = json.getJSONArray("c");
					JSONArray lowarrNormalCandle = json.getJSONArray("l");
					JSONArray higharrNormalCandle = json.getJSONArray("h");
					/* convert to heinkin */
					int len = clsarrNormalCandle.length();
					Double cH = (opnarrNormalCandle.getDouble(0) + clsarrNormalCandle.getDouble(0)
							+ higharrNormalCandle.getDouble(0) + lowarrNormalCandle.getDouble(0)) / 4;
					Double oH = (opnarrNormalCandle.getDouble(0) + clsarrNormalCandle.getDouble(0)) / 2;
					// Double hH = higharrNormalCandle.getDouble(0);
					Double lH = lowarrNormalCandle.getDouble(0);
					JSONArray opnarr = new JSONArray();
					JSONArray clsarr = new JSONArray();
					JSONArray lowarr = new JSONArray();
					// JSONArray higharr = new JSONArray();
					opnarr.put(0, oH);
					clsarr.put(0, cH);
					lowarr.put(0, lH);
					for (int x = 1; x < len; x++) {
						cH = (opnarrNormalCandle.getDouble(x) + clsarrNormalCandle.getDouble(x)
								+ higharrNormalCandle.getDouble(x) + lowarrNormalCandle.getDouble(x)) / 4;
						oH = (opnarr.getDouble(x - 1) + clsarr.getDouble(x - 1)) / 2;
						lH = 0.0;
						if (lowarrNormalCandle.getDouble(x) < cH && lowarrNormalCandle.getDouble(x) < oH)
							lH = lowarrNormalCandle.getDouble(x);
						else if (cH < lowarrNormalCandle.getDouble(x) && cH < oH)
							lH = cH;
						else if (oH < lowarrNormalCandle.getDouble(x) && oH < cH)
							lH = lowarrNormalCandle.getDouble(x);
						opnarr.put(x, oH);
						clsarr.put(x, cH);
						lowarr.put(x, lH);
					}
					if (clsarr != null) {
						int ln = clsarr.length();
						int period = 9;
						double smooth = 2.0 / (1 + period);
						Double sma = 0.0;
						Double prevEma = 0.0;
						Double ema = 0.0;
						int period21 = 21;
						double smooth21 = 2.0 / (1 + period21);
						Double sma21 = 0.0;
						Double prevEma21 = 0.0;
						Double ema21 = 0.0;
						int cntDown = 0;
						for (int i = 0; i < ln; i++) {
							if (i < period) {
								sma = sma + clsarr.getDouble(i);
							} else {
								if (i == period) {
									prevEma = sma / period;
								} else {
									prevEma = ema;
								}
								ema = ((clsarr.getDouble(i) * smooth) + (prevEma * (1 - smooth)));
							}
							if (i < period21) {
								sma21 = sma21 + lowarr.getDouble(i);
							} else {
								if (i == period21) {
									prevEma21 = sma21 / period21;
								} else {
									prevEma21 = ema21;
								}
								ema21 = ((lowarr.getDouble(i) * smooth21) + (prevEma21 * (1 - smooth21)));
							}
							if (i + 12 > len) {
								if (ema < ema21)
									cntDown = cntDown + 1;
								else
									cntDown = cntDown - 1;
							}
						}
						/*
						 * int period = 9; double smooth = 2.0/(1+period); Double sma = 0.0; Double
						 * prevEma = 0.0; Double ema = 0.0; for(int i=0; i < ln; i++) { if(i<period) {
						 * sma = sma + clsarr.getDouble(i); }else { if(i == period) { prevEma = sma /
						 * period; //System.out.println("=>"+smooth+"="+prevEma+"=per+i="+i); }else {
						 * prevEma = ema; } //ema = ((clsarr.getDouble(i) - prevEma) * smooth) +
						 * prevEma; ema = ((clsarr.getDouble(i) * smooth) + (prevEma*(1-smooth)));
						 * //System.out.println(i+"=i,ema="+ema+",prevEma="+prevEma+", cls=>"+clsarr.
						 * getDouble(i)); } } period = 21; smooth = 2.0/(1+period); Double sma21 = 0.0;
						 * Double prevEma21 = 0.0; Double ema21 = 0.0; for(int i=0; i < ln; i++) {
						 * if(i<period) { sma21 = sma21 + lowarr.getDouble(i); }else { if(i == period) {
						 * prevEma21 = sma21 / period; }else { prevEma21 = ema21; } //ema21 =
						 * ((lowarr.getDouble(i) - prevEma21) * smooth) + prevEma21; ema21 =
						 * ((lowarr.getDouble(i) * smooth) + (prevEma21*(1-smooth))); } }
						 */
						if (ema > ema21 && prevEma < prevEma21)
							ema1DayCandle.append(code + ",");
						System.out
								.println(cntDown + "-->" + clsarr.getDouble(ln - 1) + "=1Day-Code:" + code + "ema9Prev:"
										+ prevEma + ",ema9:" + ema + ",ema21Prev:" + prevEma21 + ",ema21:" + ema21);
						// downtrend
						if (cntDown > 9)
							scripFor15Min = scripFor15Min + code + ",";
						if (cntDown < -10)
							downtren1DayCandle.append(code + ",");
						/*
						 * int cnt = 0; int cntCont = 0; for(int i = ln-2; i>ln-6; i--) { Double o =
						 * opnarr.getDouble(i); Double c = clsarr.getDouble(i); if(o > c) { cntCont =
						 * cntCont + 1; Double l = lowarr.getDouble(i); if((o-l) > (c * 0.02)) { cnt =
						 * cnt + 1; } }else { cntCont = 0; if((c-o) > (c * 0.01)) { cnt = cnt - 1; } } }
						 * if(cnt > 3 || cntCont > 4) scripFor15Min = scripFor15Min + code +",";
						 */
						// System.out.println("1Day-Code:"+code+",lowCandle:"+cnt);
					}
				} catch (Exception pz) {
					System.out.println("for scrip:" + code);
					pz.printStackTrace();
				}
			}
			ema1DayCandle.append("%0A");
			downtren1DayCandle.append("%0A");
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		// 1Day candle wala
		try {
			TelegramUtil.sendTelegramMsg(downtren1DayCandle.toString(), "-485376339", false);
			TelegramUtil.sendTelegramMsg(ema1DayCandle.toString(), "-485376339", false);
		} catch (Exception ix) {
			ix.printStackTrace();
		}
		System.out.println("scripFor15Min from 1Day-Code:" + scripFor15Min);
		return scripFor15Min;
	}
	public String calculate1DayEMACalculation(Properties prop) {
		String scripFor15Min = "";
		StringBuffer ema1DayCandle = new StringBuffer("<b>EMA9-21-1DayCandle:%0A</b>");
		StringBuffer downtren1DayCandle = new StringBuffer("<b>DownTrenCanStartFor-1DayCandle:%0A</b>");
		Calendar cal = Calendar.getInstance();
		long to = (Long) (cal.getTimeInMillis() / 1000);
		cal.add(Calendar.DATE, -365);
		long from = (Long) (cal.getTimeInMillis() / 1000);
		try {
			Iterator<Entry<Object, Object>> it = prop.entrySet().iterator();
			while (it.hasNext()) {
				String code = "";
				try {
					Entry<Object, Object> en = it.next();
					code = (String) (en.getKey());
					String val = (String) (en.getValue());
					URL url;
					if ("NIFTY".equalsIgnoreCase(code))
						url = new URL(
								"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
										+ from + "&to=" + to + "&countback=350&currencyCode=INR");
					else if (val != null && val.startsWith("#"))
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ URLEncoder.encode(code, "UTF-8") + "&resolution=1D&from=" + from + "&to=" + to
								+ "&countback=350&currencyCode=INR");
					else
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ val.substring(0, val.indexOf('#')) + "&resolution=1D&from=" + from + "&to=" + to
								+ "&countback=350&currencyCode=INR");
					HttpURLConnection request = (HttpURLConnection) (url.openConnection());
					request.setRequestMethod("GET");
					request.setUseCaches(false);
					request.setDoInput(true);
					request.setDoOutput(true);
					request.connect();
					BufferedReader rd = new BufferedReader(
							new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
					StringBuilder sb = new StringBuilder();
					String cp = null;
					while ((cp = rd.readLine()) != null) {
						sb.append(cp);
					}
					JSONObject json = new JSONObject(sb.toString());
					JSONArray opnarr = json.getJSONArray("o");
					JSONArray clsarr = json.getJSONArray("c");
					JSONArray lowarr = json.getJSONArray("l");
					if (clsarr != null) {
						int ln = clsarr.length();
						if (ln > 5) {
							int cnt = 0;
							for (int i = ln - 5; i < ln; i++) {
								Double pchange = ((opnarr.getDouble(i) - clsarr.getDouble(i)) * 100)
										/ opnarr.getDouble(i);
								if (pchange > 4.9)
									cnt = cnt + 3;
								else if (pchange < -4.9)
									cnt = cnt - 3;
								else if (pchange > 1.8)
									cnt = cnt + 1;
								else if (pchange < -1.8)
									cnt = cnt - 1;
							}
							if (cnt > 2 || cnt < -2) {
								downtren1DayCandle.append(code + ":" + cnt + " candle move in 5 days,");
								ema1DayCandle.append(code + ",");
							}
						}
						int period = 9;
						double smooth = 2.0 / (1 + period);
						Double sma = 0.0;
						Double prevEma = 0.0;
						Double ema = 0.0;
						int period21 = 21;
						double smooth21 = 2.0 / (1 + period21);
						Double sma21 = 0.0;
						Double prevEma21 = 0.0;
						Double ema21 = 0.0;
						int cntDown = 0;
						for (int i = 0; i < ln; i++) {
							if (i < period) {
								sma = sma + clsarr.getDouble(i);
							} else {
								if (i == period) {
									prevEma = sma / period;
								} else {
									prevEma = ema;
								}
								ema = ((clsarr.getDouble(i) * smooth) + (prevEma * (1 - smooth)));
							}
							if (i < period21) {
								sma21 = sma21 + lowarr.getDouble(i);
							} else {
								if (i == period21) {
									prevEma21 = sma21 / period21;
								} else {
									prevEma21 = ema21;
								}
								ema21 = ((lowarr.getDouble(i) * smooth21) + (prevEma21 * (1 - smooth21)));
							}
							if (i + 20 > ln) {
								if (ema < ema21)
									cntDown = cntDown + 1;
								else
									cntDown = cntDown - 1;
							}
						}
						if (ema > ema21 && prevEma < prevEma21)
							ema1DayCandle.append(code + ",");
						System.out
								.println(cntDown + "-->" + clsarr.getDouble(ln - 1) + "=1Day-Code:" + code + "ema9Prev:"
										+ prevEma + ",ema9:" + ema + ",ema21Prev:" + prevEma21 + ",ema21:" + ema21);
						// downtrend
						if (cntDown > 9)
							scripFor15Min = scripFor15Min + code + ",";
						if (cntDown < -12 && ema > ema21)
							downtren1DayCandle.append(code + ":" + cntDown + ",");
						if (cntDown > 12 && ema21 > ema)
							downtren1DayCandle.append(code + ":" + cntDown + ",");
					}
					/*
					 * if(clsarr != null) { int ln = clsarr.length(); int period = 9; double smooth
					 * = 2.0/(1+period); Double sma = 0.0; Double prevEma = 0.0; Double ema = 0.0;
					 * for(int i=0; i < ln; i++) { if(i<period) { sma = sma + clsarr.getDouble(i);
					 * }else { if(i == period) { prevEma = sma / period;
					 * //System.out.println("=>"+smooth+"="+prevEma+"=per+i="+i); }else { prevEma =
					 * ema; } //ema = ((clsarr.getDouble(i) - prevEma) * smooth) + prevEma; ema =
					 * ((clsarr.getDouble(i) * smooth) + (prevEma*(1-smooth)));
					 * //System.out.println(i+"=i,ema="+ema+",prevEma="+prevEma+", cls=>"+clsarr.
					 * getDouble(i)); } } period = 21; smooth = 2.0/(1+period); Double sma21 = 0.0;
					 * Double prevEma21 = 0.0; Double ema21 = 0.0; for(int i=0; i < ln; i++) {
					 * if(i<period) { sma21 = sma21 + lowarr.getDouble(i); }else { if(i == period) {
					 * prevEma21 = sma21 / period; }else { prevEma21 = ema21; } //ema21 =
					 * ((lowarr.getDouble(i) - prevEma21) * smooth) + prevEma21; ema21 =
					 * ((lowarr.getDouble(i) * smooth) + (prevEma21*(1-smooth))); } } if(ema > ema21
					 * && prevEma < prevEma21) ema1DayCandle.append(code+",");
					 * 
					 * System.out.println("1Day-Code:"+code+"ema9Prev:"+prevEma+",ema9:"+ema+
					 * ",ema21Prev:"+prevEma21+",ema21:"+ema21); //downtrend int cnt = 0; int
					 * cntCont = 0; for(int i = ln-2; i>ln-6; i--) { Double o = opnarr.getDouble(i);
					 * Double c = clsarr.getDouble(i); if(o > c) { cntCont = cntCont + 1; Double l =
					 * lowarr.getDouble(i); if((o-l) > (c * 0.02)) { cnt = cnt + 1; } }else {
					 * cntCont = 0; if((c-o) > (c * 0.01)) { cnt = cnt - 1; } } } if(cnt > 3 ||
					 * cntCont > 4) scripFor15Min = scripFor15Min + code +",";
					 * //System.out.println("1Day-Code:"+code+",lowCandle:"+cnt); }
					 */
				} catch (Exception pz) {
					System.out.println("for scrip:" + code);
					pz.printStackTrace();
				}
			}
			ema1DayCandle.append("%0A");
			downtren1DayCandle.append("%0A");
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		// 1Day candle wala
		try {
			TelegramUtil.sendTelegramMsg(downtren1DayCandle.toString(), "-485376339", false);
			TelegramUtil.sendTelegramMsg(ema1DayCandle.toString(), "-485376339", false);
		} catch (Exception ix) {
			ix.printStackTrace();
		}
		System.out.println("scripFor15Min from 1Day-Code:" + scripFor15Min);
		return scripFor15Min;
	}
	public void candleCalculation(Properties prop) {
		try {
			StringBuffer bullishCandle = new StringBuffer("<b>BullCandle1Day-EOD:%0A</b>");
			StringBuffer bearishCandle = new StringBuffer("<b>BearCandle1Day-EOD:%0A</b>");
			StringBuffer insiderT = new StringBuffer("1DayCandle-EOD:");
			Calendar cal = Calendar.getInstance();
			insiderT.append("t:" + cal.get(Calendar.DATE) + "-" + (cal.get(Calendar.MONTH) + 1) + ",f:");
			long to = (Long) (cal.getTimeInMillis() / 1000);
			cal.add(Calendar.DATE, -12);
			insiderT.append(cal.get(Calendar.DATE) + "-" + (cal.get(Calendar.MONTH) + 1) + "%0A");
			long from = (Long) (cal.getTimeInMillis() / 1000);
			Iterator<Entry<Object, Object>> it = prop.entrySet().iterator();
			while (it.hasNext()) {
				String code = "";
				try {
					Entry<Object, Object> en = it.next();
					code = (String) (en.getKey());
					String val = (String) (en.getValue());
					URL url;
					if ("NIFTY".equalsIgnoreCase(code))
						url = new URL(
								"https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol=9&resolution=1D&from="
										+ from + "&to=" + to + "&countback=15&currencyCode=INR");
					else if (val != null && val.startsWith("#"))
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ URLEncoder.encode(code, "UTF-8") + "&resolution=1D&from=" + from + "&to=" + to
								+ "&countback=15&currencyCode=INR");
					else
						url = new URL("https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="
								+ val.substring(0, val.indexOf('#')) + "&resolution=1D&from=" + from + "&to=" + to
								+ "&countback=15&currencyCode=INR");
					HttpURLConnection request = (HttpURLConnection) (url.openConnection());
					request.setRequestMethod("GET");
					request.setUseCaches(false);
					request.setDoInput(true);
					request.setDoOutput(true);
					request.connect();
					BufferedReader rd = new BufferedReader(
							new java.io.InputStreamReader(request.getInputStream(), "UTF-8"));
					StringBuilder sb = new StringBuilder();
					String cp = null;
					while ((cp = rd.readLine()) != null) {
						sb.append(cp);
					}
					// System.out.println(code+"=candle===="+sb);
					JSONObject json = new JSONObject(sb.toString());
					// JSONObject json = jsonMain.getJSONObject("data");
					JSONArray volarr = json.getJSONArray("v");
					JSONArray opnarr = json.getJSONArray("o");
					JSONArray clsarr = json.getJSONArray("c");
					JSONArray lowarr = json.getJSONArray("l");
					JSONArray higharr = json.getJSONArray("h");
					if (opnarr != null) {
						int ln = opnarr.length();
						try {
							Double chngp = 0.0;
							chngp = ((higharr.getDouble(ln - 1) - lowarr.getDouble(ln - 1)) / higharr.getDouble(ln - 1))
									* 100;
							if ("NIFTY".equalsIgnoreCase(code)) {
								if (chngp > 1.8) {
									if (opnarr.getDouble(ln - 1) > clsarr.getDouble(ln - 1))
										insiderT.append("<b>" + code + "=" + App.df.format(chngp) + "%change</b>%0A");
									else
										insiderT.append("<b>" + code + "=-" + App.df.format(chngp) + "%change</b>%0A");
								}
							} else {
								if (chngp > 4.8) {
									if (opnarr.getDouble(ln - 1) > clsarr.getDouble(ln - 1))
										insiderT.append("<b>" + code + "=" + App.df.format(chngp) + "%change</b>%0A");
									else
										insiderT.append("<b>" + code + "=-" + App.df.format(chngp) + "%change</b>%0A");
								}
							}
							/*
							 * if(opnarr.getDouble(ln-1) > lowarr.getDouble(ln-1)) { chngp =
							 * ((opnarr.getDouble(ln-1) -
							 * lowarr.getDouble(ln-1))/opnarr.getDouble(ln-1))*100; } if(chngp < 3.5 &&
							 * (higharr.getDouble(ln-1) > opnarr.getDouble(ln-1))) { chngp =
							 * ((higharr.getDouble(ln-1) -
							 * opnarr.getDouble(ln-1))/opnarr.getDouble(ln-1))*100; }else { chngp = chngp *
							 * -1; } if(chngp > 3.5 || chngp < -3.5) {
							 * insiderT.append("<b>"+code+"="+App.df.format(chngp)+"%change</b>%0A"); }
							 */
							// check boolish bearish
							Double o = opnarr.getDouble(ln - 1);
							Double c = clsarr.getDouble(ln - 1);
							Double h = higharr.getDouble(ln - 1);
							Double l = lowarr.getDouble(ln - 1);
							Double wik = 0.0;
							Double wikbear = 0.0;
							double mx = 0.0;
							double mn = 1000000.0;
							String high = "";
							String low = "";
							for (int i = 0; i < ln; i++) {
								if (higharr.getDouble(i) > mx) {
									mx = higharr.getDouble(i);
									high = "h:" + App.df.format(mx) + ":t" + (i + 1 - ln);
								}
								if (lowarr.getDouble(i) < mn) {
									mn = lowarr.getDouble(i);
									low = "l:" + App.df.format(mn) + ":t" + (i + 1 - ln);
								}
							}
							if (o > c) {
								wik = (c - l) / (o - c);
								wikbear = (h - o) / (o - c);
							} else if (o < c) {
								wik = (o - l) / (c - o);
								wikbear = (h - c) / (c - o);
							}
							if (wik > 1.6) {
								if (o == h) {
									bullishCandle.append(code + ":o=h:wk=" + App.df.format(wik) + "[" + high + "," + low
											+ "][" + App.df.format(h) + "," + App.df.format(l) + "]%0A");
								} else if (c == h) {
									bullishCandle.append(code + ":c=h:wk=" + App.df.format(wik) + "[" + high + "," + low
											+ "][" + App.df.format(h) + "," + App.df.format(l) + "]%0A");
								} else {
									bullishCandle.append(code + ":wk=" + App.df.format(wik) + "[" + high + "," + low
											+ "][" + App.df.format(h) + "," + App.df.format(l) + "]%0A");
								}
							}
							if (wikbear > 1.6) {
								if (o == l) {
									bearishCandle.append(code + ":o=l:wk=" + App.df.format(wikbear) + "[" + high + ","
											+ low + "][" + App.df.format(h) + "," + App.df.format(l) + "]%0A");
								} else if (c == l) {
									bearishCandle.append(code + ":c=l:wk=" + App.df.format(wikbear) + "[" + high + ","
											+ low + "][" + App.df.format(h) + "," + App.df.format(l) + "]%0A");
								} else {
									bearishCandle.append(code + ":wk=" + App.df.format(wikbear) + "[" + high + "," + low
											+ "][" + App.df.format(h) + "," + App.df.format(l) + "]%0A");
								}
							}
						} catch (Exception xp) {
							xp.printStackTrace();
						}
						// down trend
						int downcnt = 0;
						int mn = 0;
						try {
							if (ln > 4)
								mn = ln - 4;
							double vttimes = 0.0;
							for (int i = ln - 1; i > mn; i--) {
								long pvol = volarr.getLong(i - 1);
								long cvol = volarr.getLong(i);
								double vtimes = (cvol * 1.0) / pvol;
								// System.out.println(vtimes+",d="+downcnt);
								if (vtimes > 5) {
									insiderT.append("<b><i>" + code + "-cls:" + App.df.format(clsarr.getDouble(i))
											+ "-v=" + App.df.format(vtimes) + ",d=" + (ln - 1 - i) + "%0A</i></b>");
								}
								if (vtimes > 1) {
									if ((opnarr.getDouble(i) > clsarr.getDouble(i))) {
										if (i == ln - 1) {
											if ((clsarr.getDouble(i) < lowarr.getDouble(i - 1))) {
												downcnt = downcnt + 1;
												vttimes = vtimes;
											}
										} else {
											// if((lowarr.getDouble(i) < lowarr.getDouble(i-1))) {
											if ((clsarr.getDouble(i) < clsarr.getDouble(i - 1))) {
												downcnt = downcnt + 1;
											}
										}
									}
								}
							}
							if (downcnt > 2 && ln > 0) {
								insiderT.append(code + "-cls:" + App.df.format(clsarr.getDouble(ln - 1)) + "-v="
										+ App.df.format(vttimes) + ",dt=" + downcnt + "%0A");
							}
						} catch (Exception ppx) {
							ppx.printStackTrace();
						}
					}
				} catch (Exception pz) {
					System.out.println("for scrip:" + code);
					pz.printStackTrace();
				}
			}
			TelegramUtil.sendTelegramMsg(bullishCandle.toString(), "-485376339", false);
			TelegramUtil.sendTelegramMsg(bearishCandle.toString(), "-485376339", false);
			TelegramUtil.sendTelegramMsg(insiderT.toString(), "-485376339", false);
		} catch (Exception xp) {
			xp.printStackTrace();
		}
	}
	public void chart5paisa(Properties prop, Properties propconfig) throws Exception {
		java.util.Date dat = new java.util.Date();
		String visited = "" + dat + ",";
		String visitedoption = "" + dat + ",";
		String visitedoptionweek = "Weekly" + dat + ",";
		System.setProperty("webdriver.edge.driver", propconfig.getProperty("edgedriverlocation"));
		// System.setProperty("webdriver.gecko.driver",
		// propconfig.getProperty("geckodriverlocation"));
		/*
		 * String firefoxlocation = (String)(prop.remove("firefoxlocation"));
		 * FirefoxBinary ffox = new FirefoxBinary(new File(firefoxlocation));
		 * FirefoxOptions firefoxOptions = new FirefoxOptions();
		 * firefoxOptions.setHeadless(false); firefoxOptions.setBinary(ffox);
		 * 
		 * String optionscrips5paisa = (String)(prop.remove("optionscrips5paisa"));
		 * String optionscrips5paisaBSE =
		 * (String)(prop.remove("optionscrips5paisaBSE")); String awsserverurl =
		 * (String)(prop.remove("awsserverurl")); String charturlorig =
		 * (String)(prop.remove("charturl")); String day1profile =
		 * (String)(prop.remove("firefoxprofilewithlocation1day")); String week1profile
		 * = (String)(prop.remove("firefoxprofilewithlocation1week")); String
		 * hr4min15profile = (String)(prop.remove("firefoxprofilewithlocation"));
		 * prop.remove("geckodriverlocation"); charturlorig =
		 * charturlorig.replace("?loginid", loginid);
		 */
		// 15-min 4-hr
		/*
		 * try { FirefoxProfile profile = new FirefoxProfile(new File(hr4min15profile));
		 * firefoxOptions.setProfile(profile); WebDriver driver = new
		 * FirefoxDriver(firefoxOptions); driver.manage().window().maximize(); Actions
		 * actions = new Actions(driver); for(String key : prop.stringPropertyNames()) {
		 * String charturl = charturlorig; visited = visited + key +","; String value =
		 * prop.getProperty(key); try { charturl = charturl.replace("?scripcode",
		 * value); charturl = charturl.replace("?symbol", URLEncoder.encode(key,
		 * "UTF-8")); log.info("----------->>5paisa capturing image for scripcode:"
		 * +key+" charturl:"+charturl); driver.get(charturl); Thread.sleep(8000); /*
		 * WebElement viewbtn = driver.findElement(By.className("ciq-views"));
		 * viewbtn.click(); WebElement viewbtn15min = viewbtn.findElement(By.xpath(
		 * "cq-menu-dropdown/cq-views/cq-views-content/cq-item[1]"));
		 * actions.moveToElement(viewbtn15min).click().perform(); Thread.sleep(8000);
		 * TakesScreenshot scrShot =((TakesScreenshot)driver);
		 * uploadImage(scrShot.getScreenshotAs(OutputType.BYTES), key+"_15min.png",
		 * awsserverurl); Thread.sleep(4000);
		 *//*
			 * WebElement viewbtn = driver.findElement(By.className("ciq-views"));
			 * viewbtn.click(); WebElement viewbtn30min = viewbtn.findElement(By.xpath(
			 * "cq-menu-dropdown/cq-views/cq-views-content/cq-item[2]"));
			 * actions.moveToElement(viewbtn30min).click().perform(); Thread.sleep(8000);
			 * TakesScreenshot scrShot =((TakesScreenshot)driver);
			 * uploadImage(scrShot.getScreenshotAs(OutputType.BYTES), key+"_4hr.png",
			 * awsserverurl); Thread.sleep(4000); }catch(Exception px) { log.
			 * error("having some issue in 5paisa capturing 15min-4hr image for scripcode:"
			 * +key+" charturl:"+charturl, px); } } driver.quit(); }catch(Exception x) {
			 * log.error("having some issue in 5paisa capturing 15min-4hr image", x); }
			 * Thread.sleep(60000);
			 */
		// 1-day
		org.apache.commons.net.ftp.FTPClient ftpClient = null;
		try {
			CallableChartExecutor c1 = new CallableChartExecutor(prop, propconfig, "RSTUVWXYZ",
					"C:\\\\selenium\\\\edgeprofile4");
			FutureTask f1 = new FutureTask(c1);
			Thread t1 = new Thread(f1);
			t1.start();
			CallableChartExecutor c2 = new CallableChartExecutor(prop, propconfig, "KLMNOPQ",
					"C:\\\\selenium\\\\edgeprofile1");
			FutureTask f2 = new FutureTask(c2);
			Thread t2 = new Thread(f2);
			t2.start();
			Thread.sleep(60000);
			CallableChartExecutor c3 = new CallableChartExecutor(prop, propconfig, "DEFGHIJ",
					"C:\\\\selenium\\\\edgeprofile2");
			FutureTask f3 = new FutureTask(c3);
			Thread t3 = new Thread(f3);
			t3.start();
			Thread.sleep(60000);
			CallableChartExecutor c4 = new CallableChartExecutor(prop, propconfig, "ABC",
					"C:\\\\selenium\\\\edgeprofile3");
			FutureTask f4 = new FutureTask(c4);
			Thread t4 = new Thread(f4);
			t4.start();
			String v1 = (String) f1.get();
			String v2 = (String) f2.get();
			String v3 = (String) f3.get();
			String v4 = (String) f4.get();
			visited = visited + v1 + v2 + v3 + v4;
			System.out.println("##################################################" + visited);
			String awsserverurl = (String) (propconfig.remove("awsserverurl"));
			if (ftpClient == null) {
				ftpClient = new org.apache.commons.net.ftp.FTPClient();
				ftpClient.connect("ftp.shubhday.com", 21);
				ftpClient.login("u117696066.hostingerftpuser", "Uma@1983");
				ftpClient.enterLocalPassiveMode();
				ftpClient.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
			}
			try {
				uploadImage(ftpClient, visited.getBytes(), "chartforscrips.txt", awsserverurl);
			} catch (Exception x) {
				System.out.println(
						"ERROR#################Some issue 5paisa chart picker image capture and sending file detail.");
				x.printStackTrace();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (ftpClient.isConnected()) {
					ftpClient.logout();
					ftpClient.disconnect();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		/*
		 * Thread.sleep(60000); //4hr-option try { String _time =
		 * WatchBuySellConst.HH_MM_FORMATTER.format(new java.util.Date()); String[]t =
		 * _time.split("_"); if(optionscrips5paisa != null &&
		 * optionscrips5paisa.trim().length() > 0) { FirefoxProfile profile = new
		 * FirefoxProfile(new File(hr4min15profile));
		 * firefoxOptions.setProfile(profile); WebDriver driver = new
		 * FirefoxDriver(firefoxOptions); driver.manage().window().maximize(); Actions
		 * actions = new Actions(driver); String []scrips =
		 * optionscrips5paisa.split(","); for(String snamecode : scrips) { String
		 * []namecd = snamecode.split("-"); visitedoption = visitedoption + namecd[0]
		 * +","; if(prop.containsKey(namecd[0]) == false) { String charturl =
		 * charturlorig; try { charturl = charturl.replace("?scripcode", namecd[1]);
		 * charturl = charturl.replace("?symbol", URLEncoder.encode(namecd[0],
		 * "UTF-8"));
		 * log.info("----------->>5paisa capturing image 4hr for scripcode:"+namecd[0]
		 * +" charturl:"+charturl); driver.get(charturl); Thread.sleep(8000);
		 * 
		 * WebElement viewbtn = driver.findElement(By.className("ciq-views"));
		 * viewbtn.click(); WebElement viewbtn15min = viewbtn.findElement(By.xpath(
		 * "cq-menu-dropdown/cq-views/cq-views-content/cq-item[2]"));
		 * actions.moveToElement(viewbtn15min).click().perform(); Thread.sleep(8000);
		 * TakesScreenshot scrShot =((TakesScreenshot)driver);
		 * uploadImage(scrShot.getScreenshotAs(OutputType.BYTES), namecd[0]+"_4hr.png",
		 * awsserverurl); Thread.sleep(4000); }catch(Exception px) { log.
		 * error("having some issue in 5paisa capturing 4hr image for option scripcode:"
		 * +namecd[0]+" charturl:"+charturl, px); } } } driver.quit(); }
		 * }catch(Exception x) {
		 * log.error("having some issue in 5paisa capturing 4hr image optionscrip", x);
		 * }
		 * 
		 * try { uploadImage(visitedoption.getBytes(), "chartforscripsoption.txt",
		 * awsserverurl); }catch(Exception x) { log.
		 * error("ERROR#################Some issue 5paisa chart picker image capture and sending file detail."
		 * , x); }
		 */
		/*
		 * //weekly try { java.util.Date dt = new java.util.Date(); String _time =
		 * WatchBuySellConst.HH_MM_FORMATTER.format(dt); String[]t = _time.split("_");
		 * //if((dt.getDay() == 4 || dt.getDay() == 5) && Integer.parseInt(t[0]) >= 16
		 * && optionscrips5paisa != null && optionscrips5paisa.trim().length() > 0) {
		 * if(1 == 1) { Thread.sleep(60000); FirefoxProfile profile = new
		 * FirefoxProfile(new File(week1profile)); firefoxOptions.setProfile(profile);
		 * WebDriver driver = new FirefoxDriver(firefoxOptions);
		 * driver.manage().window().maximize(); Actions actions = new Actions(driver);
		 * String []scrips = optionscrips5paisa.split(","); String []scripsBSE =
		 * optionscrips5paisaBSE.split(","); for(String snamecode : scripsBSE) { String
		 * []namecd = snamecode.split("-"); visitedoptionweek = visitedoptionweek +
		 * namecd[0] +","; String charturlnse = charturlorig; try { charturlnse =
		 * charturlnse.replace("?scripcode", namecd[1]); charturlnse =
		 * charturlnse.replace("exchange=nse", "exchange=bse"); charturlnse =
		 * charturlnse.replace("?symbol", URLEncoder.encode(namecd[0], "UTF-8"));
		 * log.info("----------->>5paisa capturing image 1week bse for scripcode:"
		 * +namecd[0]+" charturl:"+charturlnse); driver.get(charturlnse);
		 * Thread.sleep(8000);
		 * 
		 * WebElement viewbtn = driver.findElement(By.className("ciq-views"));
		 * viewbtn.click(); WebElement viewbtn15min = viewbtn.findElement(By.xpath(
		 * "cq-menu-dropdown/cq-views/cq-views-content/cq-item[1]"));
		 * actions.moveToElement(viewbtn15min).click().perform(); Thread.sleep(8000);
		 * TakesScreenshot scrShot =((TakesScreenshot)driver);
		 * uploadImage(scrShot.getScreenshotAs(OutputType.BYTES),
		 * namecd[0]+"_1wkBSE.png", awsserverurl); Thread.sleep(4000); }catch(Exception
		 * px) { log.
		 * error("having some issue in 5paisa capturing 1week bse image for option scripcode:"
		 * +namecd[0]+" charturl:"+charturlnse, px); } } for(String snamecode : scrips)
		 * { String []namecd = snamecode.split("-"); String charturl = charturlorig; try
		 * { charturl = charturl.replace("?scripcode", namecd[1]); charturl =
		 * charturl.replace("?symbol", URLEncoder.encode(namecd[0], "UTF-8"));
		 * log.info("----------->>5paisa capturing image 1week nse for scripcode:"
		 * +namecd[0]+" charturl:"+charturl); driver.get(charturl); Thread.sleep(8000);
		 * 
		 * WebElement viewbtn = driver.findElement(By.className("ciq-views"));
		 * viewbtn.click(); WebElement viewbtn15min = viewbtn.findElement(By.xpath(
		 * "cq-menu-dropdown/cq-views/cq-views-content/cq-item[1]"));
		 * actions.moveToElement(viewbtn15min).click().perform(); Thread.sleep(8000);
		 * TakesScreenshot scrShot =((TakesScreenshot)driver);
		 * uploadImage(scrShot.getScreenshotAs(OutputType.BYTES),
		 * namecd[0]+"_1wkNSE.png", awsserverurl); Thread.sleep(4000); }catch(Exception
		 * px) { log.
		 * error("having some issue in 5paisa capturing 1week nse image for option scripcode:"
		 * +namecd[0]+" charturl:"+charturl, px); } } try { driver.quit(); }
		 * catch(Exception x) { }
		 * 
		 * try { uploadImage(visitedoptionweek.getBytes(),
		 * "chartforscripsoptionweekly.txt", awsserverurl); }catch(Exception x) { log.
		 * error("ERROR#################Some issue 5paisa weekly chart picker image capture and sending file detail."
		 * , x); } } }catch(Exception x) {
		 * log.error("having some issue in 5paisa capturing weekly image optionscrip",
		 * x); }
		 */
		try {
			TelegramUtil.sendTelegramMsg("5paisa chart picker. I am live....", "-485376339", false);
		} catch (Exception _exp) {
			System.out.println("ERROR#################Some issue 5paisa chart picker telegram msg for scrips sending.");
			_exp.printStackTrace();
		}
	}
	class TodaysScripPriceCheckerExecutor implements Runnable {
		Double pricechng = 4.8;
		Boolean isMorningTime = false;
		public TodaysScripPriceCheckerExecutor(Double pricechng, Boolean isMorningTime) {
			this.pricechng = pricechng;
			this.isMorningTime = isMorningTime;
		}
		@Override
		public void run() {
			System.out.println("TodaysScripPriceCheckerExecutor Trading*************************");
			for (int lpcnt = 0; lpcnt < 15; lpcnt++) {
				todaysScripPrcChange(this.pricechng, this.isMorningTime);
			}
		}
	}
	public static void todaysScripPrcChange(Double pricechng, Boolean isMorningTime) {
		try {
			String telemsg = "";
			CookieHandler.setDefault(new CookieManager());
			HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000))
					.version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault()).build();
			java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
					.setHeader("Accept-Encoding", "deflate, br")
					.setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")
					// .setHeader("Connection", "keep-alive")
					// .setHeader("Host", "www.nseindia.com")
					.setHeader("Referer", "https://www.nseindia.com/")
					.setHeader("User-Agent",
							"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
					.setHeader("Accept",
							"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
					.setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(55000)).GET();
			HttpResponse<String> rootSiteResp = client.send(
					_reqBuilder.uri(URI.create("https://www.nseindia.com/")).build(),
					HttpResponse.BodyHandlers.ofString());
			if (rootSiteResp.statusCode() == 200) {
				String _rcddateurl = "https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%20100";
				HttpResponse<String> resp = client.send(_reqBuilder.uri(URI.create(_rcddateurl)).build(),
						HttpResponse.BodyHandlers.ofString());
				if (resp.statusCode() == 200) {
					String sb = resp.body();
					if (sb == null) {
						System.out.println(
								"###############********************unable to fetch record date and financial result data from:"
										+ _rcddateurl + ". _jnode:" + sb);
					} else {
						JSONObject json = new JSONObject(sb);
						JSONArray datanode = json.getJSONArray("data");
						if (datanode != null) {
							String symb = "";
							for (int ix = 0; ix < datanode.length(); ix++) {
								JSONObject insider = datanode.getJSONObject(ix);
								symb = insider.getString("symbol");
								Double ltp = insider.getDouble("lastPrice");
								Double opn = insider.getDouble("open");
								Double previousClose = insider.getDouble("previousClose");
								Double chngp = 0.0;
								if (isMorningTime) {
									chngp = ((ltp - previousClose) * 100) / previousClose;
								} else {
									chngp = ((ltp - opn) * 100) / opn;
								}
								if ("NIFTY 100".equalsIgnoreCase(symb)) {
									if (chngp <= -1.8) {
										telemsg = telemsg + ">p" + String.format("%.1f", chngp) + symb + "%0A";
									} else if (chngp >= 2.1) {
										telemsg = telemsg + ">p" + String.format("%.1f", chngp) + symb + "%0A";
									}
								} else {
									if (chngp <= (-1 * pricechng)) {
										telemsg = telemsg + ">p" + String.format("%.1f", chngp) + symb + "=" + ltp
												+ "%0A";
									} else if (chngp >= pricechng) {
										telemsg = telemsg + ">p" + String.format("%.1f", chngp) + symb + "=" + ltp
												+ "%0A";
									}
								}
							}
							if (telemsg != null && telemsg.length() > 10) {
								TelegramUtil.sendTelegramMsg(telemsg, "-446563244", false);
							}
						}
					}
				}
			}
			Thread.sleep(60000);
		} catch (Exception ign) {
			ign.printStackTrace();
		}
	}
	class InsiderTradeExecutor implements Runnable {
		Properties prop;
		public InsiderTradeExecutor(Properties prp) {
			prop = prp;
		}
		@Override
		public void run() {
			System.out.println("Insider Trading*************************");
			InputStream is = null;
			try {
				// is = new URL("https://www.nseindia.com/api/corporates-pit?").openStream();
				CookieHandler.setDefault(new CookieManager());
				HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000))
						.version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault()).build();
				java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
						.setHeader("Accept-Encoding", "deflate, br")
						.setHeader("Accept-Language", "Accept-Language: en-US,en;q=0.5")// .setHeader("Connection",
																						// "keep-alive")
						// .setHeader("Host", "www.nseindia.com")
						.setHeader("Referer", "https://www.nseindia.com/")
						.setHeader("User-Agent",
								"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
						.setHeader("Accept",
								"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
						.setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(35000)).GET();
				HttpResponse<String> rootSiteResp = client.send(
						_reqBuilder.uri(URI.create("https://www.nseindia.com/")).build(),
						HttpResponse.BodyHandlers.ofString());
				if (rootSiteResp.statusCode() == 200) {
					String _rcddateurl = "https://www.nseindia.com/api/corporates-pit?";
					HttpResponse<String> resp = client.send(_reqBuilder.uri(URI.create(_rcddateurl)).build(),
							HttpResponse.BodyHandlers.ofString());
					if (resp.statusCode() == 200) {
						String sb = resp.body();
						JSONObject json = new JSONObject(sb);
						JSONArray jar = json.getJSONArray("data");
						if (jar != null) {
							Map<String, Map<String, Integer>> scrpmap = new HashMap<>();
							for (int ix = 0; ix < jar.length(); ix++) {
								JSONObject insider = jar.getJSONObject(ix);
								String symbol = insider.getString("symbol");
								String date = insider.getString("date").substring(0, 10);
								String ttype = insider.getString("tdpTransactionType");
								int qty = Integer.valueOf(insider.getString("secAcq"));
								Map<String, Integer> dtmap = scrpmap.getOrDefault(symbol,
										new HashMap<String, Integer>());
								int count = dtmap.getOrDefault(date, 0);
								if ("Sell".equalsIgnoreCase(ttype)) {
									count = count - qty;
								} else if ("Buy".equalsIgnoreCase(ttype)) {
									count = count + qty;
								}
								dtmap.put(date, count);
								scrpmap.put(symbol, dtmap);
							}
							StringBuffer insiderT = new StringBuffer("InsiderTrade:%0A");
							for (Map.Entry<String, Map<String, Integer>> entryMap : scrpmap.entrySet()) {
								for (Map.Entry<String, Integer> entry : entryMap.getValue().entrySet()) {
									String symb = entryMap.getKey();
									String dt = entry.getKey();
									int qty = entry.getValue();
									if (prop.containsKey(symb)) {
										if (qty > 100000) {
											insiderT.append(dt + ":" + symb + ":" + qty + "%0A");
										}
									} else {
										if (qty > 300000) {
											insiderT.append(dt + ":" + symb + ":" + qty + "%0A");
										}
									}
								}
							}
							try {
								TelegramUtil.sendTelegramMsg(insiderT.toString(), "-485376339", false);
							} catch (Exception _exp) {
								System.out.println(
										"ERROR#################Some issue 5paisa chart picker telegram msg for scrips sending.");
								_exp.printStackTrace();
							}
						}
					}
				}
				/*
				 * URL url = new URL("https://www.nseindia.com/api/corporates-pit?");
				 * HttpURLConnection request = (HttpURLConnection)(url.openConnection());
				 * request.setRequestMethod("GET"); request.setRequestProperty("Cookie",
				 * "ak_bmsc=A5C12077052E5353BF6E36DB6B470562~000000000000000000000000000000~YAAQy7YRYMxf0huFAQAA7hDxYhJkOXB1GlLW3v0gTRVt8jCuHyen2x5KJ+j0m6siA3vkLvh1okHH8+NufZGDRZUwagYF636Rn3GUYQ6jVVZI80KpwBqK4k+2OHwarfdh1TF8dlmToTaF4ED4aTprgDR8hLmRWzeWxn3eTsYMBkl98/RSJhNdRB0ZQY0VrqDnGQjyTvjeRVamFUz6N9IOUY7wxHBloAtLLoFTC2ZkgI3xSPbjvh3Oxfs3bBTj743Am3U/fGkSNar6eGlV5l0Axyyurki8EiFuM/FABuHkxCR0G/P+y3lzDMEU2ZU7zujnHhgyxmUtAnMI+eYDhhuU1nKkdOlvSziBufbDKZ5Kw0sXUawACU8v1wTbp4vHfQ=="
				 * ); request.setUseCaches(false); request.setDoInput(true);
				 * request.setDoOutput(true);
				 * 
				 * request.connect(); is = (InputStream) request.getContent();
				 * System.out.println("insider=$$$===@@"); BufferedReader rd = new
				 * BufferedReader(new InputStreamReader(is, "UTF-8")); StringBuilder sb = new
				 * StringBuilder(); int cp = 0; while ((cp = rd.read()) != -1) {
				 * System.out.println("insider=$$$==="+sb); sb.append((char) cp); }
				 * System.out.println("insider===="+sb); JSONObject json = new JSONObject(sb);
				 * JSONArray jar = json.getJSONArray("data"); if(jar != null) { Map<String,
				 * Map<String, Integer>> scrpmap = new HashMap<>(); for (int ix=0;
				 * ix<jar.length();ix++) { JSONObject insider = jar.getJSONObject(ix); String
				 * symbol = insider.getString("symbol"); String date =
				 * insider.getString("date").substring(0, 10); String ttype =
				 * insider.getString("tdpTransactionType"); int qty =
				 * Integer.valueOf(insider.getString("secAcq"));
				 * 
				 * Map<String, Integer> dtmap = scrpmap.getOrDefault(symbol, new HashMap<String,
				 * Integer>()); int count = dtmap.getOrDefault(date, 0);
				 * if("Sell".equalsIgnoreCase(ttype)) { count = count - qty; }else
				 * if("Buy".equalsIgnoreCase(ttype)) { count = count + qty; } dtmap.put(date,
				 * count); scrpmap.put(symbol, dtmap); }
				 * 
				 * StringBuffer insiderT = new StringBuffer("InsiderTrade:%0A");
				 * 
				 * for (Map.Entry<String,Map<String, Integer>> entryMap : scrpmap.entrySet()) {
				 * for (Map.Entry<String, Integer> entry : entryMap.getValue().entrySet()) {
				 * String symb = entryMap.getKey(); String dt = entry.getKey(); int qty =
				 * entry.getValue(); if(prop.containsKey(symb)) { if(qty > 100000) {
				 * insiderT.append(dt+":"+symb+":"+qty+"%0A"); } }else { if(qty > 300000) {
				 * insiderT.append(dt+":"+symb+":"+qty+"%0A"); } } } } try {
				 * TelegramUtil.sendTelegramMsg(insiderT.toString(), "-485376339", false); }
				 * catch (Exception _exp) { System.out.
				 * println("ERROR#################Some issue 5paisa chart picker telegram msg for scrips sending."
				 * ); _exp.printStackTrace(); } }
				 */
			} catch (Exception ign) {
				ign.printStackTrace();
			} finally {
				try {
					is.close();
				} catch (Exception ig) {
				}
			}
			try {
				System.out.println("-------------processFinancialResultsFromBSELiveDate---------------");
				processFinancialResultsFromBSELiveDate(prop);
			} catch (Exception ign) {
				ign.printStackTrace();
			}
		}
	}
	class CallableChartExecutor implements Callable {
		Properties prop;
		Properties propconfig;
		String stockNames;
		String profilename;
		public CallableChartExecutor(Properties prop, Properties propconfig, String stockNames, String profilename) {
			this.prop = prop;
			this.propconfig = propconfig;
			this.stockNames = stockNames;
			this.profilename = profilename;
		}
		@Override
		public Object call() throws Exception {
			org.apache.commons.net.ftp.FTPClient ftpClient = null;
			String visited = "";
			try {
				System.out.println(stockNames + "---------Thread:" + Thread.currentThread());
				System.setProperty("webdriver.edge.driver", propconfig.getProperty("edgedriverlocation"));
				String optionscrips5paisa = (String) (propconfig.get("optionscrips5paisa"));
				String optionscrips5paisaBSE = (String) (propconfig.get("optionscrips5paisaBSE"));
				String awsserverurl = (String) (propconfig.get("awsserverurl"));
				String charturlorig = (String) (propconfig.get("charturl"));
				String day1profile = (String) (propconfig.get("firefoxprofilewithlocation1day"));
				String week1profile = (String) (propconfig.get("firefoxprofilewithlocation1week"));
				String hr4min15profile = (String) (propconfig.get("firefoxprofilewithlocation"));
				// prop.remove("geckodriverlocation");
				charturlorig = charturlorig.replace("?loginid", loginid);
				/*
				 * String firefoxlocation = (String)(propconfig.get("firefoxlocation"));
				 * org.openqa.selenium.firefox.FirefoxBinary ffox = new
				 * org.openqa.selenium.firefox.FirefoxBinary(new File(firefoxlocation));
				 * org.openqa.selenium.firefox.FirefoxProfile profile = new
				 * org.openqa.selenium.firefox.FirefoxProfile(new File(day1profile));
				 * org.openqa.selenium.firefox.FirefoxOptions firefoxOptions = new
				 * org.openqa.selenium.firefox.FirefoxOptions();
				 * firefoxOptions.setProfile(profile); firefoxOptions.setHeadless(false);
				 * firefoxOptions.setBinary(ffox); org.openqa.selenium.WebDriver driver = new
				 * org.openqa.selenium.firefox.FirefoxDriver(firefoxOptions);
				 */
				org.openqa.selenium.edge.EdgeOptions options = new org.openqa.selenium.edge.EdgeOptions();
				options.setBinary("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe");
				// options.addArguments("--headless=false");
				// options.addArguments("--remote-allow-origins=9222");
				options.addArguments("--no-sandbox");
				options.addArguments("--disable-dev-shm-usage");
				options.addArguments("window-size=2160x4200");
				// Here you set the path of the profile ending with User Data not the profile
				// folder
				options.addArguments("user-data-dir=" + profilename);
				// options.addArguments("user-data-dir=C:\\Users\\SK76365\\AppData\\Local\\Microsoft\\Edge\\User
				// Data");
				// Here you specify the actual profile folder
				options.addArguments("profile-directory=day1edge");
				org.openqa.selenium.WebDriver driver = new org.openqa.selenium.edge.EdgeDriver(options);
				driver.manage().window().maximize();
				org.openqa.selenium.interactions.Actions actions = new org.openqa.selenium.interactions.Actions(driver);
				int count = 0;
				java.util.Set<String> st = prop.stringPropertyNames();
				List<String> lst = st.stream().sorted().collect(Collectors.toList());
				for (String key : lst) {
					if (stockNames.contains("" + key.charAt(0)) == true
							|| stockNames.toLowerCase().contains("" + key.charAt(0)) == true) {
						System.out.println("-----$$$$$$$$$$$$$----key:" + key);
						/*
						 * if(count ==35 || count==70) { driver.quit(); Thread.sleep(15000); profile =
						 * new FirefoxProfile(new File(day1profile));
						 * firefoxOptions.setProfile(profile); driver = new
						 * FirefoxDriver(firefoxOptions); driver.manage().window().maximize(); actions =
						 * new Actions(driver); }
						 */
						count = count + 1;
						visited = visited + key + ",";
						String charturl = charturlorig;
						String value = prop.getProperty(key);
						try {
							if (value != null) {
								if (value.startsWith("#")) {
									charturl = charturl.replace("?scripcode", value.substring(1));
									charturl = charturl.replace("?symbol", URLEncoder.encode(key, "UTF-8"));
								} else {
									charturl = charturl.replace("exchange=nse", "exchange=bse");
									charturl = charturl.replace("?scripcode", value.substring(0, value.indexOf("#")));
									charturl = charturl.replace("?symbol", URLEncoder.encode(key, "UTF-8"));
								}
							}
							System.out.println(count + "----------->>5paisa capturing image 1day for scripcode:" + key
									+ " charturl:" + charturl);
							driver.get(charturl);
							Thread.sleep(5000);
							try {
								org.openqa.selenium.WebElement viewbtn = driver
										.findElement(org.openqa.selenium.By.className("ciq-views"));
								viewbtn.click();
								org.openqa.selenium.WebElement viewbtn15min = new org.openqa.selenium.support.ui.WebDriverWait(
										driver, java.time.Duration.ofSeconds(30))
										.until(org.openqa.selenium.support.ui.ExpectedConditions
												.presenceOfElementLocated(
														org.openqa.selenium.By.className("view-name-day2")));
								// WebElement viewbtn15min = new
								// org.openqa.selenium.support.ui.WebDriverWait(driver,
								// 15).until(org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated(By.xpath("cq-menu-dropdown/cq-views/cq-views-content/cq-item")));
								// WebElement viewbtn15min =
								// viewbtn.findElement(By.xpath("cq-menu-dropdown/cq-views/cq-views-content/cq-item"));
								actions.moveToElement(viewbtn15min).click().perform();
								Thread.sleep(1000);
								org.openqa.selenium.WebElement minbtn = driver
										.findElement(org.openqa.selenium.By.className("stx-zoom-out"));// driver.findElement(By.className("stx-zoom-in"));
								actions.moveToElement(minbtn).click().perform();
								actions.moveToElement(minbtn).click().perform();
								/*
								 * actions.moveToElement(minbtn).click().perform();
								 * actions.moveToElement(minbtn).click().perform();
								 * actions.moveToElement(minbtn).click().perform(); Thread.sleep(2000);
								 */
								org.openqa.selenium.WebElement jumptoday = driver
										.findElement(org.openqa.selenium.By.className("stx_jump_today"));
								actions.moveToElement(jumptoday).click().perform();
							} catch (Exception v) {
								v.printStackTrace();
							}
							/*
							 * minbtn.click(); Thread.sleep(2000); minbtn.click(); Thread.sleep(2000);
							 * minbtn.click(); Thread.sleep(2000); minbtn.click();
							 */
							// WebElement day1Wk1btn = driver.findElement(By.className("ciq-period"));
							// day1Wk1btn.click();
							// WebElement day1view =
							// day1Wk1btn.findElement(By.xpath("cq-menu-dropdown/cq-item[1]"));
							// --WebElement day1view =
							// day1Wk1btn.findElement(By.xpath("/html/body/cq-context/div[1]/div/div[1]/cq-menu[1]/cq-menu-dropdown/cq-item[2]"));
							// --WebElement day1view = day1Wk1btn.findElement(By.className("ciq-interval
							// comCls"));
							// actions.moveToElement(day1view).click().perform();
							// Thread.sleep(2000);
							org.openqa.selenium.TakesScreenshot scrShot = ((org.openqa.selenium.TakesScreenshot) driver);
							Thread.sleep(3000);
							if (ftpClient == null) {
								ftpClient = new org.apache.commons.net.ftp.FTPClient();
								ftpClient.connect("ftp.shubhday.com", 21);
								ftpClient.login("u117696066.hostingerftpuser", "Uma@1983");
								ftpClient.enterLocalPassiveMode();
								ftpClient.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
							}
							uploadImage(ftpClient, scrShot.getScreenshotAs(org.openqa.selenium.OutputType.BYTES),
									key + "_1day.png", awsserverurl);
						} catch (Exception px) {
							System.out.println("having some issue in 5paisa capturing 1 day image for scripcode:" + key
									+ " charturl:" + charturl);
							px.printStackTrace();
						}
					}
				}
				driver.quit();
			} catch (Exception x) {
				System.out.println("having some issue in 5paisa capturing 1 day image");
				x.printStackTrace();
			} finally {
				try {
					if (ftpClient != null && ftpClient.isConnected()) {
						ftpClient.logout();
						ftpClient.disconnect();
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			return visited;
		}
	}
	public void uploadImage(org.apache.commons.net.ftp.FTPClient ftpClient, byte[] filetoload, String filename,
			String awsserverurl) throws Exception {
		System.out.println("--->Uploading file:" + filename);
		ftpClient.storeFile(filename, new ByteArrayInputStream(filetoload));
		/*
		 * String ftpUrl =
		 * "ftp://u117696066.hostingerftpuser:Uma@1983@ftp.shubhday.com/home/u117696066/domains/shubhday.com/public_html/chart/"
		 * +filename+";type=i"; System.out.println("Upload URL: " + ftpUrl); URL url =
		 * new URL(ftpUrl); URLConnection conn = url.openConnection(); OutputStream
		 * outputStream = conn.getOutputStream(); outputStream.write(filetoload);
		 * outputStream.close();
		 */
		System.out.println("File uploaded****" + filename);
		/*
		 * try (FileOutputStream stream = new FileOutputStream(
		 * "D:\\magicbricks\\projects\\watchbuysell\\view\\5paisa-chart\\"+filename)) {
		 * stream.write(filetoload); }
		 */
		/*
		 * RestTemplate restTemplate = new RestTemplate(); FormHttpMessageConverter
		 * formConverter = new FormHttpMessageConverter();
		 * formConverter.setCharset(Charset.forName("UTF8"));
		 * restTemplate.getMessageConverters().add(formConverter);
		 * restTemplate.getMessageConverters().add(new
		 * MappingJackson2HttpMessageConverter()); restTemplate.setRequestFactory(new
		 * HttpComponentsClientHttpRequestFactory());
		 * 
		 * MultiValueMap<String, Object> parts = new LinkedMultiValueMap<String,
		 * Object>(); parts.add("filedata", new ByteArrayResource(filetoload) {
		 * 
		 * @Override public String getFilename() { return filename; } });
		 * parts.add("filename", filename); restTemplate.postForLocation(awsserverurl,
		 * parts);
		 */
		/*
		 * RestTemplate restTemplate = new RestTemplate(); MultiValueMap<String, Object>
		 * parts = new LinkedMultiValueMap<String, Object>(); parts.add("filedata", new
		 * ByteArrayResource(filetoload)); parts.add("filename", filename); HttpHeaders
		 * httpHeaders = new HttpHeaders();
		 * httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
		 * httpHeaders.setAccept(Collections.singletonList(MediaType.parseMediaType(
		 * "application/json"))); HttpEntity<LinkedMultiValueMap<String, Object>>
		 * httpEntity = new HttpEntity(parts, httpHeaders);
		 * restTemplate.exchange("http://localhost:9000/api/scrips/chart",
		 * HttpMethod.POST, httpEntity,String.class);
		 * //restTemplate.postForEntity("http://localhost:9000/api/scrips/chart",
		 * httpEntity, String.class);
		 */
	}
	public void chartZerodha(String configfile) throws Exception {
		/*
		 * FirefoxProfile profile = new FirefoxProfile(new
		 * File(prop.getProperty("firefoxprofilewithlocation")));
		 * firefoxOptions.setProfile(profile); WebDriver driver = new
		 * FirefoxDriver(firefoxOptions); driver.manage().window().maximize(); try {
		 * String awsserverurl = (String)(prop.remove("awsserverurl"));
		 * prop.remove("firefoxprofilewithlocation");
		 * prop.remove("geckodriverlocation"); String charturlorig =
		 * "https://kite.zerodha.com/"; driver.get(charturlorig); Thread.sleep(30000);
		 * try { WebElement usr = driver.findElement(By.id("userid"));
		 * usr.sendKeys("VC3861"); }catch(Exception xp) { xp.printStackTrace(); }
		 * WebElement pas = driver.findElement(By.id("password")); WebElement btn =
		 * driver.findElement(By.className("button-orange")); pas.sendKeys("u12121983");
		 * btn.click(); Thread.sleep(20000); WebElement pin =
		 * driver.findElement(By.id("pin")); WebElement pinbtn =
		 * driver.findElement(By.className("button-orange")); pin.sendKeys("121283");
		 * pinbtn.click(); Thread.sleep(20000);
		 * 
		 * String visited = ""+new java.util.Date()+","; charturlorig =
		 * (String)(prop.remove("charturl")); for(String key :
		 * prop.stringPropertyNames()) { String charturl = charturlorig; visited =
		 * visited + key +","; String value = prop.getProperty(key); try {
		 * log.info("----------->>zerodha capturing image for scripcode:"
		 * +value+" charturl:"+charturl); if("NIFTY".equalsIgnoreCase(key)) { charturl =
		 * value; }else { charturl = charturl.replace("?scripcode", value); charturl =
		 * charturl.replace("?symbol", URLEncoder.encode(key, "UTF-8")); }
		 * driver.get(charturl); Thread.sleep(20000); TakesScreenshot scrShot
		 * =((TakesScreenshot)driver); uploadImage(null,
		 * scrShot.getScreenshotAs(OutputType.BYTES), key+".png", awsserverurl);
		 * Thread.sleep(5000); }catch(Exception px) {
		 * log.error("having some issue in zerodha capturing image for scripcode:"
		 * +value+" charturl:"+charturl, px); } } uploadImage(null, visited.getBytes(),
		 * "chartforscrips.txt", awsserverurl); }catch(Exception x) { log.
		 * error("ERROR#################Some issue zerodha chart picker image capture and sending."
		 * , x); } try { driver.quit(); }catch(Exception ix) { log.
		 * error("ERROR#################Some issue zerodha chart picker browser driver closing."
		 * , ix); } try {
		 * TelegramUtil.sendTelegramMsg("Zerodha chart picker. I am live....",
		 * "-485376339", true); } catch (Exception _exp) { log.
		 * error("ERROR#################Some issue zerodha chart picker telegram msg for nifty200 sending."
		 * , _exp); }
		 */
	}
	private static List<String> todayAlreadyResultProcessedScripCodes = new ArrayList<>();
	private static SimpleDateFormat YYYYMMDD_FORMATTER = new SimpleDateFormat("yyyyMMdd");
	private static class PDFBoxEmptyResourceCache extends DefaultResourceCache {
		/*
		 * @Override public void put(COSObject indirect, PDFont font) throws IOException
		 * { }
		 * 
		 * @Override public void put(COSObject indirect, PDColorSpace colorSpace) throws
		 * IOException { }
		 */
		@Override
		public void put(COSObject indirect, PDExtendedGraphicsState extGState) {
		}
		@Override
		public void put(COSObject indirect, PDShading shading) throws IOException {
		}
		@Override
		public void put(COSObject indirect, PDAbstractPattern pattern) throws IOException {
		}
		@Override
		public void put(COSObject indirect, PDPropertyList propertyList) {
		}
		@Override
		public void put(COSObject indirect, PDXObject xobject) throws IOException {
		}
	}
	public static BufferedImage joinBufferedImage(BufferedImage img1, BufferedImage img2) {
		// do some calculate first
		int offset = 5;
		int wid = Math.max(img1.getWidth(), img2.getWidth()) + offset;
		int height = img1.getHeight() + img2.getHeight() + offset;
		// create a new buffer and draw two image into the new image
		BufferedImage newImage = new BufferedImage(wid, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = newImage.createGraphics();
		Color oldColor = g2.getColor();
		// fill background
		g2.setPaint(Color.WHITE);
		g2.fillRect(0, 0, wid, height);
		// draw image
		g2.setColor(oldColor);
		g2.drawImage(img1, null, 0, 0);
		g2.drawImage(img2, null, 0, img1.getHeight() + offset);
		g2.dispose();
		return newImage;
	}
	private static List<String[]> getLatestCorpAnnouncementFromBSE(String fromDate, String toDate, int pgcntstrt,
			int pgcntend) throws Exception {
		List<String[]> anncArrLst = new ArrayList<>();
		for (int pgcnt = pgcntstrt; pgcnt <= pgcntend; pgcnt++) {
			try {
				CookieHandler.setDefault(new CookieManager());
				HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(30000))
						.version(Version.HTTP_1_1).cookieHandler(CookieHandler.getDefault()).build();
				java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
						.setHeader("Accept-Encoding", "gzip, deflate, br")
						.setHeader("Accept-Language", "en-US,en;q=0.9")// .setHeader("Connection", "keep-alive")
						// .setHeader("Host", "www.nseindia.com")
						.setHeader("Origin", "https://www.bseindia.com")
						.setHeader("Referer", "https://www.bseindia.com/")
						.setHeader("User-Agent",
								"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0")
						.setHeader("Accept", "application/json, text/plain, */*")
						.setHeader("X-Requested-With", "XMLHttpRequest").timeout(Duration.ofMillis(50000)).GET();
				HttpResponse<String> rootSiteResproot = client.send(
						_reqBuilder.uri(URI.create("https://www.bseindia.com")).build(),
						HttpResponse.BodyHandlers.ofString());
				System.out.println(rootSiteResproot.statusCode() + "<<------*********---------->>");
				// String urltohit =
				// "https://api.bseindia.com/BseIndiaAPI/api/AnnGetData/w?pageno=" + pgcnt +
				// "&strCat=Result&strPrevDate=" + fromDate +
				// "&strScrip=&strSearch=P&strToDate=" + toDate + "&strType=C";
				// String urltohit =
				// "https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w?pageno=1&strCat=Result&strPrevDate=20231010&strScrip=&strSearch=P&strToDate=20231014&strType=C&subcategory=Financial+Results";
				String urltohit = "https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w?pageno=" + pgcnt
						+ "&strCat=Result&strPrevDate=" + fromDate + "&strScrip=&strSearch=P&strToDate=" + toDate
						+ "&strType=C&subcategory=Financial+Results";
				HttpResponse<String> rootSiteResp = client.send(_reqBuilder.uri(URI.create(urltohit)).build(),
						HttpResponse.BodyHandlers.ofString());
				System.out.println(rootSiteResp.statusCode() + "<<------=====*********---------->>");
				if (rootSiteResp.statusCode() == 200) {
					String bd = rootSiteResp.body();
					System.out.println(urltohit + "<<---------------->>" + bd);
					JSONObject _jnode = new JSONObject(bd);
					JSONArray anncArr = _jnode.getJSONArray("Table");
					if (anncArr != null) {
						int size = anncArr.length();
						for (int i = 0; i < size; i++) {
							JSONObject annc = anncArr.getJSONObject(i);
							String arr[] = new String[7];
							arr[0] = ("" + annc.getInt("SCRIP_CD")).trim();
							arr[1] = "https://www.bseindia.com/xml-data/corpfiling/AttachLive/"
									+ annc.getString("ATTACHMENTNAME").trim();
							arr[2] = annc.getString("NEWSSUB").trim();
							arr[3] = annc.getString("NSURL").trim();
							arr[4] = annc.getString("ANNOUNCEMENT_TYPE").trim();
							arr[5] = annc.getString("SUBCATNAME").trim();
							arr[6] = annc.getString("NEWS_DT").trim();
							anncArrLst.add(arr);
						}
						if (size == 0) {
							break;
						}
					} else {
						System.out.println("#########No response data from BSE latest corporate announcement" + urltohit);
						break;
					}
				} else {
					System.out.println(
							"#########No response status from BSE latest corporate announcement is not 200" + urltohit);
					break;
				}
			} catch (Exception ign) {
				System.out.println("**************ERROR in getting latest corporate announcement from bse");
			}
		}
		return anncArrLst;
	}

    private static SimpleDateFormat YYYY_MM_DD_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");

	
	public static void processFinancialResultsFromBSELiveDate(Properties prop) throws Exception {
		System.out.println("+++++++++++++++++BSEUtil.processFinancialResultsFromBSELiveDate() is starting as=======");
		try {
			int bsepagestrt = 1;
			int bsepageend = 20;
			Calendar cal = Calendar.getInstance();
			String todaysDate = YYYY_MM_DD_FORMATTER.format(cal.getTime());
			String fromDate = YYYYMMDD_FORMATTER.format(cal.getTime());
			cal.add(Calendar.DAY_OF_MONTH, -1);
			String toDate = YYYYMMDD_FORMATTER.format(cal.getTime());
			List<String[]> anncmntArrLst = getLatestCorpAnnouncementFromBSE(toDate, fromDate, bsepagestrt, bsepageend);
			CookieHandler.setDefault(new CookieManager());
			HttpClient client = HttpClient.newBuilder().version(Version.HTTP_1_1)
					.cookieHandler(CookieHandler.getDefault()).build();
			PDDocument document = null;
			for (String[] anncArr : anncmntArrLst) {
				System.out.println(todaysDate + "------Processing BSE financial result for bsecode:" + anncArr[0]);
				if (todayAlreadyResultProcessedScripCodes.contains(anncArr[0]) == false) {
					try {
						// value = value.substring(0, value.indexOf("#"));
						// if(value.equals(anncArr[0].trim())) {
						if (anncArr[5].contains("Financial Results") && anncArr[6].contains(todaysDate)) {// if(anncArr[3].contains("/"+key.toLowerCase()+"/"))
																											// {
							System.out.println("------Processing BSE financial result for bsecode==:" + anncArr[0]);
							todayAlreadyResultProcessedScripCodes.add(anncArr[0]);
							java.net.http.HttpRequest.Builder _reqBuilder = HttpRequest.newBuilder()
									.setHeader("Accept", "*/*").setHeader("Cache-Control", "no-cache")
									// .setHeader("Host", "www.bseindia.com")
									.setHeader("Accept-Encoding", "gzip, deflate")
									// .setHeader("Connection", "keep-alive")
									.setHeader("cache-control", "no-cache").setHeader("User-Agent",
											"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:82.0) Gecko/20100101 Firefox/82.0");
							HttpResponse<InputStream> rootSiteResp = client.send(
									_reqBuilder.uri(URI.create(anncArr[1])).build(),
									HttpResponse.BodyHandlers.ofInputStream());
							// document = PDDocument.load(rootSiteResp.body(),
							// MemoryUsageSetting.setupTempFileOnly());
							document = Loader.loadPDF(rootSiteResp.body(), MemoryUsageSetting.setupTempFileOnly());
							document.setResourceCache(new PDFBoxEmptyResourceCache());
							PDFRenderer renderer = new PDFRenderer(document);
							// renderer.setSubsamplingAllowed(true);
							int noOfPages = document.getNumberOfPages();
							if (noOfPages > 15) {
								noOfPages = 15;
							}
							PDFTextStripper pdfStripper = new PDFTextStripper();
							boolean reportsend = false;
							int ixprev = -1;
							int ixp = 0;
							int xiprev = -1;
							int xip = 0;
							for (int p = 1; p <= noOfPages; p++) {
								pdfStripper.setStartPage(p);
								pdfStripper.setEndPage(p);
								String pagetxt = pdfStripper.getText(document);
								if (pagetxt != null) {
									pagetxt = pagetxt.toLowerCase();
									boolean found = false;
									int ix = pagetxt.indexOf("Profit after tax".toLowerCase());
									if (ix > -1) {
										ixprev = ix;
										ixp = p;
										found = true;
									} else {
										ix = pagetxt.indexOf("Total Profit".toLowerCase());
										if (ix > -1) {
											ixprev = ix;
											ixp = p;
											found = true;
										} else {
											ix = pagetxt.indexOf("Profit for the period".toLowerCase());
											if (ix > -1) {
												ixprev = ix;
												ixp = p;
												found = true;
											} else {
												ix = pagetxt.indexOf("Profit/(Loss) for the period".toLowerCase());
												if (ix > -1) {
													ixprev = ix;
													ixp = p;
													found = true;
												} else {
													ix = pagetxt.indexOf("Profit for the period/ year (".toLowerCase());
													if (ix > -1) {
														ixprev = ix;
														ixp = p;
														found = true;
													} else {
														ix = pagetxt.indexOf("Profit/ (loss) after tax".toLowerCase());
														if (ix > -1) {
															ixprev = ix;
															ixp = p;
															found = true;
														} else {
															ix = pagetxt.indexOf("Net profit".toLowerCase());
															if (ix > -1) {
																ixprev = ix;
																ixp = p;
																found = true;
															} else {
																ix = pagetxt
																		.indexOf("Profit before tax (".toLowerCase());
																if (ix > -1) {
																	ixprev = ix;
																	ixp = p;
																	found = true;
																} else {
																	ix = pagetxt
																			.indexOf("Profit before tax".toLowerCase());
																	if (ix > -1) {
																		ixprev = ix;
																		ixp = p;
																		found = true;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
									boolean epsfound = false;
									int xi = pagetxt.indexOf("Earnings per share".toLowerCase());
									if (xi > -1) {
										xiprev = xi;
										xip = p;
										epsfound = true;
									} else {
										xi = pagetxt.indexOf("Earning per share".toLowerCase());
										if (xi > -1) {
											xiprev = xi;
											xip = p;
											epsfound = true;
										} else {
											xi = pagetxt.indexOf("Earnings per equity share".toLowerCase());
											if (xi > -1) {
												xiprev = xi;
												xip = p;
												epsfound = true;
											} else {
												xi = pagetxt.indexOf("Diluted".toLowerCase());
												if (xi > -1) {
													xiprev = xi;
													xip = p;
													epsfound = true;
												} else {
													/*
													 * xi = pagetxt.indexOf("EPS".toLowerCase()); if(xi > -1) { xiprev =
													 * xi; xip = p; epsfound = true; }
													 */}
											}
										}
									}
									if (found == true && epsfound == true) {
										try {
											byte[] bytes = null;
											try {
												pagetxt = pagetxt.substring(ix, ix + 100);
												pagetxt = pagetxt.replaceAll(" \\.", "\\.");
												pagetxt = pagetxt + "\r\n" + anncArr[2] + "\r\n" + anncArr[1];
												BufferedImage image = renderer.renderImageWithDPI(p - 1, 70,
														ImageType.RGB);
												ByteArrayOutputStream baos = new ByteArrayOutputStream();
												ImageIO.write(image, "png", baos);
												bytes = baos.toByteArray();
												image = null;
											} catch (Exception ixi) {
											}
											boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
													anncArr[0] + ".png", bytes, "-490038191");
											if (isSent == false) {
												String telegramMsgToSend = "." + anncArr[0] + "%0A" + anncArr[2] + "%0A"
														+ anncArr[1];
												TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
											}
											reportsend = true;
											renderer = null;
										} catch (Exception ign) {
											System.out.println(
													"**************ERROR in getting latest corporate announcement from bse");
										}
										break;
									}
								}
							}
							if (reportsend == false) {
								if (xiprev > -1) {
									try {
										String pagetxt = "D-\r\n" + anncArr[2] + "\r\n" + anncArr[1];
										byte[] bytes = null;
										try {
											BufferedImage joinBufferedImage = renderer.renderImageWithDPI(xip - 1, 70,
													ImageType.RGB);
											ByteArrayOutputStream baos = new ByteArrayOutputStream();
											ImageIO.write(joinBufferedImage, "png", baos);
											bytes = baos.toByteArray();
											joinBufferedImage = null;
										} catch (Exception ixi) {
										}
										boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
												anncArr[0] + ".png", bytes, "-490038191");
										if (isSent == false) {
											String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A"
													+ anncArr[1];
											TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
										}
										reportsend = true;
										renderer = null;
									} catch (Exception ign) {
										System.out.println(
												"**************ERROR in getting latest corporate announcement from bse");
									}
								}
								if (ixprev > -1 && reportsend == false) {
									try {
										String pagetxt = "P-\r\n" + anncArr[2] + "\r\n" + anncArr[1];
										byte[] bytes = null;
										try {
											BufferedImage joinBufferedImage = renderer.renderImageWithDPI(ixp - 1, 70,
													ImageType.RGB);
											try {
												joinBufferedImage = joinBufferedImage(joinBufferedImage,
														renderer.renderImageWithDPI(ixp - 2, 70, ImageType.RGB));
											} catch (Exception ix) {
											}
											ByteArrayOutputStream baos = new ByteArrayOutputStream();
											ImageIO.write(joinBufferedImage, "png", baos);
											bytes = baos.toByteArray();
											joinBufferedImage = null;
										} catch (Exception ign) {
											System.out.println(
													"**************ERROR in getting latest corporate announcement from bse");
										}
										boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
												anncArr[0] + ".png", bytes, "-490038191");
										if (isSent == false) {
											String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A"
													+ anncArr[1];
											TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
										}
										reportsend = true;
										renderer = null;
									} catch (Exception ign) {
										System.out.println(
												"**************ERROR in getting latest corporate announcement from bse");
									}
								}
								if (reportsend == false) {
									try {
										// int heightTotal = 0;
										int total = 0;
										int maxHt = 700;
										BufferedImage joinBufferedImage = null;
										List<BufferedImage> images = new ArrayList<>();
										try {
											int st = 1;
											if (noOfPages > 7)
												st = 3;
											int cntz = 1;
											for (int pg = st; pg < noOfPages; pg++) {
												if (cntz > 3) {
													break;
												}
												cntz = cntz + 1;
												document.getPage(pg).setCropBox(new PDRectangle(50, 30, 450, 600));
												BufferedImage image = renderer.renderImage(pg);
												images.add(image);
												if (image.getHeight() < maxHt) {
													maxHt = image.getHeight();
												}
												total = total + image.getWidth();
											}
											int pos = 0;
											joinBufferedImage = new BufferedImage(total, maxHt,
													BufferedImage.TYPE_INT_RGB);
											Graphics2D g2d = joinBufferedImage.createGraphics();
											for (BufferedImage bufferedImage : images) {
												g2d.drawImage(bufferedImage, pos, 0, null);
												// g2d.drawImage(bufferedImage, 0, heightCurr, null);
												pos += (bufferedImage.getWidth());
											}
											g2d.dispose();
										} catch (Exception ign) {
											System.out.println(
													"**************ERROR in getting latest corporate announcement from bse");
										}
										String pagetxt = "N-\r\n" + anncArr[2] + "\r\n" + anncArr[1];
										byte[] bytes = null;
										try {
											ByteArrayOutputStream baos = new ByteArrayOutputStream();
											ImageIO.write(joinBufferedImage, "jpg", baos);
											bytes = baos.toByteArray();
										} catch (Exception ign) {
											System.out.println(
													"**************ERROR in getting latest corporate announcement from bse");
										}
										boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
												anncArr[0] + ".jpg", bytes, "-490038191");
										if (isSent == false) {
											String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A"
													+ anncArr[1];
											TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
										}
										reportsend = true;
									} catch (Exception ign) {
										System.out.println(
												"**************ERROR in getting latest corporate announcement from bse");
									}
								}
								if (reportsend == false) {
									String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A" + anncArr[1];
									TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", true);
								}
							}
						}
					} catch (Exception ign) {
						System.out.println("**************ERROR in getting latest corporate announcement from bse");
					}
				}
			}
		} catch (Exception ign) {
			System.out.println("**************ERROR in getting latest corporate announcement from bse");
		}
	}
	private static SimpleDateFormat YYYYMMDD_FORMATTER1 = new SimpleDateFormat("dd-MM-yyyy");
	private static SimpleDateFormat YYYY_MM_DD_FORMATTER1 = new SimpleDateFormat("dd-MMM-yyyy");
	public static void processFinancialResultsFromNSELiveDate(Properties prop) throws Exception {
		System.out.println("+++++++++++++++++Util.processFinancialResultsFromNSELiveDate() is starting as=======");
		try {
			ObjectMapper OBJECT_MAPPER_JACKSON = new ObjectMapper();
			Calendar cal = Calendar.getInstance();
			String todaysDate = YYYY_MM_DD_FORMATTER1.format(cal.getTime());
			String fromDate = YYYYMMDD_FORMATTER1.format(cal.getTime());
			cal.add(Calendar.DAY_OF_MONTH, -1);
			String toDate = YYYYMMDD_FORMATTER1.format(cal.getTime());
			PDDocument document = null;
			CookieManager cookieManager = new CookieManager();
			CookieHandler.setDefault(cookieManager);
			HttpURLConnection baseUrlConnection = (HttpURLConnection) new URL("https://www.nseindia.com/")
					.openConnection();
			baseUrlConnection.setRequestProperty("Connection", "keep-alive");
			baseUrlConnection.setRequestProperty("Cache-Control", "max-age=0");
			baseUrlConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");
			baseUrlConnection.setRequestProperty("User-Agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)"
							+ " Chrome/89.0.4389.114 Safari/537.36");
			baseUrlConnection.setRequestProperty("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			baseUrlConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
			System.out.println(baseUrlConnection.getContent());
			List<HttpCookie> cookieList = cookieManager.getCookieStore().getCookies();
			String _rcddateurl = "https://www.nseindia.com/api/corporate-announcements?index=equities&from_date="
					+ toDate + "&to_date=" + fromDate;
			URL url = new URL(_rcddateurl);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("GET");
			httpURLConnection.setRequestProperty("Cookie", cookieList.stream().filter(Objects::nonNull)
					.map(cookie -> cookie.getName() + "=" + cookie.getValue()).collect(Collectors.joining(";")));
			httpURLConnection.setRequestProperty("Connection", "keep-alive");
			httpURLConnection.setRequestProperty("Cache-Control", "max-age=0");
			httpURLConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");
			httpURLConnection.setRequestProperty("User-Agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36");
			httpURLConnection.setRequestProperty("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			httpURLConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
			InputStream inputStream = httpURLConnection.getInputStream();
			System.out.println(_rcddateurl + "=Got getResponseCode." + httpURLConnection.getResponseCode());
			System.out.println(todaysDate + "=todaysDateGot inputstream." + httpURLConnection.getContent());
			String urlinputStream = new String(inputStream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
			System.out.println("Got== inputstream." + urlinputStream);
			// ObjectMapper mapper = new ObjectMapper();
			// List data = mapper.readValue(inputStream, List.class);
			// System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data));
			JsonNode _jnode = OBJECT_MAPPER_JACKSON.readTree(urlinputStream);
			if (_jnode == null) {
				System.out.println(
						"###############********************unable to fetch record date and financial result data from:"
								+ _rcddateurl + ". _jnode:" + _jnode);
			} else {
				if (_jnode.isArray()) {
					for (JsonNode objNode : _jnode) {
						try {
							// HttpResponse<InputStream> rootSiteRespkl = client.send(
							// _reqBuilder.uri(URI.create(objNode.get("attchmntFile").asText())).build(),HttpResponse.BodyHandlers.ofInputStream());
							// document = PDDocument.load(rootSiteResp.body(),
							// MemoryUsageSetting.setupTempFileOnly());
							// document =
							// Loader.loadPDF(rootSiteRespkl.body(),MemoryUsageSetting.setupTempFileOnly());
							System.out.println(
									"-------------------------------------}}}}" + objNode.get("attchmntFile").asText());
							if ((objNode.get("desc").asText().contains("Result")
									|| objNode.get("desc").asText().contains("result"))
									&& objNode.get("exchdisstime").asText().contains(todaysDate)) {
								url = new URL(objNode.get("attchmntFile").asText());
								httpURLConnection = (HttpURLConnection) url.openConnection();
								httpURLConnection.setRequestMethod("GET");
								httpURLConnection.setRequestProperty("Cookie",
										cookieList.stream().filter(Objects::nonNull)
												.map(cookie -> cookie.getName() + "=" + cookie.getValue())
												.collect(Collectors.joining(";")));
								httpURLConnection.setRequestProperty("Connection", "keep-alive");
								httpURLConnection.setRequestProperty("Cache-Control", "max-age=0");
								httpURLConnection.setRequestProperty("Upgrade-Insecure-Requests", "1");
								httpURLConnection.setRequestProperty("User-Agent",
										"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36");
								httpURLConnection.setRequestProperty("Accept",
										"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
								httpURLConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
								inputStream = httpURLConnection.getInputStream();
								System.out.println(inputStream + ":inputStream-------------------------------------}}}}"
										+ objNode.get("attchmntFile").asText());
								document = Loader.loadPDF(inputStream, MemoryUsageSetting.setupTempFileOnly());
								document.setResourceCache(new PDFBoxEmptyResourceCache());
								PDFRenderer renderer = new PDFRenderer(document);
								// renderer.setSubsamplingAllowed(true);
								int noOfPages = document.getNumberOfPages();
								if (noOfPages > 15) {
									noOfPages = 15;
								}
								PDFTextStripper pdfStripper = new PDFTextStripper();
								String anncArr[] = new String[3];
								anncArr[0] = objNode.get("symbol").asText();
								anncArr[1] = objNode.get("attchmntFile").asText();
								anncArr[2] = objNode.get("attchmntText").asText();
								boolean reportsend = false;
								int ixprev = -1;
								int ixp = 0;
								int xiprev = -1;
								int xip = 0;
								for (int p = 1; p <= noOfPages; p++) {
									pdfStripper.setStartPage(p);
									pdfStripper.setEndPage(p);
									String pagetxt = pdfStripper.getText(document);
									if (pagetxt != null) {
										pagetxt = pagetxt.toLowerCase();
										boolean found = false;
										int ix = pagetxt.indexOf("Profit after tax".toLowerCase());
										if (ix > -1) {
											ixprev = ix;
											ixp = p;
											found = true;
										} else {
											ix = pagetxt.indexOf("Total Profit".toLowerCase());
											if (ix > -1) {
												ixprev = ix;
												ixp = p;
												found = true;
											} else {
												ix = pagetxt.indexOf("Profit for the period".toLowerCase());
												if (ix > -1) {
													ixprev = ix;
													ixp = p;
													found = true;
												} else {
													ix = pagetxt.indexOf("Profit/(Loss) for the period".toLowerCase());
													if (ix > -1) {
														ixprev = ix;
														ixp = p;
														found = true;
													} else {
														ix = pagetxt
																.indexOf("Profit for the period/ year (".toLowerCase());
														if (ix > -1) {
															ixprev = ix;
															ixp = p;
															found = true;
														} else {
															ix = pagetxt
																	.indexOf("Profit/ (loss) after tax".toLowerCase());
															if (ix > -1) {
																ixprev = ix;
																ixp = p;
																found = true;
															} else {
																ix = pagetxt.indexOf("Net profit".toLowerCase());
																if (ix > -1) {
																	ixprev = ix;
																	ixp = p;
																	found = true;
																} else {
																	ix = pagetxt.indexOf(
																			"Profit before tax (".toLowerCase());
																	if (ix > -1) {
																		ixprev = ix;
																		ixp = p;
																		found = true;
																	} else {
																		ix = pagetxt.indexOf(
																				"Profit before tax".toLowerCase());
																		if (ix > -1) {
																			ixprev = ix;
																			ixp = p;
																			found = true;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										boolean epsfound = false;
										int xi = pagetxt.indexOf("Earnings per share".toLowerCase());
										if (xi > -1) {
											xiprev = xi;
											xip = p;
											epsfound = true;
										} else {
											xi = pagetxt.indexOf("Earning per share".toLowerCase());
											if (xi > -1) {
												xiprev = xi;
												xip = p;
												epsfound = true;
											} else {
												xi = pagetxt.indexOf("Earnings per equity share".toLowerCase());
												if (xi > -1) {
													xiprev = xi;
													xip = p;
													epsfound = true;
												} else {
													xi = pagetxt.indexOf("Diluted".toLowerCase());
													if (xi > -1) {
														xiprev = xi;
														xip = p;
														epsfound = true;
													} else {
														/*
														 * xi = pagetxt.indexOf("EPS".toLowerCase()); if(xi > -1) {
														 * xiprev = xi; xip = p; epsfound = true; }
														 */}
												}
											}
										}
										if (found == true && epsfound == true) {
											try {
												byte[] bytes = null;
												try {
													pagetxt = pagetxt.substring(ix, ix + 100);
													pagetxt = pagetxt.replaceAll(" \\.", "\\.");
													pagetxt = pagetxt + "\r\n" + anncArr[2] + "\r\n" + anncArr[1];
													BufferedImage image = renderer.renderImageWithDPI(p - 1, 70,
															ImageType.RGB);
													ByteArrayOutputStream baos = new ByteArrayOutputStream();
													ImageIO.write(image, "png", baos);
													bytes = baos.toByteArray();
													image = null;
												} catch (Exception ixi) {
												}
												boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
														anncArr[0] + ".png", bytes, "-490038191");
												if (isSent == false) {
													String telegramMsgToSend = "." + anncArr[0] + "%0A" + anncArr[2]
															+ "%0A" + anncArr[1];
													TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191",
															false);
												}
												reportsend = true;
												renderer = null;
											} catch (Exception ign) {
												System.out.println("**************ERROR in getting latest corporate announcement from bse");
											}
											break;
										}
									}
								}
								if (reportsend == false) {
									if (xiprev > -1) {
										try {
											String pagetxt = "D-\r\n" + anncArr[2] + "\r\n" + anncArr[1];
											byte[] bytes = null;
											try {
												BufferedImage joinBufferedImage = renderer.renderImageWithDPI(xip - 1,
														70, ImageType.RGB);
												ByteArrayOutputStream baos = new ByteArrayOutputStream();
												ImageIO.write(joinBufferedImage, "png", baos);
												bytes = baos.toByteArray();
												joinBufferedImage = null;
											} catch (Exception ixi) {
											}
											boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
													anncArr[0] + ".png", bytes, "-490038191");
											if (isSent == false) {
												String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A"
														+ anncArr[1];
												TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
											}
											reportsend = true;
											renderer = null;
										} catch (Exception ign) {
											System.out.println("**************ERROR in getting latest corporate announcement from bse");
										}
									}
									if (ixprev > -1 && reportsend == false) {
										try {
											String pagetxt = "P-\r\n" + anncArr[2] + "\r\n" + anncArr[1];
											byte[] bytes = null;
											try {
												BufferedImage joinBufferedImage = renderer.renderImageWithDPI(ixp - 1,
														70, ImageType.RGB);
												try {
													joinBufferedImage = joinBufferedImage(joinBufferedImage,
															renderer.renderImageWithDPI(ixp - 2, 70, ImageType.RGB));
												} catch (Exception ix) {
												}
												ByteArrayOutputStream baos = new ByteArrayOutputStream();
												ImageIO.write(joinBufferedImage, "png", baos);
												bytes = baos.toByteArray();
												joinBufferedImage = null;
											} catch (Exception ign) {
												System.out.println("**************ERROR in getting latest corporate announcement from bse");
											}
											boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
													anncArr[0] + ".png", bytes, "-490038191");
											if (isSent == false) {
												String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A"
														+ anncArr[1];
												TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
											}
											reportsend = true;
											renderer = null;
										} catch (Exception ign) {
											System.out.println("**************ERROR in getting latest corporate announcement from bse");
										}
									}
									if (reportsend == false) {
										try {
											// int heightTotal = 0;
											int total = 0;
											int maxHt = 700;
											BufferedImage joinBufferedImage = null;
											List<BufferedImage> images = new ArrayList<>();
											try {
												int st = 1;
												if (noOfPages > 7)
													st = 3;
												int cntz = 1;
												for (int pg = st; pg < noOfPages; pg++) {
													if (cntz > 3) {
														break;
													}
													cntz = cntz + 1;
													document.getPage(pg).setCropBox(new PDRectangle(50, 30, 450, 600));
													BufferedImage image = renderer.renderImage(pg);
													images.add(image);
													if (image.getHeight() < maxHt) {
														maxHt = image.getHeight();
													}
													total = total + image.getWidth();
												}
												int pos = 0;
												joinBufferedImage = new BufferedImage(total, maxHt,
														BufferedImage.TYPE_INT_RGB);
												Graphics2D g2d = joinBufferedImage.createGraphics();
												for (BufferedImage bufferedImage : images) {
													g2d.drawImage(bufferedImage, pos, 0, null);
													// g2d.drawImage(bufferedImage, 0, heightCurr, null);
													pos += (bufferedImage.getWidth());
												}
												g2d.dispose();
											} catch (Exception ign) {
												System.out.println("**************ERROR in getting latest corporate announcement from bse");
											}
											String pagetxt = "N-\r\n" + anncArr[2] + "\r\n" + anncArr[1];
											byte[] bytes = null;
											try {
												ByteArrayOutputStream baos = new ByteArrayOutputStream();
												ImageIO.write(joinBufferedImage, "jpg", baos);
												bytes = baos.toByteArray();
											} catch (Exception ign) {
												System.out.println("**************ERROR in getting latest corporate announcement from bse");
											}
											boolean isSent = TelegramUtil.sendTelegramImageMsgUsingBytes(pagetxt,
													anncArr[0] + ".jpg", bytes, "-490038191");
											if (isSent == false) {
												String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A"
														+ anncArr[1];
												TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", false);
											}
											reportsend = true;
										} catch (Exception ign) {
											System.out.println("**************ERROR in getting latest corporate announcement from bse");
										}
									}
									if (reportsend == false) {
										String telegramMsgToSend = anncArr[0] + "%0A" + anncArr[2] + "%0A" + anncArr[1];
										TelegramUtil.sendTelegramMsg(telegramMsgToSend, "-490038191", true);
									}
								}
							}
						} catch (Exception ign) {
							System.out.println("**************ERROR in getting latest corporate announcement from nseindia");
						}
					}
				}
			}
		} catch (Exception ign) {
			System.out.println("**************ERROR in getting latest corporate announcement from jse");
		}
	}
}
