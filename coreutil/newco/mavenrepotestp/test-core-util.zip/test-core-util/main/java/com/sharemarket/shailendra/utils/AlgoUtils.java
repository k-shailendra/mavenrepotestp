package com.sharemarket.shailendra.utils;

import java.util.ArrayList;
import java.util.List;

public class AlgoUtils {
	
	public static List<Double> calculateEMA(int period, List<Double> dataArr) throws Exception {
		double smooth = 2.0/(1+period);
		Double sma = 0.0;
		Double prevEma = 0.0;
		Double ema = 0.0;
		List<Double> emaarr = new ArrayList<Double>();
		
		for(int i=0; i < dataArr.size(); i++) {
			if(i<period) {
				sma = sma + dataArr.get(i);
			}else {
				if(i == period) {
					prevEma = sma / period;
				}else {
					prevEma = ema;
				}
				ema = ((dataArr.get(i) * smooth) + (prevEma*(1-smooth)));
				emaarr.add(ema);
			}
		}
		return emaarr;
	}

}
