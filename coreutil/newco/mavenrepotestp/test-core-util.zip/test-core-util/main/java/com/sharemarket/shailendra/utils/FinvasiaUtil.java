package com.sharemarket.shailendra.utils;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import javax.swing.JOptionPane;

import org.apache.commons.codec.binary.Base32;
import org.apache.commons.codec.binary.Hex;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import de.taimos.totp.TOTP;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.RepositoryClass;

public class FinvasiaUtil {
	
    static WebSocket ws = null;
    public static boolean connectToWebSocket(WebSocket.Listener websocketlistner) {
    	try {
    		if(ws == null) {
        		String wsurl = "wss://api.shoonya.com/NorenWSTP/";
        		ws = HttpClient.newHttpClient().newWebSocketBuilder().buildAsync(URI.create(wsurl), websocketlistner).join();
        		//latch.await();
                //for(int i=0; i<1000000000; i++){  };
    		}
    		return true;
    	}catch(Exception xp) {
    		ws = null;
    		logger.error(xp);
    	}
    	return false;
    }
    
    public static void disConnectWebSocket() {
    	try {
    		ws.sendClose(WebSocket.NORMAL_CLOSURE, "ok");
    	}catch(Exception xp) {
    		logger.error(xp);
    	}
    	try {
    		ws.abort();
    	}catch(Exception xp) {
    		logger.error(xp);
    	}
    	ws = null;
    }
    
    public static void subscribeToWebSocket(String subscribefordata) {
    	if(ws == null) {
    		
    	}
    	if(subscribefordata != null && subscribefordata.length() > 1)
    		ws.sendText("{\"t\":\"t\",\"k\":\""+subscribefordata+"\"}", true);
    }
    
    public static void unsubscribeToWebSocket(String subscribefordata) {
 	    if(subscribefordata != null) {
 	    	CompletableFuture<WebSocket> ff = ws.sendText("{\"t\":\"u\",\"k\":\""+subscribefordata+"\"}", true);
 	    }
    }
	
	public static String getTimeSeriesData(long stTimeInSec, long endTimeInSec, String tkn, Integer candleInterval, String exch) throws Exception {
		String call = "jData={\r\n\"uid\":\"FA66519\",\r\n\"exch\":\""+exch+"\",\r\n\"token\":\""+tkn+"\",\r\n\"st\":\""+stTimeInSec+"\",\r\n\"et\":\""+endTimeInSec+"\",\r\n\"intrv\":\""+candleInterval+"\"\r\n}&jKey="+App.loginToken;
        RequestBody body1 = RequestBody.create(call, App.mediaType_JSON);        
        Request postRequest1 = new Request.Builder()
                .url(RepositoryClass.TPSeries)
                .method("POST", body1)
                .addHeader("Content-Type", "application/json").build();
        Response response1 = App.client.newCall(postRequest1).execute();
        String bd = response1.body().string();
		//System.out.println(call +"<-------->"+bd);
		return bd;
	}
	
	public static Map<String,String> getFinvasiaScripTokenMap(Set<String> scripnames, String exchange) throws Exception {
		Map<String, String> mp = new HashMap<String, String>();
		if(scripnames != null) {
				for (String sname : scripnames) {
					boolean retry = false;
					try {
						String tkn = getFinvasiaScripToken(URLEncoder.encode(sname, "UTF-8"), exchange);
						if(tkn != null && tkn.length() > 0) {
							mp.put(sname, tkn);
						}else {
							retry = true;
						}
					}catch(Exception xp) {
						retry = true;
						xp.printStackTrace();
					}
					if(retry) {
						try {
							String tkn = getFinvasiaScripToken(URLEncoder.encode(sname, "UTF-8"), exchange);
							if(tkn != null && tkn.length() > 0) {
								mp.put(sname, tkn);
							}
						}catch(Exception xp) {
							xp.printStackTrace();
						}
					}
				}
		}
		return mp;
	}
	
	public static Map<String,String> getFinvasiaScripTokenMapForNifty(int nifty50val4ce, int nifty50val4pe, String exchange, int qtyIn1Lot) throws Exception {
		Map<String, String> mp = new HashMap<String, String>();
		if(nifty50val4ce > 0) {
				for (int vl = nifty50val4ce; vl >= (nifty50val4ce - 4*qtyIn1Lot); vl = vl-qtyIn1Lot) {
					boolean retry = false;
					String sname = "NIFTY"+App.niftyWeeklyExpiryDate+"C"+vl;
					try {
						String tkn = getFinvasiaScripToken(URLEncoder.encode(sname, "UTF-8"), exchange);
						if(tkn != null && tkn.length() > 0) {
							Double ltp = getLTPValueOf(tkn, exchange);
							if(ltp > 30 && ltp<62) {
								mp.put(sname, tkn);
								break;
							}
						}else {
							retry = true;
						}
					}catch(Exception xp) {
						retry = true;
						xp.printStackTrace();
					}
					if(retry) {
						try {
							String tkn = getFinvasiaScripToken(URLEncoder.encode(sname, "UTF-8"), exchange);
							if(tkn != null && tkn.length() > 0) {
								Double ltp = getLTPValueOf(tkn, exchange);
								if(ltp > 30 && ltp<62)
									mp.put(sname, tkn);
								break;
							}
						}catch(Exception xp) {
							xp.printStackTrace();
						}
					}
				}
		}
		if(nifty50val4pe > 0) {
			for (int vl = nifty50val4pe; vl <= (nifty50val4pe + 4*qtyIn1Lot); vl = vl+qtyIn1Lot) {
				boolean retry = false;
				String sname = "NIFTY"+App.niftyWeeklyExpiryDate+"P"+vl;
				try {
					String tkn = getFinvasiaScripToken(URLEncoder.encode(sname, "UTF-8"), exchange);
					if(tkn != null && tkn.length() > 0) {
						Double ltp = getLTPValueOf(tkn, exchange);
						if(ltp > 30 && ltp<62) {
							mp.put(sname, tkn);
							break;
						}
					}else {
						retry = true;
					}
				}catch(Exception xp) {
					retry = true;
					xp.printStackTrace();
				}
				if(retry) {
					try {
						String tkn = getFinvasiaScripToken(URLEncoder.encode(sname, "UTF-8"), exchange);
						if(tkn != null && tkn.length() > 0) {
							Double ltp = getLTPValueOf(tkn, exchange);
							if(ltp > 30 && ltp<62)
								mp.put(sname, tkn);
							break;
						}
					}catch(Exception xp) {
						xp.printStackTrace();
					}
				}
			}
	}
		return mp;
	}
	
	public static String getFinvasiaScripToken(String name, String exchange) throws Exception {
		if(name != null) {
            RequestBody body = RequestBody.create("jData={\r\n\"exch\":\""+exchange+"\",\r\n\"uid\":\"FA66519\",\r\n\"stext\":\""+name.trim()+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
            Request postRequest = new Request.Builder()
                    .url(RepositoryClass.searchScrip)
                    .method("POST", body)
                    .addHeader("Content-Type", "application/json").build();
            Response response = App.client.newCall(postRequest).execute();
            String bd = response.body().string();
            //System.out.println(name+"====>getSubscriptionToken:"+bd);
            JSONObject json = new JSONObject(bd);
            JSONArray values = json.getJSONArray("values");
            if(values != null) {
            	JSONObject jo = values.getJSONObject(0);
            	String tkn = jo.getString("token");
            	return tkn;
            }
		}
		return null;
	}
	
	public static Double getLTPValueOfNifty50() throws Exception {
		Request postRequest4getquote = App.postRequest4nifty50getquote.build();
    	Response response = App.client.newCall(postRequest4getquote).execute();
        JSONObject json = new JSONObject(response.body().string());
        return Double.valueOf(json.getString("lp"));
	}
	
	public static Double getLTPValueOf(String tokn, String exch) throws Exception {
		RequestBody bodygetquote = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"exch\":\""+exch+"\",\r\n\"token\":\""+tokn+"\"\r\n}&jKey="+App.loginToken, App.mediaType_JSON);
	    Request.Builder postRequestgetquote = new Request.Builder().url("https://api.shoonya.com/NorenWClientTP/GetQuotes").method("POST", bodygetquote).addHeader("Content-Type", "application/json");
		Request postRequest4getquote = postRequestgetquote.build();
    	Response response = App.client.newCall(postRequest4getquote).execute();
        JSONObject json = new JSONObject(response.body().string());
        return Double.valueOf(json.getString("lp"));
	}
	
	public static String getLoginToken() throws Exception {
        try {
        	String secretKey = "7F67LDDJ77TV76625E56R5TAT256ZK5D";
    		Base32 base32 = new Base32();
    	    byte[] bytes = base32.decode(secretKey);
    	    String hexKey = Hex.encodeHexString(bytes);
    	    String loginToken =  TOTP.getOTP(hexKey);
            RequestBody body = RequestBody.create("jData={\r\n\"apkversion\":\"1.0.15\",\r\n\"uid\":\"FA66519\",\r\n\"pwd\":\"a712127e6278f05966444e3eda6fe175eceae1d3304f3b6fc58f93529612b4c6\",\r\n\"factor2\":\""+loginToken+"\",\r\n\"imei\":\"abc1234\",\r\n\"source\":\"API\",\r\n\"vc\":\"FA66519_U\",\r\n\"appkey\":\"d603ec0a3bc532dee5eda6c3615d485890ca979935b4b835fecf3dd4dffda80a\"\r\n}", App.mediaType_JSON);
            Request postRequest = new Request.Builder()
                    //.url("https://shoonyatrade.finvasia.com/NorenWClientTP/QuickAuth")
            		.url("https://api.shoonya.com/NorenWClientTP/QuickAuth")
                    .method("POST", body)
                    .addHeader("Content-Type", "application/json").build();
            Response response = App.client.newCall(postRequest).execute();
            String bd = response.body().string();
            System.out.println("loginResponse:"+bd);
            JSONObject json = new JSONObject(bd);
            loginToken = json.getString("susertoken");
            return loginToken;
        } catch (Exception ex) {
            logger.error("login have issue", ex);
        }
        return null;
	}
	
    private static final Logger logger = LogManager.getLogger(FinvasiaUtil.class);

}
