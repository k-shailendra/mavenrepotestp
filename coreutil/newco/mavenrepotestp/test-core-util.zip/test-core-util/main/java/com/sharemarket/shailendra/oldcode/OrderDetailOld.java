package com.sharemarket.shailendra.oldcode;

import okhttp3.Request;

public class OrderDetailOld {
	private Double mxP = 0.0;
	private Double mnP = 0.0;
	private Request[] reqS;
	private int noOfReqs = 0;
	
	public OrderDetailOld(Double mxP, Double mnP, Request[] reqs, int noOfReqs) {
		this.mxP = mxP;
		this.mnP = mnP;
		this.reqS = reqs;
		this.noOfReqs = noOfReqs;
	}

	public Double getMxP() {
		return mxP;
	}

	public void setMxP(Double mxP) {
		this.mxP = mxP;
	}

	public Double getMnP() {
		return mnP;
	}

	public void setMnP(Double mnP) {
		this.mnP = mnP;
	}

	public Request[] getReqS() {
		return reqS;
	}

	public int getNoOfReqs() {
		return noOfReqs;
	}

	public void setNoOfReqs(int noOfReqs) {
		this.noOfReqs = noOfReqs;
	}

	public void setReqS(Request[] reqS) {
		this.reqS = reqS;
	}

}
