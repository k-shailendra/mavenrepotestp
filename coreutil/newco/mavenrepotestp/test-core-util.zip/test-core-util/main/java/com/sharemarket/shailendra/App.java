package com.sharemarket.shailendra;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import com.sharemarket.shailendra.charting.NiftyDataProcessor;
import com.sharemarket.shailendra.charting.NseBseDataProcessor;
import com.sharemarket.shailendra.charting.ScripChartService;
import com.sharemarket.shailendra.finvasia.FinvasiaAlgoCalculator;
import com.sharemarket.shailendra.finvasia.FinvasiaAlgoCalculator4OptionNifty;
import com.sharemarket.shailendra.finvasia.FinvasiaAlgoCalculatorMoneyControl;
import com.sharemarket.shailendra.finvasia.FinvasiaAutoTrader;
import com.sharemarket.shailendra.finvasia.FinvasiaDepthPicker;
import com.sharemarket.shailendra.finvasia.PositionBookProcessor;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.NSEBSEUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;
import de.taimos.totp.TOTP;
import io.netty.util.Timeout;
import javax.swing.JOptionPane;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.security.SecureRandom;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import com.sharemarket.shailendra.RepositoryClass;
public class App {
	private static JFrame mainFrame;
	private static JPanel topPanel;
	private static JLabel lblStpLsTrigger = new JLabel("StopLsTrgger");
	private static JButton peDataPickerbutton = new JButton("PEDataPicker");
	private static JButton peDataPickerStopbutton = new JButton("StopPEDataPicker");
	private static JButton ceDataPickerbutton = new JButton("CEDataPicker");
	private static JButton ceDataPickerStopbutton = new JButton("StopCEDataPicker");
	static JTextField cetxt = new JTextField(8);
	static JTextField petxt = new JTextField(8);
	private static JTextField txtPrcCE = new JTextField(2);
	private static JTextField txtPrcPE = new JTextField(2);
	private static JTextField txtScripCodeStpLs = new JTextField();
	private static JTextField txtNoOfLotStpLs = new JTextField(8);
	private static JTextField txtStopLs = new JTextField(8);
	private static JTextField txtStopLsUpBy = new JTextField(8);
	private static JTextField txtLot2SaleAtProfit = new JTextField(8);
	private static JTextField txtTargetProfit = new JTextField(8);
//public static JTextArea orderBookJTextArea = new JTextArea();
	private static JTextArea positionBookJTextArea = new JTextArea();
	private static JTextField txtStopLossStrtFrom = new JTextField(8);
	static JTextArea localorderBook = new JTextArea();
	private static JTextField txtPriceCESell = new JTextField(2);
	private static JTextField txtPricePESell = new JTextField(2);
	private static JTextField txtStplsp = new JTextField(2);
	private static double stoplosspercent = 0.03;
	private static int qtyIn1Lot = 50;
	private static int waitInSec = 60;
	private static boolean isLocalOrder1st = true;
	private static List<String> exchangeOrdIds = null;
	public static OkHttpClient client = new OkHttpClient.Builder().hostnameVerifier(new HostnameVerifier() {
		@Override
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	}).connectTimeout(10, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).writeTimeout(10, TimeUnit.SECONDS)
			.build();
	public final static MediaType mediaType_JSON = MediaType.parse("application/json; charset=utf-8");
	public static String loginToken = null;
	public static String actid = "FA66519";
	static SwingWorker<Void, Double> ceDataPickerWrkr = null;
	static SwingWorker<Void, Double> peDataPickerWrkr = null;
	static SwingWorker<Void, Double> stopLossTriggerWrkr = null;
	private static final Logger logger = LogManager.getLogger(App.class);
	public static String niftyWeeklyExpiryDate = "";
	public static int niftyWeeklyExpiryDateRemaining = 0;
	public static RequestBody body4nifty50getquote = null;
	public static Request.Builder postRequest4nifty50getquote = null;
	static RequestBody body4positionFromUtil = null;
	static Request.Builder postRequest4positionBuilderFromUtil = null;
	public static Integer APPROACH = 2;
	public static Double PRCENTHIKE = 0.022;
	public static void main(String[] args) throws Exception {
		logger.info("Starting app---------------->");
		try {
			if (args == null || args.length == 0) {
				logger.info("please pass parameter for task!!!");
				return;
			}
			loginToken = FinvasiaUtil.getLoginToken();
			logger.info("finvasia login token:" + loginToken);
			TelegramUtil.sendTelegramMsg("Starting App Now. loginToken:" + loginToken, "-547540350", false);
		} catch (Exception e) {
			logger.error(e);
		}
		
		if (loginToken == null || loginToken.trim().length() == 0) {
			loginToken = "ZZ";//return;
		}if ("finvasiaoptionadesktop".equalsIgnoreCase(args[0])) {
			try {
				/*
				 * javax.swing.SwingUtilities.invokeLater(new Runnable() { public void run() {
				 * createAndShowGUI(); } });
				 */
				createAndShowGUI();
			} catch (Exception e) {
				logger.error(e);
			}
		} else {
			try {
				Properties prp = new Properties();
				prp.putAll(ConstantScrips.scripsMap);
				NseBseDataProcessor nsebse = new NseBseDataProcessor(prp);
				ScheduledExecutorService executornsebse = Executors.newSingleThreadScheduledExecutor();
				executornsebse.scheduleAtFixedRate(nsebse, 1, 80, TimeUnit.MINUTES);
			} catch (Throwable t) {
				logger.error("------->", t);
			}
			ScheduledExecutorService executor = Executors.newScheduledThreadPool(10);
			Thread autotraderthread = null;
			try {
				PositionBookProcessor pbprocessor = new PositionBookProcessor();
				executor.scheduleAtFixedRate(pbprocessor, 0, 15, TimeUnit.SECONDS);
			} catch (Throwable t) {
				logger.error("error starting..", t);
			}
			for (String arg : args) {
				if ("finvasiachart".equalsIgnoreCase(arg)) {
					try {
						NseBseDataProcessor.isScripChartAllowed = true;
					} catch (Exception e) {
						logger.error(e);
					}
				}
				if ("finvasiaresult".equalsIgnoreCase(arg)) {
					try {
						NseBseDataProcessor.isScripResultAllowed = true;
					} catch (Exception e) {
						logger.error(e);
					}
				}
				if ("finvasiaother".equalsIgnoreCase(arg)) {
					try {
						NseBseDataProcessor.canrunbulkdealdatafetch = true;
					} catch (Exception e) {
						logger.error(e);
					}
				}
				if ("moneycontrol".equalsIgnoreCase(arg)) {
					try {
						Properties prop = new Properties();
						prop.put("NIFTY", "#999920000");
						prop.put("TATAMOTORS", "500570#3456");
						prop.put("AXISBANK", "532215#5900");
						prop.put("BAJFINANCE", "500034#317");
						prop.put("BAJAJ-AUTO", "532977#16669");
						prop.put("LUPIN", "500257#10440");
						prop.put("TATAPOWER", "500400#3426");
						prop.put("AMARAJABAT", "500008#100");
						prop.put("HAVELLS", "517354#9819");
						prop.put("ASIANPAINT", "500820#236");
						prop.put("BHARTIARTL", "532454#10604");
						prop.put("TATASTEEL", "500470#3499");
						prop.put("MONTECARLO", "538836#5938");
						prop.put("L&TFH", "533519#24948");
						prop.put("WIPRO", "507685#3787");
						prop.put("TITAN", "500114#3506");
						prop.put("RELIANCE", "500325#2885");
						prop.put("ICICIBANK", "532174#4963");
						prop.put("HINDUNILVR", "500696#1394");
						prop.put("WHIRLPOOL", "500238#18011");
						prop.put("ITC", "500875#1660");
						prop.put("COALINDIA", "533278#20374");
						prop.put("NETWORK18", "532798#14111");
						prop.put("BIOCON", "532523#11373");
						prop.put("ACC", "500410#22");
						prop.put("BALKRISIND", "502355#335");
						prop.put("IRCTC", "542830#13611");
						prop.put("MUTHOOTFIN", "533398#23650");
						prop.put("RAYMOND", "500330#2859");
						prop.put("HEROMOTOCO", "500182#1348");
						prop.put("TATACHEM", "500770#3405");
						prop.put("PEL", "500302#2412");
						prop.put("TATACONSUM", "500800#3432");
						prop.put("ADANIGREEN", "541450#3563");
						prop.put("MCDOWELL-N", "#10447");
						prop.put("PAYTM", "543396#6705");
						prop.put("KALYANKJIL", "543278#2955");
						prop.put("TRIDENT", "521064#9685");
						prop.put("SPICEJET", "500285#11446");
						prop.put("UPL", "512070#11287");
						prop.put("ABFRL", "535755#30108");
						prop.put("TRENT", "500251#1964");
						prop.put("RBLBANK", "540065#18391");
						prop.put("AMBUJACEM", "500425#1270");
						prop.put("RAMCOCEM", "500260#2043");
						prop.put("NBCC", "534309#31415");
						prop.put("DLF", "532868#14732");
						prop.put("GODREJPROP", "533150#17875");
						prop.put("UBL", "532478#16713");
						prop.put("BALRAMCHIN", "500038#341");
						prop.put("INDIGO", "539448#11195");
						prop.put("TATAPOWER", "500400#3426");
						prop.put("IGL", "532514#11262");
						prop.put("ONGC", "500312#2475");
						prop.put("IOC", "530965#1624");
						prop.put("INDHOTEL", "500850#1512");
						prop.put("VOLTAS", "500575#3718");
						prop.put("IDFCFIRSTB", "539437#11184");
						prop.put("SBILIFE", "540719#540719");
						prop.put("M&M", "500520#2031");
						prop.put("MARUTI", "532500#10999");
						prop.put("EICHERMOT", "505200#910");
						prop.put("GRASIM", "500300#1232");
						prop.put("LT", "500510#11483");
						prop.put("SBIN", "500112#3045");
						prop.put("HDFCBANK", "500180#1333");
						prop.put("KOTAKBANK", "500247#1922");
						prop.put("HDFC", "500010#1330");
						prop.put("HDFCLIFE", "540777#467");
						prop.put("CIPLA", "500087#694");
						prop.put("HINDALCO", "500440#1363");
						prop.put("BRITANNIA", "500825#547");
						prop.put("ADANIENT", "512599#25");
						prop.put("ULTRACEMCO", "532538#11532");
						prop.put("NESTLEIND", "500790#17963");
						prop.put("POWERGRID", "532898#14977");
						prop.put("JSWSTEEL", "500228#11723");
						prop.put("TCS", "532540#11536");
						prop.put("HCLTECH", "532281#7229");
						prop.put("APOLLOHOSP", "508869#157");
						prop.put("TECHM", "532755#13538");
						prop.put("INFY", "500209#1594");
						prop.put("INDUSINDBK", "532187#5258");
						prop.put("NTPC", "532555#11630");
						prop.put("DRREDDY", "500124#881");
						prop.put("AARTIIND", "524208#7");
						prop.put("ABB", "500002#13");
						prop.put("ABBOTINDIA", "500488#17903");
						prop.put("ABCAPITAL", "540691#21614");
						prop.put("ADANIPORTS", "532921#15083");
						prop.put("ALKEM", "539523#11703");
						prop.put("APOLLOTYRE", "500877#163");
						prop.put("ASTRAL", "532830#14418");
						prop.put("ASHOKLEY", "500477#212");
						prop.put("ATUL", "500027#263");
						prop.put("AUBANK", "540611#21238");
						prop.put("AUROPHARMA", "524804#275");
						prop.put("BAJAJFINSV", "532978#16675");
						prop.put("BANDHANBNK", "541153#2263");
						prop.put("BANKBARODA", "532134#4668");
						prop.put("BATAINDIA", "500043#371");
						prop.put("BEL", "500049#383");
						prop.put("BERGEPAINT", "509480#404");
						prop.put("BHARATFORG", "500493#422");
						prop.put("BHEL", "500103#438");
						prop.put("ZYDUSLIFE", "532321#7929");
						prop.put("ZEEL", "505537#3812");
						prop.put("VEDL", "500295#3063");
						prop.put("TVSMOTOR", "532343#8479");
						prop.put("SUNTV", "532733#13404");
						prop.put("SUNPHARMA", "524715#3351");
						prop.put("SRTRANSFIN", "511218#4306");
						prop.put("RAIN", "500339#15337");
						prop.put("POLYCAB", "542652#9590");
						prop.put("PETRONET", "532522#11351");
						prop.put("OFSS", "532466#10738");
						prop.put("NAVINFLUOR", "532504#14672");
						prop.put("NAUKRI", "532777#13751");
						prop.put("MOTHERSON", "517334#4204");
						prop.put("M&MFIN", "532720#13285");
						prop.put("TATACOMM", "500483#3721");
						prop.put("PNB", "532461#10666");
						prop.put("PIDILITIND", "500331#2664");
						FinvasiaAlgoCalculatorMoneyControl agStockOnly1day = new FinvasiaAlgoCalculatorMoneyControl(
								"TEMA", prop, 375, 18, "-1001539893897", "1Day-Candle-TEMA-", new Double[] { 0.04 },
								RepositoryClass.moneycontrolTokenProperties15Min, true, true, 12.2);
						executor.scheduleAtFixedRate(agStockOnly1day, 20, 6600, TimeUnit.SECONDS);
						FinvasiaAlgoCalculatorMoneyControl agStockOnly15min = new FinvasiaAlgoCalculatorMoneyControl(
								"TEMA", RepositoryClass.moneycontrolTokenProperties15Min, 15, 6, "-1001539893897",
								"15min-Candle-TEMA-", new Double[] { 0.04 }, null, true, true, 3.0);
						executor.scheduleAtFixedRate(agStockOnly15min, 300, 1700, TimeUnit.SECONDS);
					} catch (Exception e) {
						logger.error(e);
					}
				}
				if ("finvasiaoptionauto".equalsIgnoreCase(arg)) {
					try {
						String xpdate = CommonUtils.getNiftyBankNiftyWeeklyExpiryDate();
						int inx = xpdate.indexOf("#");
						niftyWeeklyExpiryDateRemaining = Integer.valueOf(xpdate.substring(0, inx));
						niftyWeeklyExpiryDate = xpdate.substring(inx + 1);
						body4nifty50getquote = RequestBody.create(
								"jData={\r\n\"uid\":\"FA66519\",\r\n\"exch\":\"NSE\",\r\n\"token\":\"26000\"\r\n}&jKey="
										+ App.loginToken,
								App.mediaType_JSON);
						postRequest4nifty50getquote = new Request.Builder()
								.url("https://api.shoonya.com/NorenWClientTP/GetQuotes")
								.method("POST", body4nifty50getquote).addHeader("Content-Type", "application/json");
						body4positionFromUtil = RequestBody.create(
								"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\"\r\n}&jKey=" + App.loginToken,
								mediaType_JSON);
						postRequest4positionBuilderFromUtil = new Request.Builder().url(RepositoryClass.positionbook)
								.method("POST", body4positionFromUtil).addHeader("Content-Type", "application/json");
					} catch (Exception e) {
						logger.error("------------->" + e);
					}
					try {
						FinvasiaAutoTrader at = new FinvasiaAutoTrader();
						autotraderthread = new Thread(at);
						autotraderthread.start();
					} catch (Exception e) {
						logger.error("------------->" + e);
					}
					try {
						final Map<String, String> niftyToFinvasiaTokenMap = new HashMap<String, String>() {
							{
								put("NIFTY", "26000");
// put("NIFTY BANK", "26009");
							}
						};
						TimerTask task = new TimerTask() {
							@Override
							public void run() {
								Calendar cal = Calendar.getInstance();
								if (CommonUtils.isTradingAllowedToday(cal)) {
									int hr = cal.get(Calendar.HOUR_OF_DAY);
									int mn = cal.get(Calendar.MINUTE);
									boolean canrun = false;
									if (hr > 8 && hr < 16) {
										if (hr == 9 && mn > 8) {
											if (mn < 17) {
												try {
													NseBseDataProcessor.pickAndProcessScripsLivePreSessionData();
												} catch (Exception ign) {
													logger.error("----->", ign);
												}
											}
											canrun = true;
										} else if (hr == 15 && mn < 30) {
											canrun = true;
										} else {
											canrun = true;
										}
									}
									if (canrun) {
										Double lp = 0.0;
										try {
											int niftyltpce = 0;
											int niftyltppe = 0;
											boolean noorderonexpiryday = true;
											String msg = TelegramUtil.getLatestTelegramMsgFromGroup("-547540350");
											if (msg != null) {
												if (msg.contains("@@##@@approach:")
														|| msg.contains("@@##@@Approach:")) {
													msg = msg.substring(msg.indexOf(":") + 1);
													if (msg.contains(",")) {
														int x = msg.indexOf(",");
														APPROACH = Integer.valueOf(msg.substring(0, x));
														PRCENTHIKE = Double.valueOf(
																msg.substring(msg.lastIndexOf(":") + 1).trim());
													} else if (msg.contains("\n")) {
														int x = msg.indexOf("\n");
														APPROACH = Integer.valueOf(msg.substring(0, x));
														PRCENTHIKE = Double.valueOf(
																msg.substring(msg.lastIndexOf(":") + 1).trim());
													}
												}
												if (msg.contains("@@##@@FakeOrder") || msg.contains("@@##@@FakeOrder ")
														|| msg.contains("@@##@@fakeorder ")
														|| msg.contains("@@##@@Fakeorder")
														|| msg.contains("@@##@@fakeorder")
														|| msg.contains("@@##@@fake order")
														|| msg.contains("@@##@@Fake Order")
														|| msg.contains("@@##@@Fake order")) {
													noorderonexpiryday = true;
												}
												if (msg.contains("@@##@@NoOrder") || msg.contains("@@##@@Noorder")
														|| msg.contains("@@##@@noorder")
														|| msg.contains("@@##@@no order")
														|| msg.contains("@@##@@No Order")
														|| msg.contains("@@##@@No order")) {
													noorderonexpiryday = true;
												}
												if (msg.contains("@@##@@PlaceOrder") || msg.contains("@@##@@Placeorder")
														|| msg.contains("@@##@@placeorder")
														|| msg.contains("@@##@@place order")
														|| msg.contains("@@##@@Place Order")
														|| msg.contains("@@##@@Place order")) {
//niftyToFinvasiaTokenMap.clear();
													noorderonexpiryday = false;
												} else {
													lp = FinvasiaUtil.getLTPValueOfNifty50();
													if (lp > 1.0) {
														Double mod = lp % 50;
														int niftyltp = 50 * ((int) (lp / 50));
														if (App.niftyWeeklyExpiryDateRemaining == 0) {
															if (hr > 13) {
																noorderonexpiryday = true;
																niftyltpce = (niftyltp + (mod > 40 ? 50 : 0));
																niftyltppe = (niftyltp - (mod > 20 ? 0 : 50));
															}
															if (hr > 11) {
																niftyltpce = (niftyltp + (mod > 30 ? 100 : 50));
																niftyltppe = (niftyltp - (mod > 30 ? 0 : 50));
															} else {
																niftyltpce = (niftyltp + (mod > 10 ? 100 : 50));
																niftyltppe = (niftyltp - (mod > 44 ? 0 : 50));
															}
														} else if (App.niftyWeeklyExpiryDateRemaining == 1) {
															niftyltpce = (niftyltp + (mod > 30 ? 100 : 50));
															niftyltppe = (niftyltp - (mod > 30 ? 50 : 100));
														} else if (App.niftyWeeklyExpiryDateRemaining > 1) {
															niftyltpce = (niftyltp + (mod > 40 ? 150 : 100));
															niftyltppe = (niftyltp - (mod > 40 ? 100 : 150));
														}
														if (msg.contains("@@##@@NoCe") || msg.contains("@@##@@Noce")
																|| msg.contains("@@##@@noce")
																|| msg.contains("@@##@@no ce")
																|| msg.contains("@@##@@No Ce")
																|| msg.contains("@@##@@No ce")) {
															niftyltpce = 0;
														} else if (msg.contains("@@##@@NoPe")
																|| msg.contains("@@##@@Nope")
																|| msg.contains("@@##@@nope")
																|| msg.contains("@@##@@no pe")
																|| msg.contains("@@##@@No Pe")
																|| msg.contains("@@##@@No pe")) {
															niftyltppe = 0;
														} else {
														}
													}
												}
											} else {
												lp = FinvasiaUtil.getLTPValueOfNifty50();
												if (lp > 1.0) {
													Double mod = lp % 50;
													int niftyltp = 50 * ((int) (lp / 50));
													if (App.niftyWeeklyExpiryDateRemaining == 0) {
														if (hr > 13) {
															noorderonexpiryday = true;
															niftyltpce = (niftyltp + (mod > 40 ? 50 : 0));
															niftyltppe = (niftyltp - (mod > 20 ? 0 : 50));
														}
														if (hr > 11) {
															niftyltpce = (niftyltp + (mod > 30 ? 100 : 50));
															niftyltppe = (niftyltp - (mod > 30 ? 0 : 50));
														} else {
															niftyltpce = (niftyltp + (mod > 10 ? 100 : 50));
															niftyltppe = (niftyltp - (mod > 44 ? 0 : 50));
														}
													} else if (App.niftyWeeklyExpiryDateRemaining == 1) {
														niftyltpce = (niftyltp + (mod > 30 ? 100 : 50));
														niftyltppe = (niftyltp - (mod > 30 ? 50 : 100));
													} else if (App.niftyWeeklyExpiryDateRemaining > 1) {
														niftyltpce = (niftyltp + (mod > 40 ? 150 : 100));
														niftyltppe = (niftyltp - (mod > 40 ? 100 : 150));
													}
												}
											}
											niftyToFinvasiaTokenMap.clear();
											niftyToFinvasiaTokenMap
													.putAll(FinvasiaUtil.getFinvasiaScripTokenMapForNifty(niftyltpce,
															niftyltppe, "NFO", 50));
											if (noorderonexpiryday)
												niftyToFinvasiaTokenMap.put("Fakeorder", "Fakeorder");
										} catch (Exception e) {
											logger.error("timer task issue", e);
										}
									}
								}
							}
						};
						Timer timer = new Timer();
						timer.scheduleAtFixedRate(task, 0l, 240000l);
						FinvasiaAutoTrader finvasiaAutoTrader = new FinvasiaAutoTrader();
						FinvasiaAlgoCalculator4OptionNifty agNiftyBankNiftyOnly15Candle = new FinvasiaAlgoCalculator4OptionNifty(
								"TEMA", niftyToFinvasiaTokenMap, 15, 6, "-490038191", "Nifty15mn-", null, true,
								finvasiaAutoTrader, 0.16, 0.03, 7);
						executor.scheduleAtFixedRate(agNiftyBankNiftyOnly15Candle, 20, 300, TimeUnit.SECONDS);
						FinvasiaAlgoCalculator4OptionNifty agNiftyBankNiftyOnly5Candle = new FinvasiaAlgoCalculator4OptionNifty(
								"TEMA", niftyToFinvasiaTokenMap, 5, 3, "-490038191", "Nifty5mn-", null, true,
								finvasiaAutoTrader, 0.01, 0.003, 3);
						executor.scheduleAtFixedRate(agNiftyBankNiftyOnly5Candle, 10, 60, TimeUnit.SECONDS);
					} catch (Exception e) {
						logger.error("***************>" + e);
					}
				}
			}
			if (autotraderthread != null)
				autotraderthread.join();
			FinvasiaDepthPicker.disconnect2socket();
		}
	}
	public static void connectToWebSocket() {
		FinvasiaUtil.connectToWebSocket(new WebSocketClient());
	}
	public static void disConnectWebSocket() {
		FinvasiaUtil.disConnectWebSocket();
		JOptionPane.showMessageDialog(null, "Web Socket Closed Now. Can start Again!!!");
	}
	public static void subscribeToWebSocket() {
		ceScripCodeSelected = cetxt.getText().trim().toUpperCase();
		peScripCodeSelected = petxt.getText().trim().toUpperCase();
		if (ceScripCodeSelected == null || ceScripCodeSelected.length() == 0 || peScripCodeSelected == null
				|| peScripCodeSelected.length() == 0) {
			JOptionPane.showMessageDialog(null, "First make CE and PE entry!!!");
		} else {
			String subscribefordata = getSubscriptionToken(new String[] { ceScripCodeSelected, peScripCodeSelected });
			FinvasiaUtil.subscribeToWebSocket(subscribefordata);
			JOptionPane.showMessageDialog(null, "Subscribed:" + subscribefordata);
		}
	}
	public static String ceTokenVal = null;
	public static String peTokenVal = null;
	private static String ceScripCodeSelected = "NIFTY-XY";
	private static String peScripCodeSelected = "NIFTY-YX";
	public static void unsubscribeToWebSocket() {
		String subscribefordata = null;
		if (ceTokenVal != null) {
			subscribefordata = "NFO|" + ceTokenVal;
		}
		if (peTokenVal != null) {
			subscribefordata = subscribefordata + "#NFO|" + peTokenVal;
		}
		if (subscribefordata == null) {
			JOptionPane.showMessageDialog(null, "No Data for UnSubscribe!!!");
		} else {
			FinvasiaUtil.unsubscribeToWebSocket(subscribefordata);
			JOptionPane.showMessageDialog(null, "UnSubscribed:" + subscribefordata);
		}
	}
	public static String getSubscriptionToken(String[] name) {
		String subscriptionval = null;
		try {
			if (name != null) {
				for (int x = 0; x < name.length; x++) {
					RequestBody body = RequestBody
							.create("jData={\r\n\"exch\":\"NFO\",\r\n\"uid\":\"FA66519\",\r\n\"stext\":\"" + name[x]
									+ "\"\r\n}&jKey=" + loginToken, mediaType_JSON);
					Request postRequest = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/SearchScrip").method("POST", body)
							.addHeader("Content-Type", "application/json").build();
					Response response = client.newCall(postRequest).execute();
					String bd = response.body().string();
					logger.info(loginToken+"***********="+name[x] + "====>getSubscriptionToken:" + bd);
					JSONObject json = new JSONObject(bd);
					JSONArray values = json.getJSONArray("values");
					if (values != null) {
						JSONObject jo = values.getJSONObject(0);
						String tkn = jo.getString("token");
						if (subscriptionval == null) {
							subscriptionval = "NFO|" + tkn;
							ceTokenVal = tkn;
						} else {
							subscriptionval = subscriptionval + "#NFO|" + tkn;
							peTokenVal = tkn;
						}
// System.out.println("Token=====>"+tkn);
					}
				}
			}
		} catch (Exception xp) {
			xp.printStackTrace();
		}
		return subscriptionval;
	}
	private static class WebSocketClient implements WebSocket.Listener {
		public WebSocketClient() {
		}
		@Override
		public void onOpen(WebSocket webSocket) {
			WebSocket.Listener.super.onOpen(webSocket);
			CompletableFuture<WebSocket> fff = webSocket.sendText("{\"t\":\"c\",\"uid\":\"" + actid + "\",\"actid\":\""
					+ actid + "\",\"source\":\"API\",\"susertoken\":\"" + loginToken + "\"}", true);
		}
		@Override
		public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
// System.out.println(last+":onText received=" + data);
			try {
				String rsp = data.toString();
				if (rsp.contains("\"t\": \"ck\",")) {
					JOptionPane.showMessageDialog(null, "Web Socket Status:CK");
				} else if (rsp.contains("\"t\":\"tk\",") || rsp.contains("\"t\":\"tf\",")) {
					JSONObject json = new JSONObject(rsp);
					String tkn = json.getString("tk");
					String ltp = json.getString("lp");
					if (ceTokenVal != null && ceTokenVal.equals(tkn)) {
						if ("ce".equals(App.placeLocalOrdFor)) {
							synchronized (lockobj) {
								int noLocalOrder = StockMarketUtil.placeBuyOrderForLocalOrders(Double.valueOf(ltp),
										ceScripCodeSelected, loginToken, App.localOrderArr, 15, false, null, 0.025);
								if (noLocalOrder == 0)
									App.placeLocalOrdFor = "";
							}
						}
						txtPrcCE.setText(ltp);
					} else if (peTokenVal != null && peTokenVal.equals(tkn)) {
						if ("pe".equals(App.placeLocalOrdFor)) {
							synchronized (lockobj) {
								int noLocalOrder = StockMarketUtil.placeBuyOrderForLocalOrders(Double.valueOf(ltp),
										peScripCodeSelected, loginToken, App.localOrderArr, 15, false, null, 0.025);
								if (noLocalOrder == 0)
									App.placeLocalOrdFor = "";
							}
						}
						txtPrcPE.setText(ltp);
					}
				}
			} catch (Exception xp) {
// xp.printStackTrace();
			}
			webSocket.request(1);
			return null;
		}
		@Override
		public void onError(WebSocket webSocket, Throwable error) {
			logger.info("Bad day! " + webSocket.toString() + ", error=" + error.getStackTrace());
			WebSocket.Listener.super.onError(webSocket, error);
			JOptionPane.showMessageDialog(null, "Web Socket Closed. Restart Again!!!");
		}
	}
	private static Object lockobj = new Object();
	public static void createAndShowGUI() {
		mainFrame = new JFrame("StockAutoTrader");
		mainFrame.setSize(920, 730);
		mainFrame.setLayout(null);
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});
		mainFrame.add(createTopPanel());
		mainFrame.add(createCEPanel());
		mainFrame.add(createPEPanel());
		mainFrame.add(createPositionPanel());
		mainFrame.add(createOrderBookPanel());
		mainFrame.add(createOrderXchangePanel());
		mainFrame.add(createLocalOrderBookPanel());
		mainFrame.add(createStopLossPanel());
		mainFrame.setVisible(true);
	}
	private static SwingWorker positionBookWorker = null;
	private static JPanel createPositionPanel() {
		JPanel positionPanel = new JPanel();
		positionPanel.setBackground(new Color(10, 10, 15));
		positionPanel.setBounds(0, 205, 224, 250);
		positionPanel.setSize(224, 250);
		positionPanel.setLayout(null);
		JLabel lbl = new JLabel("PositionBook");
		lbl.setForeground(Color.RED);
		lbl.setFont(new Font("Serif", Font.PLAIN, 9));
		lbl.setBounds(1, 1, 56, 14);
		positionPanel.add(lbl);
		JButton startWatcherbutton = new JButton("StartWatcher");
		startWatcherbutton.setBorder(null);
		startWatcherbutton.setBackground(Color.BLUE);
		startWatcherbutton.setForeground(Color.WHITE);
		startWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		startWatcherbutton.setBounds(58, 2, 53, 18);
		startWatcherbutton.setVisible(true);
		startWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startWatcherbutton.setEnabled(false);
				positionBookWorker = new SwingWorker() {
					@Override
					protected Object doInBackground() throws Exception {
						int cnt = 0;
						RequestBody body4position = RequestBody.create(
								"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\"\r\n}&jKey=" + loginToken,
								mediaType_JSON);
						Request.Builder postRequest4positionBuilder = new Request.Builder()
								.url("https://api.shoonya.com/NorenWClientTP/PositionBook")
								.method("POST", body4position).addHeader("Content-Type", "application/json");
						while (isCancelled() == false && cnt < 54000) {
							loadPositionBook(postRequest4positionBuilder);
							cnt = cnt + 1;
							Thread.sleep(5000);
						}
						return null;
					}
				};
				positionBookWorker.execute();
			}
		});
		positionPanel.add(startWatcherbutton);
		JButton stopWatcherbutton = new JButton("StopWatcher");
		stopWatcherbutton.setBorder(null);
		stopWatcherbutton.setBackground(Color.BLUE);
		stopWatcherbutton.setForeground(Color.WHITE);
		stopWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		stopWatcherbutton.setBounds(114, 2, 53, 18);
		stopWatcherbutton.setVisible(true);
		stopWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (positionBookWorker != null)
						positionBookWorker.cancel(true);
					startWatcherbutton.setEnabled(true);
				} catch (Exception px) {
					logger.error(px);
				}
			}
		});
		positionPanel.add(stopWatcherbutton);
		JButton refreshWatcherbutton = new JButton("Refresh");
		refreshWatcherbutton.setBorder(null);
		refreshWatcherbutton.setBackground(Color.BLUE);
		refreshWatcherbutton.setForeground(Color.WHITE);
		refreshWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		refreshWatcherbutton.setBounds(170, 2, 50, 18);
		refreshWatcherbutton.setVisible(true);
		refreshWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					RequestBody body4position = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request.Builder postRequest4positionBuilder = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PositionBook")
							.method("POST", body4position).addHeader("Content-Type", "application/json");
					loadPositionBook(postRequest4positionBuilder);
				} catch (Exception e1) {
					logger.error(e1);
				}
			}
		});
		positionPanel.add(refreshWatcherbutton);
		positionBookJTextArea.setEnabled(false);
		positionBookJTextArea.setForeground(Color.BLACK);
		positionBookJTextArea.setFont(new Font("Serif", Font.PLAIN, 15));
		positionBookJTextArea.setBounds(10, 30, 200, 180);
		positionPanel.add(positionBookJTextArea);
		return positionPanel;
	}
	private static String positionPrev = "";
	public static void loadPositionBook(Request.Builder postRequest4positionBuilder) throws Exception {
		String responseBody = null;
		try {
			Request postRequest4position = postRequest4positionBuilder.build();
			Response response = client.newCall(postRequest4position).execute();
			responseBody = response.body().string();
			JSONArray jsonArr = new JSONArray(responseBody);
			if (jsonArr != null) {
				String position = "";
				Integer netQty = 0;
				int ln = jsonArr.length();
				String scrpCodeStpLs = txtScripCodeStpLs.getText();
				for (int i = 0; i < ln; i++) {
					JSONObject json = jsonArr.getJSONObject(i);
					netQty = Integer.valueOf(json.getString("netqty"));
					if (netQty > 0) {
						String nm = json.getString("tsym").trim();
						if (nm.equalsIgnoreCase(scrpCodeStpLs)) {
							txtNoOfLotStpLs.setText("" + netQty);
						}
// System.out.println("position->"+nm+"="+scripCodeStopLoss+"=>"+nm.equalsIgnoreCase(scripCodeStopLoss));
						position = position + netQty + "->" + nm + "\n";
					}
				}
// System.out.println("position*->"+positionPrev+"="+position+"=>"+(updatepositiondataval
// / qtyIn1Lot));
				if (positionPrev.equalsIgnoreCase(position) == false) {
					positionPrev = position;
					positionBookJTextArea.setText(position);
				} else if (position.length() < 1) {
					positionPrev = "";
					positionBookJTextArea.setText("No Position");
				}
			}
		} catch (Exception ig) {
			logger.error("issue in Position reponse:" + responseBody, ig);
		}
	}
	static JPanel orderXchangePanel = null;
	private static JPanel createOrderXchangePanel() {
		orderXchangePanel = new JPanel();
		orderXchangePanel.setBackground(Color.WHITE);
		orderXchangePanel.setBounds(225, 235, 370, 260);
		orderXchangePanel.setSize(370, 260);
		orderXchangePanel.setLayout(new BoxLayout(orderXchangePanel, BoxLayout.Y_AXIS));
		return orderXchangePanel;
	}
	private static JPanel createOrderBookPanel() {
		JPanel orderPanel = new JPanel();
		orderPanel.setBackground(new Color(80, 40, 20));
		orderPanel.setBounds(225, 205, 370, 30);
// orderPanel.setBounds(450, 205, 450, 250);
		orderPanel.setSize(370, 30);
		orderPanel.setLayout(null);
		JLabel lbl = new JLabel("OrderBox");
		lbl.setForeground(Color.WHITE);
		lbl.setFont(new Font("Serif", Font.PLAIN, 10));
		lbl.setBounds(1, 1, 44, 14);
		orderPanel.add(lbl);
		JButton refreshWatcherbutton = new JButton("Refresh");
		refreshWatcherbutton.setBorder(null);
		refreshWatcherbutton.setBackground(Color.BLUE);
		refreshWatcherbutton.setForeground(Color.WHITE);
		refreshWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		refreshWatcherbutton.setBounds(46, 2, 44, 18);// (246, 2, 80, 18);
		refreshWatcherbutton.setVisible(true);
		refreshWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				loadorderbook();
			}
		});
		orderPanel.add(refreshWatcherbutton);
		JButton refreshCancelWatcherbutton = new JButton("Refresh+Cancel");
		refreshCancelWatcherbutton.setBorder(null);
		refreshCancelWatcherbutton.setBackground(Color.BLUE);
		refreshCancelWatcherbutton.setForeground(Color.WHITE);
		refreshCancelWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		refreshCancelWatcherbutton.setBounds(93, 2, 90, 18);// (246, 2, 80, 18);
		refreshCancelWatcherbutton.setVisible(true);
		refreshCancelWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				loadorderbook();
				cancelAllOrder();
			}
		});
		orderPanel.add(refreshCancelWatcherbutton);
		JButton cancelAllOrderbutton = new JButton("CancelAll");
		cancelAllOrderbutton.setBorder(null);
		cancelAllOrderbutton.setBackground(Color.BLUE);
		cancelAllOrderbutton.setForeground(Color.WHITE);
		cancelAllOrderbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		cancelAllOrderbutton.setBounds(186, 2, 42, 18);// (340, 2, 100, 18);
		cancelAllOrderbutton.setVisible(true);
		cancelAllOrderbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cancelAllOrder();
			}
		});
		orderPanel.add(cancelAllOrderbutton);
		JButton startWatcherbutton = new JButton("StartWatcher");
		startWatcherbutton.setBorder(null);
		startWatcherbutton.setBackground(Color.BLUE);
		startWatcherbutton.setForeground(Color.WHITE);
		startWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		startWatcherbutton.setBounds(232, 2, 60, 18);
		startWatcherbutton.setVisible(true);
		startWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startWatcherbutton.setEnabled(false);
			}
		});
		orderPanel.add(startWatcherbutton);
		JButton stopWatcherbutton = new JButton("StopWatcher");
		stopWatcherbutton.setBorder(null);
		stopWatcherbutton.setBackground(Color.BLUE);
		stopWatcherbutton.setForeground(Color.WHITE);
		stopWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		stopWatcherbutton.setBounds(294, 2, 70, 18);
		stopWatcherbutton.setVisible(true);
		stopWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startWatcherbutton.setEnabled(true);
			}
		});
		orderPanel.add(stopWatcherbutton);
		return orderPanel;
	}
	private static JPanel createLocalOrderBookPanel() {
		JPanel localOrderPanel = new JPanel();
		localOrderPanel.setBackground(new Color(10, 40, 20));
// localOrderPanel.setBounds(0, 205, 450, 250);
		localOrderPanel.setBounds(595, 205, 300, 250);
		localOrderPanel.setSize(300, 250);
		localOrderPanel.setLayout(null);
		JLabel lbl = new JLabel("LocalOrderBox");
		lbl.setForeground(Color.RED);
		lbl.setFont(new Font("Serif", Font.PLAIN, 10));
		lbl.setBounds(1, 1, 62, 14);
		localOrderPanel.add(lbl);
		localorderBook.setEnabled(false);
		Font font = new Font("Segoe Script", Font.BOLD, 13);
		localorderBook.setFont(font);
		localorderBook.setText("localOrderBook");
		localorderBook.setBounds(10, 30, 270, 204);
		localOrderPanel.add(localorderBook);
		JButton startLocalWatcherbutton = new JButton("StartWatcher");
		startLocalWatcherbutton.setBorder(null);
		startLocalWatcherbutton.setBackground(Color.BLUE);
		startLocalWatcherbutton.setForeground(Color.WHITE);
		startLocalWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		startLocalWatcherbutton.setBounds(242, 2, 40, 18);
		startLocalWatcherbutton.setVisible(true);
		startLocalWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startLocalWatcherbutton.setEnabled(false);
			}
		});
		localOrderPanel.add(startLocalWatcherbutton);
		JButton stopLocalWatcherbutton = new JButton("StopWatcher");
		stopLocalWatcherbutton.setBorder(null);
		stopLocalWatcherbutton.setBackground(Color.BLUE);
		stopLocalWatcherbutton.setForeground(Color.WHITE);
		stopLocalWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 10));
		stopLocalWatcherbutton.setBounds(188, 2, 52, 18);
		stopLocalWatcherbutton.setVisible(true);
		stopLocalWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startLocalWatcherbutton.setEnabled(true);
			}
		});
		localOrderPanel.add(stopLocalWatcherbutton);
		JButton refreshLocalWatcherbutton = new JButton("Refresh");
		refreshLocalWatcherbutton.setBorder(null);
		refreshLocalWatcherbutton.setBackground(Color.BLUE);
		refreshLocalWatcherbutton.setForeground(Color.WHITE);
		refreshLocalWatcherbutton.setFont(new Font("Serif", Font.PLAIN, 11));
		refreshLocalWatcherbutton.setBounds(126, 2, 60, 18);
		refreshLocalWatcherbutton.setVisible(true);
		refreshLocalWatcherbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				localorderBook.setText(localOrdMsg);
			}
		});
		localOrderPanel.add(refreshLocalWatcherbutton);
		JButton cancelAllLocalOrderbutton = new JButton("Cancel");
		cancelAllLocalOrderbutton.setBorder(null);
		cancelAllLocalOrderbutton.setBackground(Color.BLUE);
		cancelAllLocalOrderbutton.setForeground(Color.WHITE);
		cancelAllLocalOrderbutton.setFont(new Font("Serif", Font.PLAIN, 11));
		cancelAllLocalOrderbutton.setBounds(63, 2, 60, 18);
		cancelAllLocalOrderbutton.setVisible(true);
		cancelAllLocalOrderbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				placeLocalOrdFor = "";
				for (int i = 0; i < 15; i++) {
					localOrderArr[i] = null;
				}
				localOrdMsg = "";
			}
		});
		localOrderPanel.add(cancelAllLocalOrderbutton);
		return localOrderPanel;
	}
	private static JPanel createCEPanel() {
		JPanel cePanel = new JPanel();
		cePanel.setBackground(Color.lightGray);
		cePanel.setBounds(0, 55, 450, 100);
		cePanel.setSize(450, 100);
		cePanel.setLayout(null);
		ceDataPickerbutton.setBackground(Color.GREEN);
		ceDataPickerbutton.setForeground(Color.WHITE);
		ceDataPickerbutton.setBounds(80, 2, 120, 20);
		ceDataPickerbutton.setVisible(true);
		ceDataPickerbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ceDataPickerbutton.setEnabled(false);
				peDataPickerbutton.setEnabled(false);
				ceScripCodeSelected = cetxt.getText().trim().toUpperCase();
				ceDataPickerWrkr = new CEDataPickerSwingWorker(ceScripCodeSelected, loginToken, txtPrcCE);
				ceDataPickerWrkr.execute();
			}
		});
		cePanel.add(ceDataPickerbutton);
		ceDataPickerStopbutton.setBackground(Color.GREEN);
		ceDataPickerStopbutton.setForeground(Color.WHITE);
		ceDataPickerStopbutton.setBounds(220, 2, 150, 20);
		ceDataPickerStopbutton.setVisible(true);
		ceDataPickerStopbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					ceDataPickerWrkr.cancel(true);
					ceDataPickerbutton.setEnabled(true);
					peDataPickerbutton.setEnabled(true);
					txtPrcCE.setText("0.00");
				} catch (Exception x) {
					logger.error(x);
				}
			}
		});
		cePanel.add(ceDataPickerStopbutton);
		JLabel lbl = new JLabel("CE:");
		lbl.setBounds(10, 24, 18, 20);
		cePanel.add(lbl);
		cetxt.setBounds(30, 24, 76, 20);
		cetxt.setText("NIFTY");
		cePanel.add(cetxt);
		JLabel lblNoOfLot = new JLabel("NoOfLot:");
		lblNoOfLot.setBounds(112, 24, 50, 20);
		cePanel.add(lblNoOfLot);
		JTextField txtNoOfLotCE = new JTextField(2);
		txtNoOfLotCE.setText("3");
		txtNoOfLotCE.setBounds(162, 24, 30, 20);
		cePanel.add(txtNoOfLotCE);
		JLabel lblPrcCE = new JLabel("Prc:");
		lblPrcCE.setBounds(194, 24, 24, 20);
		cePanel.add(lblPrcCE);
		txtPrcCE.setText("0.00");
		txtPrcCE.setBounds(220, 24, 60, 20);
		cePanel.add(txtPrcCE);
		JLabel lblAtMyPrcCE = new JLabel("AtMyPrc:");
		lblAtMyPrcCE.setBounds(120, 46, 54, 20);
		cePanel.add(lblAtMyPrcCE);
		JTextField txtAtMyPrcCE = new JTextField(2);
		txtAtMyPrcCE.setText("0.00");
		txtAtMyPrcCE.setBounds(176, 46, 50, 20);
		JTextField txtAtMyPrcStplsCE = new JTextField(2);
		txtAtMyPrcCE.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				String v = txtPrcCE.getText();
				txtAtMyPrcCE.setText(v);
				txtAtMyPrcStplsCE.setText(App.df.format(Double.valueOf(v) - (Double.valueOf(v) * stoplosspercent)));
			}
		});
		cePanel.add(txtAtMyPrcCE);
		JLabel lblAtMyPrcStplsCE = new JLabel("stopLos:");
		lblAtMyPrcStplsCE.setBounds(230, 46, 54, 20);
		cePanel.add(lblAtMyPrcStplsCE);
		txtAtMyPrcStplsCE.setText("0.00");
		txtAtMyPrcStplsCE.setBounds(284, 46, 40, 20);
		txtAtMyPrcStplsCE.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				String v = txtAtMyPrcCE.getText();
				txtAtMyPrcStplsCE.setText(App.df.format(Double.valueOf(v) - (Double.valueOf(v) * stoplosspercent)));
			}
		});
		cePanel.add(txtAtMyPrcStplsCE);
		JButton ceBuyAtMyPrcbutton = new JButton("BuyAtMyPrc");
		ceBuyAtMyPrcbutton.setBackground(Color.GREEN);
		ceBuyAtMyPrcbutton.setForeground(Color.WHITE);
		ceBuyAtMyPrcbutton.setBounds(328, 46, 110, 20);
		ceBuyAtMyPrcbutton.setVisible(true);
		ceBuyAtMyPrcbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				placeBuyOrder(ceScripCodeSelected, Double.valueOf(txtAtMyPrcCE.getText()),
						Double.valueOf(txtAtMyPrcStplsCE.getText()), Integer.valueOf(txtNoOfLotCE.getText()), "ce");
				new Thread(new Runnable() {
					@Override
					public void run() {
						txtScripCodeStpLs.setText(ceScripCodeSelected);
						txtStopLs.setText(txtAtMyPrcStplsCE.getText());
						txtTargetProfit.setText(App.df.format(
								Double.valueOf(txtAtMyPrcCE.getText()) + Double.valueOf(txtStopLsUpBy.getText())));
						txtNoOfLotStpLs.setText(txtNoOfLotCE.getText());
					}
				}).start();
			}
		});
		cePanel.add(ceBuyAtMyPrcbutton);
		JLabel lblSell = new JLabel("SellCE");
		lblSell.setForeground(Color.yellow);
		lblSell.setBounds(1, 74, 40, 20);
		cePanel.add(lblSell);
		JTextField txtNoOfLotCESell = new JTextField(2);
		txtPriceCESell.setText("");
		txtPriceCESell.setBounds(41, 74, 34, 20);
		cePanel.add(txtPriceCESell);
		JButton ceSellbuttonManual = new JButton("Sell");
		ceSellbuttonManual.setBorder(null);
		ceSellbuttonManual.setBackground(Color.GREEN);
		ceSellbuttonManual.setForeground(Color.YELLOW);
		ceSellbuttonManual.setBounds(77, 74, 40, 20);
		ceSellbuttonManual.setVisible(true);
		ceSellbuttonManual.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int quantity = Integer.valueOf(txtNoOfLotCESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + txtPriceCESell.getText()
									+ "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + ceScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		cePanel.add(ceSellbuttonManual);
		JLabel lblNoOfLotSell = new JLabel("NoOfLot:");
		lblNoOfLotSell.setBounds(118, 74, 50, 20);
		cePanel.add(lblNoOfLotSell);
		txtNoOfLotCESell.setText("1");
		txtNoOfLotCESell.setBounds(168, 74, 20, 20);
		cePanel.add(txtNoOfLotCESell);
		JButton ceSellbutton = new JButton("Sell");
		ceSellbutton.setBackground(Color.GREEN);
		ceSellbutton.setForeground(Color.YELLOW);
		ceSellbutton.setBounds(194, 74, 55, 20);
		ceSellbutton.setVisible(true);
		ceSellbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int quantity = Integer.valueOf(txtNoOfLotCESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + txtPrcCE.getText()
									+ "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + ceScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		cePanel.add(ceSellbutton);
		JButton ceSellOneNextbutton = new JButton("Sell+2%");
		ceSellOneNextbutton.setBorder(null);
		ceSellOneNextbutton.setBackground(Color.DARK_GRAY);
		ceSellOneNextbutton.setForeground(Color.YELLOW);
		ceSellOneNextbutton.setBounds(252, 74, 72, 20);
		ceSellOneNextbutton.setVisible(true);
		ceSellOneNextbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String prc = txtPrcCE.getText();
					Double prcval = Double.valueOf(prc);
					prcval = prcval + (prcval * .02);
					String nval = df.format(prcval);
					int quantity = Integer.valueOf(txtNoOfLotCESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + nval + "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""
									+ quantity + "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + ceScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
					nval = df.format(prcval + .1);
// Double nval = Double.valueOf(prc)+Double.valueOf(txtStopLsUpBy.getText());
					RequestBody body4saleNxt = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + nval + "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""
									+ quantity + "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + ceScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4saleNxt = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4saleNxt).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4saleNxt).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		cePanel.add(ceSellOneNextbutton);
		JButton ceSellAtMarketbutton = new JButton("Sell@Market");
		ceSellAtMarketbutton.setBackground(Color.GREEN);
		ceSellAtMarketbutton.setForeground(Color.YELLOW);
		ceSellAtMarketbutton.setBounds(328, 74, 110, 20);
		ceSellAtMarketbutton.setVisible(true);
		ceSellAtMarketbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int quantity = Integer.valueOf(txtNoOfLotCESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n"
									+ "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + ceScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		cePanel.add(ceSellAtMarketbutton);
		return cePanel;
	}
	public static final DecimalFormat df = new DecimalFormat("0.0");
	public static final DecimalFormat df1 = new DecimalFormat("0.00");
	public static final DecimalFormat df2 = new DecimalFormat("0.000");
	public static volatile OrderDetailNew[] localOrderArr = new OrderDetailNew[15];
	public static volatile String placeLocalOrdFor = "";
	public static String localOrdMsg = "";
	public static long orderpicktime = 0l;
	public static void placeBuyOrder(String scripCode, Double buyprc, double stopls, Integer noOfLotIdValue,
			String ceORpe) {
		try {
			orderpicktime = System.currentTimeMillis();
			if (noOfLotIdValue == 0)
				noOfLotIdValue = 1;
			Double prcMinus = (buyprc - stopls) / noOfLotIdValue;
			placeLocalOrdFor = "";
			if (isLocalOrder1st) {
				localOrdMsg = "";
				for (int i = 0; i < 15; i++) {
					localOrderArr[i] = null;
				}
				for (int xx = noOfLotIdValue; xx > 0; xx--) {
					double buyPrcCurrent = buyprc - (prcMinus * (xx - 1));
					int quantity = qtyIn1Lot;
					OrderDetailNew ord = new OrderDetailNew(buyPrcCurrent, stopls + 0.15, quantity);
					localOrderArr[noOfLotIdValue - xx] = ord;
					localOrdMsg = localOrdMsg + buyPrcCurrent + "->" + stopls + "=" + quantity + "\n";
				}
				placeLocalOrdFor = ceORpe;
			} else {
				for (int xx = noOfLotIdValue; xx > 0; xx--) {
					double buyPrcCurrent = buyprc - (prcMinus * (xx - 1));
					int quantity = qtyIn1Lot;
					RequestBody body4buy = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + App.df.format(buyPrcCurrent)
									+ "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"B\",\r\n\"tsym\":\"" + scripCode + "\"\r\n}&jKey="
									+ loginToken,
							mediaType_JSON);
					Request postRequest4buy = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder").method("POST", body4buy)
							.addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4buy).execute();
				}
			}
			if ("ce".equalsIgnoreCase(ceORpe)) {
				txtPriceCESell.setText(df.format(buyprc + 0.4));
			} else if ("pe".equalsIgnoreCase(ceORpe)) {
				txtPricePESell.setText(df.format(buyprc + 0.4));
			}
			TelegramUtil.sendTelegramMsgToChanel("Stoplossdetail:%0A"+scripCode+":"+stopls+":"+txtStopLsUpBy.getText()+":"+(buyprc+2.8)+"="+(waitInSec/60), "@Optionpositionwatcherchanel", "bot6225590752:AAFzdBzjl24b5J-qJP2dZaz6W0Y88UQQ78o", false);

			localorderBook.setText(localOrdMsg);
			loadorderbook();
		} catch (Exception px) {
			JOptionPane.showMessageDialog(null, "Some issue in order placement. Issue:" + px.getMessage());
			logger.error(px);
		}
	}
	public static void loadorderbook() {
		try {
			RequestBody body4order = RequestBody.create("jData={\r\n\"uid\":\"FA66519\"\r\n}&jKey=" + loginToken,
					mediaType_JSON);
			Request postRequest4buy = new Request.Builder()
					.url("https://api.shoonya.com/NorenWClientTP/OrderBook").method("POST", body4order)
					.addHeader("Content-Type", "application/json").build();
			Response response = client.newCall(postRequest4buy).execute();
			JSONArray jsonArr = new JSONArray(response.body().string());
			if (jsonArr != null) {
				orderXchangePanel.removeAll();
// String order = "";
				int ln = jsonArr.length();
				List<String> exchangeOrdIdtmp = new ArrayList<>();
				for (int i = 0; i < ln; i++) {
					JSONObject json = jsonArr.getJSONObject(i);
					String stts = json.getString("status");
					if ("OPEN".equalsIgnoreCase(stts) || stts.startsWith("PARTIAL")) {
						String ordId = json.getString("norenordno");
						String ttype = json.getString("trantype");
						exchangeOrdIdtmp.add(ordId);
						JButton b = new JButton();
						if ("B".equals(ttype)) {
							b.setBackground(Color.GREEN);
							b.setActionCommand("B," + ordId);
							b.setText("cancelBuy-" + json.getString("prc") + "-" + json.getString("qty") + "-"
									+ json.getString("tsym"));
						} else {
							String tysm = json.getString("tsym");
							String qty = json.getString("qty");
							b.setBackground(Color.RED);
							b.setActionCommand("S," + ordId + "," + tysm + "," + qty);
							b.setText("MktSale-" + json.getString("prc") + "-" + qty + "-" + tysm);
						}
						b.addActionListener(new java.awt.event.ActionListener() {
							public void actionPerformed(java.awt.event.ActionEvent e) {
								String cmd = e.getActionCommand();
								try {
									if (cmd.startsWith("B,")) {
										cmd = cmd.substring(2);
										cancelOrder(cmd);
									} else if (cmd.startsWith("S,")) {
										cmd = cmd.substring(2);
										int ix = cmd.indexOf(',');
										int ixn = cmd.lastIndexOf(',');
										try {
											String sale = "jData={\r\n\"norenordno\":\"" + cmd.substring(0, ix)
													+ "\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\r\n"
													+ "\"uid\":\"FA66519\",\r\n\"prc\":\"0.0\",\r\n\"qty\":\""
													+ cmd.substring(ixn + 1) + "\",\r\n\"ret\":\"DAY\",\r\n\"tsym\":\""
													+ cmd.substring(ix + 1, ixn) + "\"\r\n}&jKey=" + loginToken;
											RequestBody body4sale = RequestBody.create(sale, mediaType_JSON);
											Request postRequest4sale = new Request.Builder()
													.url("https://api.shoonya.com/NorenWClientTP/ModifyOrder")
													.method("POST", body4sale)
													.addHeader("Content-Type", "application/json").build();
											client.newCall(postRequest4sale).execute();
										} catch (Exception ppx) {
											logger.error(ppx);
										}
									}
								} catch (Exception px) {
									logger.error(px);
								}
							}
						});
						orderXchangePanel.add(b);
// order = order +
// json.getString("trantype")+"-"+json.getString("prc")+"-"+json.getString("qty")+"-"+json.getString("tsym")+"\n";
					}
				}
				exchangeOrdIds = exchangeOrdIdtmp;
				orderXchangePanel.revalidate();
				orderXchangePanel.repaint();
			}
		} catch (Exception x) {
			logger.error(x);
		}
	}
	public static void cancelOrder(String id) throws Exception {
		RequestBody body4cancelorder = RequestBody.create(
				"jData={\r\n\"uid\":\"FA66519\",\r\n\"norenordno\":\"" + id + "\"\r\n}&jKey=" + loginToken,
				mediaType_JSON);
		Request postRequest4cancel = new Request.Builder()
				.url("https://api.shoonya.com/NorenWClientTP/CancelOrder").method("POST", body4cancelorder)
				.addHeader("Content-Type", "application/json").build();
		client.newCall(postRequest4cancel).execute();
	}
	public static void cancelAllOrder() {
		try {
			if (exchangeOrdIds != null) {
				for (String id : exchangeOrdIds) {
					cancelOrder(id);
				}
			}
// if(isLocalOrder1st) {
			placeLocalOrdFor = "";
			for (int i = 0; i < 15; i++) {
				localOrderArr[i] = null;
			}
			localOrdMsg = "";
// }
		} catch (Exception x) {
			logger.error(x);
		}
	}
	private static JPanel createPEPanel() {
		JPanel pePanel = new JPanel();
		pePanel.setBackground(Color.CYAN);
		pePanel.setBounds(450, 55, 900, 100);
		pePanel.setSize(450, 100);
		pePanel.setLayout(null);
		peDataPickerbutton.setBackground(Color.RED);
		peDataPickerbutton.setForeground(Color.WHITE);
		peDataPickerbutton.setBounds(80, 2, 120, 20);
		peDataPickerbutton.setVisible(true);
		peDataPickerbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ceDataPickerbutton.setEnabled(false);
				peDataPickerbutton.setEnabled(false);
				peScripCodeSelected = petxt.getText().trim().toUpperCase();
				peDataPickerWrkr = new PEDataPickerSwingWorker(peScripCodeSelected, loginToken, txtPrcPE);
				peDataPickerWrkr.execute();
			}
		});
		pePanel.add(peDataPickerbutton);
		peDataPickerStopbutton.setBackground(Color.RED);
		peDataPickerStopbutton.setForeground(Color.WHITE);
		peDataPickerStopbutton.setBounds(220, 2, 150, 20);
		peDataPickerStopbutton.setVisible(true);
		peDataPickerStopbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					peDataPickerWrkr.cancel(true);
					ceDataPickerbutton.setEnabled(true);
					peDataPickerbutton.setEnabled(true);
					txtPrcPE.setText("0.00");
				} catch (Exception x) {
					logger.error(x);
				}
			}
		});
		pePanel.add(peDataPickerStopbutton);
		JLabel lbl = new JLabel("PE:");
		lbl.setBounds(10, 24, 18, 20);
		pePanel.add(lbl);
		petxt.setBounds(30, 24, 76, 20);
		petxt.setText("NIFTY");
		pePanel.add(petxt);
		JLabel lblNoOfLot = new JLabel("NoOfLot:");
		lblNoOfLot.setBounds(110, 24, 50, 20);
		pePanel.add(lblNoOfLot);
		JTextField txtNoOfLotPE = new JTextField(2);
		txtNoOfLotPE.setText("3");
		txtNoOfLotPE.setBounds(160, 24, 30, 20);
		pePanel.add(txtNoOfLotPE);
		JLabel lblPrcCE = new JLabel("Prc:");
		lblPrcCE.setBounds(194, 24, 24, 20);
		pePanel.add(lblPrcCE);
		txtPrcPE.setText("0.00");
		txtPrcPE.setBounds(220, 24, 60, 20);
		pePanel.add(txtPrcPE);
		JLabel lblAtMyPrcPE = new JLabel("AtMyPrc:");
		lblAtMyPrcPE.setBounds(100, 46, 56, 20);
		pePanel.add(lblAtMyPrcPE);
		JTextField txtAtMyPrcPE = new JTextField(2);
		txtAtMyPrcPE.setText("0.00");
		txtAtMyPrcPE.setBounds(158, 46, 50, 20);
		JTextField txtAtMyPrcstplsPE = new JTextField(2);
		txtAtMyPrcPE.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				String v = txtPrcPE.getText();
				txtAtMyPrcPE.setText(v);
				txtAtMyPrcstplsPE.setText(App.df.format(Double.valueOf(v) - (Double.valueOf(v) * stoplosspercent)));
			}
		});
		pePanel.add(txtAtMyPrcPE);
		JLabel lblAtMyPrcstplsPE = new JLabel("stopLos:");
		lblAtMyPrcstplsPE.setBounds(210, 46, 56, 20);
		pePanel.add(lblAtMyPrcstplsPE);
		txtAtMyPrcstplsPE.setText("0.00");
		txtAtMyPrcstplsPE.setBounds(266, 46, 50, 20);
		txtAtMyPrcstplsPE.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				String v = txtAtMyPrcPE.getText();
				txtAtMyPrcstplsPE.setText(App.df.format(Double.valueOf(v) - (Double.valueOf(v) * stoplosspercent)));
			}
		});
		pePanel.add(txtAtMyPrcstplsPE);
		JButton peBuyAtMyPrcbutton = new JButton("BuyAtMyPrc");
		peBuyAtMyPrcbutton.setBackground(Color.RED);
		peBuyAtMyPrcbutton.setForeground(Color.WHITE);
		peBuyAtMyPrcbutton.setBounds(318, 46, 120, 20);
		peBuyAtMyPrcbutton.setVisible(true);
		peBuyAtMyPrcbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				placeBuyOrder(peScripCodeSelected, Double.valueOf(txtAtMyPrcPE.getText()),
						Double.valueOf(txtAtMyPrcstplsPE.getText()), Integer.valueOf(txtNoOfLotPE.getText()), "pe");
				new Thread(new Runnable() {
					@Override
					public void run() {
						txtScripCodeStpLs.setText(peScripCodeSelected);
						txtStopLs.setText(txtAtMyPrcstplsPE.getText());
						txtTargetProfit.setText(App.df.format(
								Double.valueOf(txtAtMyPrcPE.getText()) + Double.valueOf(txtStopLsUpBy.getText())));
						txtNoOfLotStpLs.setText(txtNoOfLotPE.getText());
					}
				}).start();
			}
		});
		pePanel.add(peBuyAtMyPrcbutton);
		JLabel lblSell = new JLabel("SellPE");
		lblSell.setForeground(Color.yellow);
		lblSell.setBounds(1, 74, 40, 20);
		pePanel.add(lblSell);
		JTextField txtNoOfLotPESell = new JTextField(2);
		txtPricePESell.setText("");
		txtPricePESell.setBounds(41, 74, 34, 20);
		pePanel.add(txtPricePESell);
		JButton peSellbuttonManual = new JButton("Sell");
		peSellbuttonManual.setBorder(null);
		peSellbuttonManual.setBackground(Color.RED);
		peSellbuttonManual.setForeground(Color.YELLOW);
		peSellbuttonManual.setBounds(77, 74, 40, 20);
		peSellbuttonManual.setVisible(true);
		peSellbuttonManual.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int quantity = Integer.valueOf(txtNoOfLotPESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + txtPricePESell.getText()
									+ "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + peScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		pePanel.add(peSellbuttonManual);
		JLabel lblNoOfLotSell = new JLabel("NoOfLot:");
		lblNoOfLotSell.setBounds(118, 74, 50, 20);
		pePanel.add(lblNoOfLotSell);
		txtNoOfLotPESell.setText("1");
		txtNoOfLotPESell.setBounds(168, 74, 20, 20);
		pePanel.add(txtNoOfLotPESell);
		JButton peSellbutton = new JButton("Sell");
		peSellbutton.setBackground(Color.RED);
		peSellbutton.setForeground(Color.YELLOW);
		peSellbutton.setBounds(194, 74, 55, 20);
		peSellbutton.setVisible(true);
		peSellbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int quantity = Integer.valueOf(txtNoOfLotPESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + txtPrcPE.getText()
									+ "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + peScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		pePanel.add(peSellbutton);
		JButton peSellOneNextbutton = new JButton("Sell+2%");
		peSellOneNextbutton.setBorder(null);
		peSellOneNextbutton.setBackground(Color.PINK);
		peSellOneNextbutton.setForeground(Color.YELLOW);
		peSellOneNextbutton.setBounds(252, 74, 72, 20);
		peSellOneNextbutton.setVisible(true);
		peSellOneNextbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String prc = txtPrcPE.getText();
					Double prcval = Double.valueOf(prc);
					prcval = prcval + (prcval * .02);
					String nval = df.format(prcval);
					int quantity = Integer.valueOf(txtNoOfLotPESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + nval + "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""
									+ quantity + "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + peScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
// Double nval = Double.valueOf(prc)+Double.valueOf(txtStopLsUpBy.getText());
					nval = df.format(prcval + .1);
					RequestBody body4saleNxt = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"LMT\",\n"
									+ "\"prc\":\"" + nval + "\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""
									+ quantity + "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + peScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4saleNxt = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4saleNxt).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4saleNxt).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		pePanel.add(peSellOneNextbutton);
		JButton peSellAtMarketbutton = new JButton("Sell@Market");
		peSellAtMarketbutton.setBackground(Color.RED);
		peSellAtMarketbutton.setForeground(Color.YELLOW);
		peSellAtMarketbutton.setBounds(330, 74, 110, 20);
		peSellAtMarketbutton.setVisible(true);
		peSellAtMarketbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int quantity = Integer.valueOf(txtNoOfLotPESell.getText()) * qtyIn1Lot;
					RequestBody body4sale = RequestBody.create(
							"jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n"
									+ "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\"" + quantity
									+ "\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\"" + peScripCodeSelected
									+ "\"\r\n}&jKey=" + loginToken,
							mediaType_JSON);
					Request postRequest4sale = new Request.Builder()
							.url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
							.method("POST", body4sale).addHeader("Content-Type", "application/json").build();
					client.newCall(postRequest4sale).execute();
				} catch (Exception ppx) {
					logger.error(ppx);
				}
			}
		});
		pePanel.add(peSellAtMarketbutton);
		return pePanel;
	}
	private static JPanel createStopLossPanel() {
		JPanel stopLossPanel = new JPanel();
		stopLossPanel.setBounds(0, 155, 900, 50);
		stopLossPanel.setSize(900, 50);
		stopLossPanel.setLayout(null);
		stopLossPanel.setBackground(new Color(8, 120, 160));
		JButton startStpLsbutton = new JButton("startStopLossTrigger");
		startStpLsbutton.setBackground(Color.BLACK);
		startStpLsbutton.setForeground(Color.WHITE);
		startStpLsbutton.setBounds(240, 1, 160, 22);
		startStpLsbutton.setVisible(true);
		startStpLsbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startStpLsbutton.setEnabled(false);
				stopLossTriggerWrkr = new StopLossTriggerWorker(txtScripCodeStpLs.getText(), loginToken, qtyIn1Lot,
						txtNoOfLotStpLs, txtStopLs, txtTargetProfit, Double.valueOf(txtTargetProfit.getText()),
						Double.valueOf(txtStopLs.getText()), Double.valueOf(txtStopLsUpBy.getText()),
						Integer.valueOf(txtLot2SaleAtProfit.getText()), Integer.valueOf(txtNoOfLotStpLs.getText()),
						orderpicktime, waitInSec);
				stopLossTriggerWrkr.execute();
			}
		});
		stopLossPanel.add(startStpLsbutton);
		JButton stopStpLsbutton = new JButton("stopStopLossTrigger");
		stopStpLsbutton.setBackground(Color.BLACK);
		stopStpLsbutton.setForeground(Color.WHITE);
		stopStpLsbutton.setBounds(410, 1, 160, 22);
		stopStpLsbutton.setVisible(true);
		stopStpLsbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stopLossTriggerWrkr.cancel(true);
					startStpLsbutton.setEnabled(true);
				} catch (Exception x) {
					logger.error(x);
				}
			}
		});
		stopLossPanel.add(stopStpLsbutton);
		txtScripCodeStpLs.setForeground(Color.GREEN);
		txtScripCodeStpLs.setFont(new Font("Serif", Font.PLAIN, 12));
		txtScripCodeStpLs.setBounds(2, 25, 80, 20);
		stopLossPanel.add(txtScripCodeStpLs);
		txtScripCodeStpLs.setText("NIFTY");
		JLabel lbllot = new JLabel("NoOfLot:");
		lbllot.setBounds(84, 25, 50, 20);
		stopLossPanel.add(lbllot);
		txtNoOfLotStpLs.setBounds(134, 25, 30, 20);
		txtNoOfLotStpLs.setText("0");
		stopLossPanel.add(txtNoOfLotStpLs);
		JLabel lblStpLs = new JLabel("StopLs:");
		lblStpLs.setBounds(166, 25, 46, 20);
		stopLossPanel.add(lblStpLs);
		txtStopLs.setBounds(212, 25, 40, 20);
		txtStopLs.setText("0");
		stopLossPanel.add(txtStopLs);
		JLabel lblStpLsUpBy = new JLabel("StopLsUpBy(Rs):");
		lblStpLsUpBy.setBounds(253, 25, 96, 20);
		stopLossPanel.add(lblStpLsUpBy);
		txtStopLsUpBy.setBounds(350, 25, 30, 20);
		txtStopLsUpBy.setText("0.8");
		stopLossPanel.add(txtStopLsUpBy);
		JLabel lblTargetProfit = new JLabel("TargetProfit:");
		lblTargetProfit.setBounds(380, 25, 80, 20);
		stopLossPanel.add(lblTargetProfit);
		txtTargetProfit.setBounds(461, 25, 50, 20);
		txtTargetProfit.setText("0");
		stopLossPanel.add(txtTargetProfit);
		JLabel lblLot2SaleAtProfit = new JLabel("Lot2SaleAtProfit:");
		lblLot2SaleAtProfit.setBounds(516, 25, 100, 20);
		stopLossPanel.add(lblLot2SaleAtProfit);
		txtLot2SaleAtProfit.setBounds(616, 25, 50, 20);
		txtLot2SaleAtProfit.setText("1");
		stopLossPanel.add(txtLot2SaleAtProfit);
		return stopLossPanel;
	}
	private static JPanel createTopPanel() {
		topPanel = new JPanel();
		topPanel.setBounds(0, 0, 900, 50);
		topPanel.setSize(900, 50);
		topPanel.setLayout(null);
		JLabel lbl = new JLabel("OTP:");
		lbl.setBounds(1, 2, 30, 20);
		topPanel.add(lbl);
		JTextField tkntxt = new JTextField(8);
		tkntxt.setBounds(31, 2, 40, 20);
		topPanel.add(tkntxt);
		JButton generateTknbutton = new JButton("GenerateTkn");
		generateTknbutton.setFont(new Font("Serif", Font.PLAIN, 11));
		generateTknbutton.setBackground(Color.BLUE);
		generateTknbutton.setForeground(Color.WHITE);
		generateTknbutton.setBounds(72, 2, 96, 20);
		generateTknbutton.setVisible(true);
		generateTknbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					loginToken = FinvasiaUtil.getLoginToken();
					JOptionPane.showMessageDialog(null, loginToken);
					/*
					 *
					 * loginToken = tkntxt.getText(); RequestBody body = RequestBody.create(
					 *
					 * "jData={\r\n\"apkversion\":\"1.0.15\",\r\n\"uid\":\"FA66519\",\r\n\"pwd\":\"4cf088a16467762aa1b328fe0ff8096368ac30808de1fa9156d8878b86fc0735\",\r\n\"factor2\":\""
					 *
					 * +loginToken+
					 *
					 * "\",\r\n\"imei\":\"abc1234\",\r\n\"source\":\"API\",\r\n\"vc\":\"FA66519_U\",\r\n\"appkey\":\"990870e924dce76cfc2bf55365fb482435a5a255afe6b0fdd3e49f834caa8f31\"\r\n}",
					 *
					 * mediaType_JSON); Request postRequest = new Request.Builder()
					 *
					 * .url("https://shoonyatrade.finvasia.com/NorenWClientTP/QuickAuth")
					 *
					 * .method("POST", body) .addHeader("Content-Type", "application/json").build();
					 *
					 * Response response = client.newCall(postRequest).execute(); String bd =
					 *
					 * response.body().string(); System.out.println("loginResponse:"+bd); JSONObject
					 *
					 * json = new JSONObject(bd); loginToken = json.getString("susertoken"); actid =
					 *
					 * json.getString("actid"); JOptionPane.showMessageDialog(null, loginToken);
					 *
					 */
				} catch (Exception ex) {
					logger.error(ex);
					JOptionPane.showMessageDialog(null, "Issue:" + ex.getMessage());
				}
			}
		});
		topPanel.add(generateTknbutton);
		JLabel stplsp = new JLabel("StpLs%:");
		stplsp.setBounds(320, 2, 50, 20);
		topPanel.add(stplsp);
		txtStplsp.setText("6");
		txtStplsp.setBounds(372, 2, 40, 20);
		topPanel.add(txtStplsp);
		JLabel lblQtyIn1Lot = new JLabel("QtyIn1Lot:");
		lblQtyIn1Lot.setBounds(414, 2, 60, 20);
		topPanel.add(lblQtyIn1Lot);
		JTextField txtQtyIn1Lot = new JTextField(2);
		txtQtyIn1Lot.setText("50");
		txtQtyIn1Lot.setBounds(476, 2, 40, 20);
		topPanel.add(txtQtyIn1Lot);
		JLabel lblWaitInSec = new JLabel("WaitInSec:");
		lblWaitInSec.setBounds(520, 2, 64, 20);
		topPanel.add(lblWaitInSec);
		JTextField txtWaitInSec = new JTextField(3);
		txtWaitInSec.setText("60");
		txtWaitInSec.setBounds(586, 2, 40, 20);
		topPanel.add(txtWaitInSec);
		JCheckBox checkBoxLocalOrder = new JCheckBox("LocalOrder1st");
		checkBoxLocalOrder.setFont(new Font("Serif", Font.PLAIN, 12));
		checkBoxLocalOrder.setBounds(630, 2, 100, 20);
		checkBoxLocalOrder.setSelected(true);
		topPanel.add(checkBoxLocalOrder);
		JButton updatebutton = new JButton("Update");
		updatebutton.setBackground(Color.BLUE);
		updatebutton.setForeground(Color.WHITE);
		updatebutton.setBounds(740, 2, 80, 20);
		updatebutton.setVisible(true);
		updatebutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stoplosspercent = Double.valueOf(txtStplsp.getText()) / 100;
					qtyIn1Lot = Integer.valueOf(txtQtyIn1Lot.getText());
					waitInSec = Integer.valueOf(txtWaitInSec.getText());
					isLocalOrder1st = checkBoxLocalOrder.isSelected();
					ceDataPickerbutton.setEnabled(true);
					peDataPickerbutton.setEnabled(true);
					txtPrcCE.setText("0.00");
					txtPrcPE.setText("0.00");
					try {
						ceDataPickerWrkr.cancel(true);
					} catch (Exception n) {
					}
					try {
						peDataPickerWrkr.cancel(true);
					} catch (Exception n) {
					}
					JOptionPane.showMessageDialog(null, "Updated Successfully! Please start CE/PE data picker again");
				} catch (Exception ex) {
					logger.error(ex);
					JOptionPane.showMessageDialog(null, "Issue:" + ex.getMessage());
				}
			}
		});
		topPanel.add(updatebutton);
		JCheckBox checkBoxUseWebSocket = new JCheckBox("useWebSocket");
		checkBoxUseWebSocket.setFont(new Font("Serif", Font.PLAIN, 12));
		checkBoxUseWebSocket.setBounds(1, 28, 96, 20);
		checkBoxUseWebSocket.setSelected(false);
		checkBoxUseWebSocket.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {
				JCheckBox checkBox = (JCheckBox) event.getSource();
				if (checkBox.isSelected()) {
					ceDataPickerbutton.setEnabled(false);
					ceDataPickerStopbutton.setEnabled(false);
					peDataPickerbutton.setEnabled(false);
					peDataPickerStopbutton.setEnabled(false);
					startWebsockebutton.setEnabled(true);
					stopWebsockebutton.setEnabled(true);
					subscribeWebsockebutton.setEnabled(true);
					unsubscribeWebsockebutton.setEnabled(true);
					checkBoxToUseWebSocketSelected = true;
				} else {
					startWebsockebutton.setEnabled(false);
					stopWebsockebutton.setEnabled(false);
					subscribeWebsockebutton.setEnabled(false);
					unsubscribeWebsockebutton.setEnabled(false);
					ceDataPickerbutton.setEnabled(true);
					ceDataPickerStopbutton.setEnabled(true);
					peDataPickerbutton.setEnabled(true);
					peDataPickerStopbutton.setEnabled(true);
					checkBoxToUseWebSocketSelected = false;
				}
			}
		});
		topPanel.add(checkBoxUseWebSocket);
		startWebsockebutton = new JButton("startWebSocket");
		startWebsockebutton.setBackground(Color.BLUE);
		startWebsockebutton.setForeground(Color.WHITE);
		startWebsockebutton.setBounds(100, 28, 128, 20);
		startWebsockebutton.setVisible(true);
		startWebsockebutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					connectToWebSocket();
				} catch (Exception ex) {
					logger.error(ex);
					JOptionPane.showMessageDialog(null, "Issue:" + ex.getMessage());
				}
			}
		});
		topPanel.add(startWebsockebutton);
		stopWebsockebutton = new JButton("stopWebSocket");
		stopWebsockebutton.setBackground(Color.BLUE);
		stopWebsockebutton.setForeground(Color.WHITE);
		stopWebsockebutton.setBounds(230, 28, 128, 20);
		stopWebsockebutton.setVisible(true);
		stopWebsockebutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					disConnectWebSocket();
				} catch (Exception ex) {
					logger.error(ex);
					JOptionPane.showMessageDialog(null, "Issue:" + ex.getMessage());
				}
			}
		});
		topPanel.add(stopWebsockebutton);
		subscribeWebsockebutton = new JButton("Subscribe");
		subscribeWebsockebutton.setBackground(Color.BLUE);
		subscribeWebsockebutton.setForeground(Color.WHITE);
		subscribeWebsockebutton.setBounds(362, 28, 94, 20);
		subscribeWebsockebutton.setVisible(true);
		subscribeWebsockebutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					subscribeToWebSocket();
				} catch (Exception ex) {
					logger.error(ex);
					JOptionPane.showMessageDialog(null, "Issue:" + ex.getMessage());
				}
			}
		});
		topPanel.add(subscribeWebsockebutton);
		unsubscribeWebsockebutton = new JButton("UnSubscribe");
		unsubscribeWebsockebutton.setBackground(Color.BLUE);
		unsubscribeWebsockebutton.setForeground(Color.WHITE);
		unsubscribeWebsockebutton.setBounds(460, 28, 108, 20);
		unsubscribeWebsockebutton.setVisible(true);
		unsubscribeWebsockebutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					unsubscribeToWebSocket();
				} catch (Exception ex) {
					logger.error(ex);
					JOptionPane.showMessageDialog(null, "Issue:" + ex.getMessage());
				}
			}
		});
		topPanel.add(unsubscribeWebsockebutton);
		startWebsockebutton.setEnabled(false);
		stopWebsockebutton.setEnabled(false);
		subscribeWebsockebutton.setEnabled(false);
		unsubscribeWebsockebutton.setEnabled(false);
		ceDataPickerbutton.setEnabled(false);
		ceDataPickerStopbutton.setEnabled(false);
		peDataPickerbutton.setEnabled(false);
		peDataPickerStopbutton.setEnabled(false);
		return topPanel;
	}
	static JButton startWebsockebutton;
	static JButton stopWebsockebutton;
	static JButton subscribeWebsockebutton;
	static JButton unsubscribeWebsockebutton;
	static boolean checkBoxToUseWebSocketSelected = false;
}