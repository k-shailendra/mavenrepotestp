package com.sharemarket.shailendra.finvasia;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionStage;

import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;

public class FinvasiaDepthPicker {
	static WebSocket ws = null;
	public static void connect2socket(String []codes) {
		try {
			disconnect2socket();
			String wsurl = "wss://api.shoonya.com/NorenWSTP/";
    		ws = HttpClient.newHttpClient().newWebSocketBuilder().buildAsync(URI.create(wsurl), new WebSocketClientDepthPicker(codes))
                    .join();
		}catch(Exception px) {
			px.printStackTrace();
		}
	}
	
	public static void disconnect2socket() {
		try {
	    	if(ws != null) {
		    	try {
		    		ws.sendClose(WebSocket.NORMAL_CLOSURE, "ok");
		    	}catch(Exception xp) {
		    		xp.printStackTrace();
		    	}
		    	try {
		    		ws.abort();
		    	}catch(Exception xp) {
		    		xp.printStackTrace();
		    	}
	    	}
		}catch(Exception px) {
			px.printStackTrace();
		}
	}
	
	public static void subscribe2socket(String[] data2subscribe) {
		/*try {
			if(ws != null && data2subscribe != null) {
				String substoken = "";
				for (String st : data2subscribe) {
					String token = FinvasiaUtil.getFinvasiaScripToken(st.toUpperCase(), "NFO");
					if(token != null) {
						substoken = substoken+"NFO|"+token+"#";
					}
				}
				int ln = substoken.length();
				if(ln > 5) {
					ws.sendText("{\"t\":\"d\",\"k\":\"NFO|49613\"}", true);
					//ws.sendText("{\"t\":\"d\",\"k\":\""+substoken.substring(0, ln-1)+"\"}", true);
					//System.out.println("---->Depth:" +substoken.substring(0, ln-1));
					//ws.request(1);
				}
			}
		}catch(Exception px) {
			px.printStackTrace();
		}*/
	}
	
    private static class WebSocketClientDepthPicker implements WebSocket.Listener {
    	Map<String, String> token2codeMap = null;
    	String substoken = "";
        public WebSocketClientDepthPicker(String[] data2subscribe) {
        	token2codeMap = new HashMap<>();
        	substoken = "";
        	try {
    			if(data2subscribe != null) {
    				for (String st : data2subscribe) {
    					String token = FinvasiaUtil.getFinvasiaScripToken(st.toUpperCase(), "NFO");
    					if(token != null) {
    						token2codeMap.put(token, st);
    						substoken = substoken+"NFO|"+token+"#";
    					}
    				}
    			}
    		}catch(Exception px) {
    			px.printStackTrace();
    		}
        }
    	@Override
    	public void onOpen(WebSocket webSocket) {
    	    WebSocket.Listener.super.onOpen(webSocket);
    	    webSocket.sendText("{\"t\":\"c\",\"uid\":\"FA66519\",\"actid\":\"FA66519\",\"source\":\"API\",\"susertoken\":\""+App.loginToken+"\"}", true);
    	}
    	@Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            try {
            	String rsp = data.toString();
                //System.out.println("---->Depth onText received=" + data);
	            if(rsp.contains("\"t\": \"ck\",")) {
	            	//ws.sendText("{\"t\":\"d\",\"k\":\"NFO|49613\"}", true);
	            	int ln = substoken.length();
					if(ln > 5) {
						ws.sendText("{\"t\":\"d\",\"k\":\""+substoken.substring(0, ln-1)+"\"}", true);
					}
	            }else if(rsp.contains("\"t\":\"dk\",") || rsp.contains("\"t\":\"df\",")){
	                JSONObject json = new JSONObject(rsp);
	                int ltq = 0;
	                try {
	                	ltq = Integer.valueOf(json.getString("ltq"));
	                }catch(Exception ix) {
	                }
	                if(ltq > 2000) {
		                String tkn = json.getString("tk");
		                tkn = token2codeMap.get(tkn);
		                String ltp = "";
		                try {
		                	ltp = json.getString("lp");
		                }catch(Exception x) {
		                	try {
		                		ltp = json.getString("bp1");
		                	}catch(Exception xx) {
		                		ltp = json.getString("sp1");
		                	}
		                }
		                TelegramUtil.sendTelegramMsg("Token:"+tkn+",qty="+ltq+" traded at:"+ltp, "-547540350", false);
	                }else {
	                	int bq1 = 0;
		                try {
		                	bq1 = Integer.valueOf(json.getString("bq1"));
		                }catch(Exception ix) {
		                }
		                int sq1 = 0;
		                try {
		                	sq1 = Integer.valueOf(json.getString("sq1"));
		                }catch(Exception ix) {
		                }
		                if(sq1>0 && bq1>2000 && (bq1/sq1)>500) {
		                	String tkn = json.getString("tk");
			                tkn = token2codeMap.get(tkn);
			                TelegramUtil.sendTelegramMsg("T:"+tkn+",qtyBUYby="+App.df.format(bq1/sq1), "-547540350", false);
		                }
		                if(bq1>0 && sq1>2000 && (sq1/bq1)>500) {
		                	String tkn = json.getString("tk");
			                tkn = token2codeMap.get(tkn);
			                TelegramUtil.sendTelegramMsg("T:"+tkn+",qtySELLby="+App.df.format(sq1/bq1), "-547540350", false);
		                }
	                }
	            }
            }catch(Exception xp) {
            	xp.printStackTrace();
            }
            webSocket.request(1);
            return null;
        }
    	
        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            System.out.println("Bad day for depth picker! " + webSocket.toString()+", error="+error.getStackTrace());
            WebSocket.Listener.super.onError(webSocket, error);
        }
     }

}
