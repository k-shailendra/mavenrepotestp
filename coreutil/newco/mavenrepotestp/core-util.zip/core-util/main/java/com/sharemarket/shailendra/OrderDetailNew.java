package com.sharemarket.shailendra;

public class OrderDetailNew {
	private Double mxP = 0.0;
	private Double mnP = 0.0;
	private int qty = 0;
	
	public OrderDetailNew(Double mxP, Double mnP, int quantity) {
		this.mxP = mxP;
		this.mnP = mnP;
		this.qty = quantity;
	}

	public Double getMxP() {
		return mxP;
	}

	public void setMxP(Double mxP) {
		this.mxP = mxP;
	}

	public Double getMnP() {
		return mnP;
	}

	public void setMnP(Double mnP) {
		this.mnP = mnP;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}
	
}
