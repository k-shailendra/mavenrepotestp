package com.sharemarket.shailendra.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CommonUtils {
	public static String[] tradeNotAllowed4Day = new String[] {"30Mar23", "04Apr23", "07Apr23","14Apr23","01May23","28Jun23","15Aug23","19Sep23","02Oct23","24Oct23",
			"14Nov23","27Nov23","25Dec23"};
	private static final SimpleDateFormat sf = new SimpleDateFormat("ddMMMyy");
	public static boolean isTradingAllowedToday(Calendar _current) {
		try {
            if(_current.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY || _current.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            	return false;
            }else {
            	String today = sf.format(_current.getTime());
            	for (String t : tradeNotAllowed4Day) {
					if(t.equalsIgnoreCase(today))
						return false;
				}
            	return true;
            }
		}catch(Exception px) {
			px.printStackTrace();
		}
		return false;
	}
	
	public static String getNiftyBankNiftyWeeklyExpiryDate() throws Exception {
		Calendar cal = Calendar.getInstance();
		Calendar tday = cal;
		int cnt = -1;
		for(int i=0; i<7; i++) {
        	if(isTradingAllowedToday(cal)) {
        		tday = cal;
        		cnt = i;
        	}
			if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY) {
				break;
            }
			cal.add(Calendar.DAY_OF_MONTH, 1);
		}
		return cnt+"#"+sf.format(tday.getTime()).toUpperCase();
	}

}
