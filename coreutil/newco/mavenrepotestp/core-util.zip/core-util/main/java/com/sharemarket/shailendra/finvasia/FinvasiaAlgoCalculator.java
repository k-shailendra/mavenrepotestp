package com.sharemarket.shailendra.finvasia;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.ConstantScrips;
import com.sharemarket.shailendra.RepositoryClass;
import com.sharemarket.shailendra.StockMarketUtil;
import com.sharemarket.shailendra.utils.AlgoUtils;
import com.sharemarket.shailendra.utils.CommonUtils;
import com.sharemarket.shailendra.utils.FinvasiaUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;

import okhttp3.Request;
import okhttp3.RequestBody;

public class FinvasiaAlgoCalculator implements Runnable {
    private static final Logger logger = LogManager.getLogger(FinvasiaAlgoCalculator.class);
	String algoName;
	Map<String, String> codeTokenMap;
	Integer candleTime;
	Integer dataPickGapInMonth;
	String telegramchanelId;
	Double[] gap = new Double[] {3.0};
	boolean pricevolumecheck = false;
	boolean runTemaAlgo = false;
	
	Map<String, String> codeTokenMapForLowerTimeCandle;
	String telegramTitle;
	Double volhike = 10.2;
	
	long telegramMsgId = 0;
	String temp = "";
	
	public FinvasiaAlgoCalculator(String algoName, Map<String, String> codeTokenMap, Integer candleTime, Integer dataPickGapInMonth, String telegramchanelId, String telegramTitle, Double[] gap, Map<String, String> codeTokenMapForLowerTimeCandle, boolean pricevolumecheck, boolean runTemaAlgo, Double volhike) {
		this.algoName = algoName;
		this.codeTokenMap = codeTokenMap;
		this.candleTime = candleTime;
		this.dataPickGapInMonth = dataPickGapInMonth;
		this.telegramchanelId = telegramchanelId;
		this.gap = gap;
		
		this.telegramTitle = telegramTitle;
		this.codeTokenMapForLowerTimeCandle = codeTokenMapForLowerTimeCandle;
		this.pricevolumecheck = pricevolumecheck;
		this.runTemaAlgo = runTemaAlgo;
		this.volhike = volhike;
	}
	
	@Override
	public void run() {
		try {
			Calendar cal = Calendar.getInstance();
			if(CommonUtils.isTradingAllowedToday(cal)) {
				int mn = cal.get(Calendar.MINUTE);
				int hr = cal.get(Calendar.HOUR_OF_DAY);
				boolean canrun = false;
				if(hr > 8 && hr <= 16) {
					if(hr ==9 && mn >14) {
						canrun = true;
					}else if(hr == 16 && mn < 50) {
						canrun = true;
					}else {
						canrun = true;
					}
				}
				if(canrun) {
						StringBuffer temaCandleBuffer  = new StringBuffer("<b>"+this.telegramTitle+":4c-11c or 4c-22l:"+hr+":"+mn+"</b>%0A%0A");
						StringBuffer rsiBuffer = new StringBuffer("<b>"+this.telegramTitle+":RSI:"+hr+":"+mn+"</b>%0A%0A");
					
						String temaCandle  = "<b>"+this.telegramTitle+hr+":"+mn+"</b>%0A%0A";
						StringBuffer buf = new StringBuffer();
		        		StringBuffer msg = new StringBuffer("<b><i>PriceVolume</i></b>%0A");
		        		logger.info("-->Algo calculator Running for candle:"+temaCandle);
						
						Map<String, Double> nameClsPrcMap = new HashMap<>();
						if("MyScrip-60 Min-Candle-TEMA-".equals(this.telegramTitle)) {
			        		String commandfromtelegram = TelegramUtil.getLatestTelegramMsgFromGroup(this.telegramchanelId);
			        		if(commandfromtelegram != null) {
			        			try {
			        				int xi = commandfromtelegram.indexOf("@@##@@");
				        			long telegramMsgIdcur = Long.valueOf(commandfromtelegram.substring(0, xi));
					        		//System.out.println(telegramMsgId+"="+telegramMsgIdcur+"%%%%%%=="+commandfromtelegram);
				        			if(telegramMsgIdcur > telegramMsgId) {
				        				telegramMsgId = telegramMsgIdcur;
				        				commandfromtelegram = commandfromtelegram.substring(xi+6);
				        				if(commandfromtelegram != null &&commandfromtelegram.trim().length()>0) {
				        					if(commandfromtelegram.startsWith("Stop")==true||commandfromtelegram.startsWith("stop")==true) {
				        						nameClsPrcMap.clear();
				        						TelegramUtil.sendTelegramMsg("Stopped watching all scrip. For renew send scrip in format->scrip:stoplossprc-sellprc like voltas:880:980", telegramchanelId, false);
				        					}else {
					        					String []oderDetailArrfromtelegram = commandfromtelegram.split("\n");
					        					Set<String> scripset = new HashSet<>();
					        					for (String orddata : oderDetailArrfromtelegram) {
					        						int inx = orddata.indexOf(':');
					        						String scrp = orddata.substring(0, inx);
					        						scripset.add(scrp);
					        						int index = orddata.indexOf('-');
					        						nameClsPrcMap.put(scrp+"-mx", Double.valueOf(orddata.substring(inx+1, index)));
					        						nameClsPrcMap.put(scrp+"-mn", Double.valueOf(orddata.substring(index+1)));
												}
					        					RepositoryClass.myScripsToFinvasiaTokenMap.clear();
					        					RepositoryClass.myScripsToFinvasiaTokenMap.putAll(FinvasiaUtil.getFinvasiaScripTokenMap(scripset, "NSE"));
				        					}
				        				}
				        			}
			        			}catch(Exception px) {
			        				TelegramUtil.sendTelegramMsg("please send stop or scrip in format->scrip:stoplossprc-sellprc like voltas:880:980", telegramchanelId, false);
			        				logger.error("please send stop or scrip in format->scrip:stoplossprc-sellprc like voltas:880:980",px);
			        			}
			        		}
						}
						
						Long endTimeInSec = cal.getTimeInMillis()/1000;
						if(runTemaAlgo == false)
							cal.add(Calendar.DATE, -1);
						else
							cal.add(Calendar.MONTH, dataPickGapInMonth*-1);
						Long stTimeInSec = cal.getTimeInMillis()/1000;
						if(codeTokenMap != null) {
							int cnt = 0;
							int gplnth = gap.length;
							
							java.util.HashMap<String,String> codeTokenMapCloned = (java.util.HashMap<String,String>) (((java.util.HashMap<String,String>)codeTokenMap).clone());
							Iterator<Entry<String, String>> codeTokenitrt = codeTokenMapCloned.entrySet().iterator();
							while(codeTokenitrt.hasNext()) {
								Entry<String, String> entry = codeTokenitrt.next();
								try {
									String dataresp = FinvasiaUtil.getTimeSeriesData(stTimeInSec, endTimeInSec, entry.getValue(), candleTime, "NSE");
									JSONArray jsonA = new JSONArray(dataresp);
					            	
					            	if(pricevolumecheck == true) {
					            		JSONObject obj = jsonA.getJSONObject(0);
					            		long intv0 = obj.getLong("intv");
					            		Double p1 = obj.getDouble("intc");
					            		Double o1 = obj.getDouble("into");
					            		obj = jsonA.getJSONObject(1);
					            		long intv1 = obj.getLong("intv");
					            		Double p2 = obj.getDouble("intc");
					            		Double o2 = obj.getDouble("into");
					            		Double l2 = obj.getDouble("intl");
					            		long v1 = obj.getLong("v");
					            		obj = jsonA.getJSONObject(2);
					            		long intv2 = obj.getLong("intv");
					            		Double p3 = obj.getDouble("intc");
					            		Double o3 = obj.getDouble("into");
					            		Double l3 = obj.getDouble("intl");
					            		
					            		long intvmx = 0;
					            		int ktr = 1;
					            		for(int z=1; z<15; z++) {
					            			obj = jsonA.getJSONObject(z);
					            			if(intvmx < obj.getLong("intv")) {
					            				intvmx = obj.getLong("intv");
					            				ktr = z;
					            			}
					            		}
					            		
					            		if(intv0>0 && intv1>0 && intv2>0 && p1>0.0 && p2>0.0) {
						            		if((intv0 > intvmx*volhike)) {
						            			msg.append(entry.getKey()+":curvol/intvmxOfCandle[-"+ktr+"]="+App.df.format(intv0/(1.01*intvmx))+"%0A");
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
							            		}
						            		}
						            		if((intv0 > (v1*4)) && "1Day-Candle-TEMA-".equals(this.telegramTitle)==false) {
						            			msg.append(entry.getKey()+":curvol/totvol="+App.df.format(intv0/(1.1*v1))+"%0A");
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
							            		}
						            		}
						            		if((intv0 > intv1*1.4) && (intv1 > intv2*1.26)) {
						            			if(p1>p2&&p2>p3&&(o1<p1)&&(o2<p2)&&(o3<p3)) {
						            				msg.append(entry.getKey()+":Down can start.%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
						            			}else if(p1<p2&&p2<p3&&(o1>p1)&&(o2>p2)&&(o3>p3)) {
						            				msg.append(entry.getKey()+":Up can start.%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
						            			}
						            		}
						            		
						            		
						            		if((intv0 > intv1*1.2) && (intv1 > intv2*1.2)) {
						            			if(p1<p2&&p1<l2&&p2<p3&&p2<l3&&(o1>p1)&&(o2>p2)&&(o3>p3)) {
						            				msg.append(entry.getKey()+":Up can start:p1p2p3.%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
						            			}
						            		}
						            		obj = jsonA.getJSONObject(3);
					                		long intv3 = obj.getLong("intv");
					                		Double l4 = obj.getDouble("intl");
					                		Double p4 = obj.getDouble("intc");
						            		Double o4 = obj.getDouble("into");
					                		if((intv1 > intv2*1.2) && (intv2 > intv3*1.2)) {
					                			if(p2<p3&&p2<l3&&p3<p4&&p3<l4&&(o2>p2)&&(o3>p3)&&(o4>p4)) {
					                				msg.append(entry.getKey()+":Up can start:p2p3p4.%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
					                			}
					                		}
						            		obj = jsonA.getJSONObject(4);
					                		long intv4 = obj.getLong("intv");
					                		Double l5 = obj.getDouble("intl");
					                		Double p5 = obj.getDouble("intc");
						            		Double o5 = obj.getDouble("into");
				                    		if((intv4 < intv3) && (intv3 < intv2) && ((intv2 < intv1) || (intv2 > intv1)) && (intv1 < intv0)) {
				                    			if(p1<p2&&p2<p3&&p3<p4&&p4<p5&&(o1>p1)&&(o2>p2)&&(o3>p3)&&(o4>p4)&&(o5>p5)) {
				                    				msg.append(entry.getKey()+":Up can start:p1p2p3p4p5.%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
				                    			}
				                    		}
						            		
						            		
					            		}
					            	}
					            	if(runTemaAlgo) {
							            if("TEMA".equals(algoName)) {				            	
							            	List<Double> clsarr = new ArrayList<>();
							            	List<Double> lowarr = new ArrayList<>();
							            	List<Double> higharr = new ArrayList<>();
							            	for(int i = jsonA.length() -1; i>-1; i--) {
							            		JSONObject obj = jsonA.getJSONObject(i);
							            		clsarr.add(obj.getDouble("intc"));
							            		lowarr.add(obj.getDouble("intl"));
							            		higharr.add(obj.getDouble("inth"));
							            	}
							            	int ln = clsarr.size();
							            	Double clsprc = clsarr.get(ln-1);
							            	
							            	Double mxchk = nameClsPrcMap.getOrDefault(entry.getKey()+"-mx", 0.0);
							            	Double mnchk = nameClsPrcMap.getOrDefault(entry.getKey()+"-mn", 0.0);
							            	if(clsprc <= mxchk && clsprc >= mnchk) {
							            		buf.append(entry.getKey()+":is matching ur price="+clsprc+". pls exit.%0A");
							            	}
							            	
							            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
							            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
							            	higharr = AlgoUtils.calculateEMA(20, higharr);
							            	
							            	ln = clsarr.size();
							            	Double em1cls = clsarr.get(ln-1);
							            	Double em1clsprev = clsarr.get(ln-2);
							            	Double em11clsprev = clsarr.get(ln-3);
							            	Double em111clsprev = clsarr.get(ln-4);
							            	Double em1111clsprev = clsarr.get(ln-5);
							            	Double em11111clsprev = clsarr.get(ln-6);
							            	Double em111111clsprev = clsarr.get(ln-7);
							            	
							            	ln = lowarr.size();
							            	Double em1lwr = lowarr.get(ln-1);
							            	Double em1lwrprev = lowarr.get(ln-2);
							            	Double em11lwrprev = lowarr.get(ln-3);
							            	Double em111lwrprev = lowarr.get(ln-4);
							            	Double em1111lwrprev = lowarr.get(ln-5);
							            	Double em11111lwrprev = lowarr.get(ln-6);
							            	Double em111111lwrprev = lowarr.get(ln-7);
							            	
							            	ln = higharr.size();
							            	Double em1high = higharr.get(ln-1);
							            	Double em1highprev = higharr.get(ln-2);
							            	Double em11highprev = higharr.get(ln-3);
							            	Double em111highprev = higharr.get(ln-4);
							            	Double em1111highprev = higharr.get(ln-5);
							            	Double em11111highprev = higharr.get(ln-6);
							            	Double em111111highprev = higharr.get(ln-7);
							            	
							            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
							            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
							            	higharr = AlgoUtils.calculateEMA(20, higharr);
							            	
							            	ln = clsarr.size();
							            	Double em2cls = clsarr.get(ln-1);
							            	Double em2clsprev = clsarr.get(ln-2);
							            	Double em22clsprev = clsarr.get(ln-3);
							            	Double em222clsprev = clsarr.get(ln-4);
							            	Double em2222clsprev = clsarr.get(ln-5);
							            	Double em22222clsprev = clsarr.get(ln-6);
							            	Double em222222clsprev = clsarr.get(ln-7);
							            	ln = lowarr.size();
							            	Double em2lwr = lowarr.get(ln-1);
							            	Double em2lwrprev = lowarr.get(ln-2);
							            	Double em22lwrprev = lowarr.get(ln-3);
							            	Double em222lwrprev = lowarr.get(ln-4);
							            	Double em2222lwrprev = lowarr.get(ln-5);
							            	Double em22222lwrprev = lowarr.get(ln-6);
							            	Double em222222lwrprev = lowarr.get(ln-7);
							            	ln = higharr.size();
							            	Double em2high = higharr.get(ln-1);
							            	Double em2highprev = higharr.get(ln-2);
							            	Double em22highprev = higharr.get(ln-3);
							            	Double em222highprev = higharr.get(ln-4);
							            	Double em2222highprev = higharr.get(ln-5);
							            	Double em22222highprev = higharr.get(ln-6);
							            	Double em222222highprev = higharr.get(ln-7);
							            	
							            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
							            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
							            	higharr = AlgoUtils.calculateEMA(20, higharr);
							            	
							            	ln = clsarr.size();
							            	Double em3cls = clsarr.get(ln-1);
							            	Double em3clsprev = clsarr.get(ln-2);
							            	Double em33clsprev = clsarr.get(ln-3);
							            	Double em333clsprev = clsarr.get(ln-4);
							            	Double em3333clsprev = clsarr.get(ln-5);
							            	Double em33333clsprev = clsarr.get(ln-6);
							            	Double em333333clsprev = clsarr.get(ln-7);
							            	ln = lowarr.size();
							            	Double em3lwr = lowarr.get(ln-1);
							            	Double em3lwrprev = lowarr.get(ln-2);
							            	Double em33lwrprev = lowarr.get(ln-3);
							            	Double em333lwrprev = lowarr.get(ln-4);
							            	Double em3333lwrprev = lowarr.get(ln-5);
							            	Double em33333lwrprev = lowarr.get(ln-6);
							            	Double em333333lwrprev = lowarr.get(ln-7);
							            	ln = higharr.size();
							            	Double em3high = higharr.get(ln-1);
							            	Double em3highprev = higharr.get(ln-2);
							            	Double em33highprev = higharr.get(ln-3);
							            	Double em333highprev = higharr.get(ln-4);
							            	Double em3333highprev = higharr.get(ln-5);
							            	Double em33333highprev = higharr.get(ln-6);
							            	Double em333333highprev = higharr.get(ln-7);
							            	
							            	Double tema1c = (3*em1cls) - (3*em2cls) + em3cls;
							            	Double tema2c = (3*em1clsprev) - (3*em2clsprev) + em3clsprev;
							            	Double tema3c = (3*em11clsprev) - (3*em22clsprev) + em33clsprev;
							            	Double tema4c = (3*em111clsprev) - (3*em222clsprev) + em333clsprev;
							            	Double tema5c = (3*em1111clsprev) - (3*em2222clsprev) + em3333clsprev;
							            	Double tema6c = (3*em11111clsprev) - (3*em22222clsprev) + em33333clsprev;
							            	Double tema7c = (3*em111111clsprev) - (3*em222222clsprev) + em333333clsprev;
							            	
							            	Double tema1l = (3*em1lwr) - (3*em2lwr) + em3lwr;
							            	Double tema2l = (3*em1lwrprev) - (3*em2lwrprev) + em3lwrprev;
							            	Double tema3l = (3*em11lwrprev) - (3*em22lwrprev) + em33lwrprev;
							            	Double tema4l = (3*em111lwrprev) - (3*em222lwrprev) + em333lwrprev;
							            	Double tema5l = (3*em1111lwrprev) - (3*em2222lwrprev) + em3333lwrprev;
							            	Double tema6l = (3*em11111lwrprev) - (3*em22222lwrprev) + em33333lwrprev;
							            	Double tema7l = (3*em111111lwrprev) - (3*em222222lwrprev) + em333333lwrprev;
							            	
							            	
							            	Double tema1h = (3*em1high) - (3*em2high) + em3high;
							            	Double tema2h = (3*em1highprev) - (3*em2highprev) + em3highprev;
							            	Double tema3h = (3*em11highprev) - (3*em22highprev) + em33highprev;
							            	Double tema4h = (3*em111highprev) - (3*em222highprev) + em333highprev;
							            	Double tema5h = (3*em1111highprev) - (3*em2222highprev) + em3333highprev;
							            	Double tema6h = (3*em11111highprev) - (3*em22222highprev) + em33333highprev;
							            	Double tema7h = (3*em111111highprev) - (3*em222222highprev) + em333333highprev;
							            	
							            	//System.out.println("5tema="+tema1+"="+tema1prev);System.out.println("19tema="+tema2+"="+tema2prev);System.out.println("18tema="+tema3+"="+tema3prev);
							            	Double gapval = 2000.0;
							            	if(cnt < gplnth) {
							            		gapval = clsprc * gap[cnt];
							            	}else {
							            		gapval = clsprc * gap[gplnth-1];
							            	}
							            	//System.out.println(entry.getKey()+"-->"+tema1c +"="+ tema1l +","+ tema2c +"="+ tema2l +","+ tema3c +"="+tema3l+","+tema4c +"="+ tema4l +","+ tema5c +"="+ tema5l +","+ tema6c +"="+ tema6l +","+ tema7c +"="+ tema7l);
							            	if(tema1c < tema1l && tema2c < tema2l && tema3c < tema3l && tema4c < tema4l && tema5c < tema5l && tema6c < tema6l && tema7c < tema7l) {
							            		//System.out.println(entry.getKey()+"-******->");
							            		if(tema2c < tema2l && tema1c > tema2c && tema1c > tema1l) {
								            		buf.append(entry.getKey()+":BULLISH-L:"+App.df1.format(clsprc)+"%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
								            		}
								            	}
							            	}else if(tema1c < tema1h && tema2c < tema2h && tema3c < tema3h && tema4c < tema4h && tema5c < tema5h && tema6c < tema6h && tema7c < tema7h) {
							            		//System.out.println(entry.getKey()+"-******hhh->");
							            		if(tema2c < tema2h && tema1c > tema2c && tema1c > tema1h) {
								            		buf.append(entry.getKey()+":BULLISH:"+App.df1.format(clsprc)+"%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
								            		}
								            	}
							            	}else if(tema1c > tema1l && tema2c > tema2l && tema3c > tema3l && tema4c > tema4l && tema5c > tema5l && tema6c > tema6l && tema7c > tema7l) {
							            		if((tema2c > tema2l && tema1c < tema2c && tema1c < tema1l)) {
								            		buf.append(entry.getKey()+":BEARISH:"+App.df1.format(clsprc)+"%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
								            		}
								            	}
							            	}else if(tema1c > tema1h && tema2c > tema2h && tema3c > tema3h && tema4c > tema4h && tema5c > tema5h && tema6c > tema6h && tema7c > tema7h) {
							            		if((tema2c > tema2h && tema1c < tema2c && tema2c < tema3c && tema1c < tema1h)) {
								            		buf.append(entry.getKey()+":BEARISH-H:"+App.df1.format(clsprc)+"%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
								            		}
								            	}
							            	}else {
							            		if(gapval > 0 && (tema1l-tema1c) > gapval) {
								            		buf.append(entry.getKey()+":BULLISH-Candlegap="+App.df2.format((tema1l-tema1c)/tema1c)+":"+App.df1.format(clsprc)+"%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
								            	}
							            		if(gapval > 0 && (tema1c-tema1h) > gapval) {
								            		buf.append(entry.getKey()+":BEARISH-Candlegap="+App.df2.format((tema1c-tema1h)/tema1h)+":"+App.df1.format(clsprc)+"%0A");
								            		if(this.codeTokenMapForLowerTimeCandle != null) {
								            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
								            		}
								            	}
							            	}
							            	/*
							            	if(tema2c < tema2l && tema1c > tema2c && tema1c > tema1l) {
							            		buf.append(entry.getKey()+":BULLISH-L:"+App.df1.format(clsprc)+"%0A");
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
							            		}
							            	}else if(tema2c < tema2h && tema1c > tema2c && tema1c > tema1h) {
							            		buf.append(entry.getKey()+":BULLISH:"+App.df1.format(clsprc)+"%0A");
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
							            		}
							            	}else if(gapval > 0 && (tema1l-tema1c) > gapval) {
							            		buf.append(entry.getKey()+":BULLISH-Candlegap="+App.df2.format((tema1l-tema1c)/tema1c)+":"+App.df1.format(clsprc)+"%0A");
							            		//check lower time candle now
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
							            		}
							            	}else if((tema2c > tema2h && tema1c < tema2c && tema2c < tema3c && tema1c < tema1h)) {
							            		buf.append(entry.getKey()+":BEARISH-H:"+App.df1.format(clsprc)+"%0A");
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
							            		}
							            	}else if((tema2c > tema2l && tema1c < tema2c && tema1c < tema1l)) {
							            		buf.append(entry.getKey()+":BEARISH:"+App.df1.format(clsprc)+"%0A");
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.remove(entry.getKey());
							            		}
							            	}else if(gapval > 0 && (tema1c-tema1h) > gapval) {
							            		buf.append(entry.getKey()+":BEARISH-Candlegap="+App.df2.format((tema1c-tema1h)/tema1h)+":"+App.df1.format(clsprc)+"%0A");
							            		//check lower time candle now
							            		if(this.codeTokenMapForLowerTimeCandle != null) {
							            			this.codeTokenMapForLowerTimeCandle.put(entry.getKey(), entry.getValue());
							            		}
							            	}
							            	*/
							            	//System.out.println(temaCandle);Thread.sleep(10000);
							            	
							            	
							            	//--------------------------TeMA type algo------------------------
							            	if("1Day-Candle-TEMA-".equals(this.telegramTitle)) {
							            		temaNewAlgo(jsonA, temaCandleBuffer, entry.getKey());
							            		calculateRSIDivergence(jsonA, rsiBuffer, entry.getKey());
							            	}
							            	
							            	//----------------------Tema type algo end
							            	
							            	
							            	
							            	
							            }
					            	}
								} catch (Exception e) {
									logger.error("Issuue*******", e);
								}
								cnt = cnt + 1;
								endTimeInSec = Calendar.getInstance().getTimeInMillis()/1000;
							}
							//logger.info(temaCandle+"=algocalculator----->"+buf+"*******************************************************------>"+msg);
							try {
								if(temaCandleBuffer.length() > 70)
									TelegramUtil.sendTelegramMsg(temaCandleBuffer.toString(), telegramchanelId, false);
								if(buf.length()>3) {
									TelegramUtil.sendTelegramMsg(temaCandle+buf.toString(), telegramchanelId, false);
								}if(msg.length()>32)
									TelegramUtil.sendTelegramMsg(temaCandle+msg.toString(), telegramchanelId, false);
								if(rsiBuffer.length()>3)
									TelegramUtil.sendTelegramMsg(temaCandle+msg.toString(), telegramchanelId, false);
					    	}catch(Exception ix) {
					    		logger.error("---->", ix);
							}
					}
				}
			}
		}catch(Throwable t) {
			logger.error("**************", t);
		}
	}
	
	private void calculateRSIDivergence(JSONArray jsonA, StringBuffer rsiBuffer, String stockname) {
		try {
			List<Integer> rsiarr = new ArrayList<Integer>();
			List<Double> prcarr = new ArrayList<Double>();
			
			int rsiDays = 16;
			int ix = 2*rsiDays;
			ix = ix + 2;
			List<Double> clsarr = new ArrayList<Double>();
			for(int i=ix; i >= 0; i--) {
        		JSONObject obj = jsonA.getJSONObject(i);
        		Double ltp = obj.getDouble("intc");
        		clsarr.add(ltp);
        		//System.out.println("--------------------------------------------");
        		//System.out.print(obj.getString("time")+"="+obj.getDouble("into")+"/"+ltp+"/"+obj.getDouble("inth"));
			}
			
            Double avgU = 0.0;
            Double avgD = 0.0;
			Double prevCls = clsarr.get(0);
			int daycount = 1;
			for(int z=1; z<clsarr.size(); z++) {
				Double ltp = clsarr.get(z);
				if(daycount < rsiDays) {
	        		if((ltp-prevCls) > 0 ) {
	                    avgU = avgU + (ltp-prevCls);
	                }else {
	                    avgD = avgD + (prevCls-ltp);
	                }
				}
                if(daycount == rsiDays) {
                    avgU = avgU/rsiDays;
                    avgD = avgD/rsiDays;
                    rsiarr.add((int)(100-(100/(1+(avgU/avgD)))));
                    prcarr.add(ltp);
                }
                if(daycount > rsiDays) {
                    if((ltp-prevCls) > 0 ) {
                        avgU = ((avgU*(rsiDays-1)) + (ltp-prevCls))/rsiDays;
                        avgD = ((avgD*(rsiDays-1)) + 0)/rsiDays;
                    }else {
                        avgU = ((avgU*(rsiDays-1)) + 0)/rsiDays;
                        avgD = ((avgD*(rsiDays-1)) + (prevCls-ltp))/rsiDays;
                    }
                    rsiarr.add((int)(100-(100/(1+(avgU/avgD)))));
                    prcarr.add(ltp);
                }
                daycount++;
                prevCls = ltp;
			}
			
			int rsz = rsiarr.size();
			int rsi = rsiarr.get(rsz-1);
			Double ltp = prcarr.get(rsz-1);
			if(rsi < 30) {
				Double prclwr = 0.0;
				int rsilwr = 100;
				int bfr = 0;
				boolean isrsidiv = true;
				for(int i=rsz-12; i<rsz-1; i++) {
					int rsiprv = rsiarr.get(i);
					if(rsiprv > 65) {
						isrsidiv = false;
						break;
					}
					if(rsiprv < rsilwr) {
						rsilwr = rsiprv;
						prclwr = prcarr.get(i);
						bfr = i;
					}
				}
				if(isrsidiv == true) {
					if(rsi > rsilwr && ltp < prclwr) {
						rsiBuffer.append(stockname+":rsi:"+rsi+",bull-div:"+bfr+"%0A");
					}
				}
			}else if(rsi > 78) {
				Double prclwr = 0.0;
				int rsilwr = 0;
				int bfr = 0;
				boolean isrsidiv = true;
				for(int i=rsz-12; i<rsz-1; i++) {
					int rsiprv = rsiarr.get(i);
					if(rsiprv < 45) {
						isrsidiv = false;
						break;
					}
					if(rsiprv > rsilwr) {
						rsilwr = rsiprv;
						prclwr = prcarr.get(i);
						bfr = i;
					}
				}
				if(isrsidiv == true) {
					if(rsi > rsilwr && ltp < prclwr) {
						rsiBuffer.append(stockname+":rsi:"+rsi+",bear-div:"+bfr+"%0A");
					}
				}
			}
			if(rsi < 22 || rsi > 84) {
				rsiBuffer.append(stockname+":rsi:"+rsi+"%0A");
			}
			}catch(Exception px) {
			logger.error("*****====*********", px);
		}
	}
	
	private void temaNewAlgo(JSONArray jsonA, StringBuffer temaCandleBuffer, String stockname) {
		try {
			JSONObject obj = jsonA.getJSONObject(1);
			Double p1 = obj.getDouble("intc");
			Double o1 = obj.getDouble("into");
			JSONObject obj2 = jsonA.getJSONObject(2);
			Double p2 = obj2.getDouble("intc");
			Double o2 = obj2.getDouble("into");
			JSONObject obj3 = jsonA.getJSONObject(3);
			Double p3 = obj3.getDouble("intc");
			Double o3 = obj3.getDouble("into");
			
			JSONObject obj4 = jsonA.getJSONObject(4);
			Double p4 = obj4.getDouble("intc");
			Double o4 = obj4.getDouble("into");
			
			JSONObject obj5 = jsonA.getJSONObject(5);
			Double p5 = obj5.getDouble("intc");
			Double o5 = obj5.getDouble("into");
			if((p1<p2&&p2<p3&&(o1>p1)&&(o2>p2)&&(o3>p3)) || (p1<p2&&p2<o3&&p3<p4&&p4<p5&&(o1>p1)&&(p2>o2)&&(o3>p3)&&(o4>p4)&&(o5>p5))) {
				List<Double> clsarr = new ArrayList<>();
	        	List<Double> lowarr = new ArrayList<>();
	        	List<Double> clsarr1 = new ArrayList<>();
	        	for(int i = jsonA.length() -1; i>-1; i--) {
	        		obj = jsonA.getJSONObject(i);
	        		Double cl = obj.getDouble("intc");
	        		clsarr.add(cl);
	        		lowarr.add(obj.getDouble("intl"));
	        		clsarr1.add(cl);
	        	}
	        	int ln = clsarr.size();
	        	Double clsprc = clsarr.get(ln-1);								            	
	        	clsarr = AlgoUtils.calculateEMA(4, clsarr);
	        	lowarr = AlgoUtils.calculateEMA(22, lowarr);
	        	clsarr1 = AlgoUtils.calculateEMA(11, clsarr1);
	        		ln = clsarr.size();
	            	Double em1cls = clsarr.get(ln-1);
	            	Double em1clsprev = clsarr.get(ln-2);
	            	Double em11clsprev = clsarr.get(ln-3);
	            	ln = lowarr.size();
	            	Double em1lwr = lowarr.get(ln-1);
	            	Double em1lwrprev = lowarr.get(ln-2);
	            	ln = clsarr1.size();
	            	Double em1high = clsarr1.get(ln-1);
	            	Double em1highprev = clsarr1.get(ln-2);
	            	
	            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
	            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
	            	clsarr1 = AlgoUtils.calculateEMA(11, clsarr1);
	            	
	            	ln = clsarr.size();
	            	Double em2cls = clsarr.get(ln-1);
	            	Double em2clsprev = clsarr.get(ln-2);
	            	Double em22clsprev = clsarr.get(ln-3);
	            	ln = lowarr.size();
	            	Double em2lwr = lowarr.get(ln-1);
	            	Double em2lwrprev = lowarr.get(ln-2);
	            	ln = clsarr1.size();
	            	Double em2high = clsarr1.get(ln-1);
	            	Double em2highprev = clsarr1.get(ln-2);
	            	
	            	clsarr = AlgoUtils.calculateEMA(4, clsarr);
	            	lowarr = AlgoUtils.calculateEMA(22, lowarr);
	            	clsarr1 = AlgoUtils.calculateEMA(11, clsarr1);
	            	
	            	ln = clsarr.size();
	            	Double em3cls = clsarr.get(ln-1);
	            	Double em3clsprev = clsarr.get(ln-2);
	            	Double em33clsprev = clsarr.get(ln-3);
	            	ln = lowarr.size();
	            	Double em3lwr = lowarr.get(ln-1);
	            	Double em3lwrprev = lowarr.get(ln-2);
	            	ln = clsarr1.size();
	            	Double em3high = clsarr1.get(ln-1);
	            	Double em3highprev = clsarr1.get(ln-2);
	            	
	            	Double tema1 = (3*em1cls) - (3*em2cls) + em3cls;
	            	Double tema1prev = (3*em1clsprev) - (3*em2clsprev) + em3clsprev;
	            	Double tema11prev = (3*em11clsprev) - (3*em22clsprev) + em33clsprev;
	            	Double tema2 = (3*em1lwr) - (3*em2lwr) + em3lwr;
	            	Double tema2prev = (3*em1lwrprev) - (3*em2lwrprev) + em3lwrprev;
	            	Double tema3 = (3*em1high) - (3*em2high) + em3high;
	            	Double tema3prev = (3*em1highprev) - (3*em2highprev) + em3highprev;
	            	
	            	if(tema1prev < tema2prev && tema1 > tema1prev && tema1 > tema2) {
	            		temaCandleBuffer.append(stockname+":BULLISH-4c22l:"+App.df1.format(clsprc)+"%0A");
	            	}else if(tema1prev < tema3prev && tema1 > tema1prev && tema1 > tema3) {
	            		temaCandleBuffer.append(stockname+":BULLISH-4c11c:"+App.df1.format(clsprc)+"%0A");
	            	}
			}
		}catch(Exception px) {
			logger.error("*****====*********", px);
		}
	}

}
