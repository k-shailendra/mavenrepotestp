package com.sharemarket.shailendra;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import com.sharemarket.shailendra.App;
import com.sharemarket.shailendra.OrderDetailNew;
import com.sharemarket.shailendra.StockMarketUtil;
import com.sharemarket.shailendra.utils.TelegramUtil;

public class StopLossTriggerWorker extends SwingWorker {
	final static MediaType mediaType_JSON = MediaType.parse("application/json; charset=utf-8");
	private JTextField txtNoOfLotStpLs;
	JTextField txtBxTargetProfit;
	JTextField txtBxStopLs;
	private String loginToken;
    private String scripToken;
    private Integer qtyIn1LotIdValue = 50;
    
    private Double targetProfitValue = 1000000.0;
    Double targetStpLsValue = 0.0000;
	Double targetStpLsUpByValue = 0.8;
	Integer noOfLot2SaleAtPftValue = 1;
	Integer noOfLot2SaleAtStplsValue = 0;
	int waittime = -1;
	long orderpicktime;
    
	public StopLossTriggerWorker(String scripTokenVal, String loginToken, Integer qtyIn1LotIdValueData, JTextField txtNoOfLotStpLs, JTextField txtStopLs, JTextField txtTargetProfit, Double targetProfitVal, Double targetStpLsVal, Double targetStpLsUpByVal, Integer noOfLot2SaleAtPftVal, Integer noOfLot2SaleAtStplsVal, long orderpicktime, int waitimeinsec) {
		this.loginToken = loginToken;
        scripToken = scripTokenVal;
        qtyIn1LotIdValue = qtyIn1LotIdValueData;
        this.txtNoOfLotStpLs = txtNoOfLotStpLs;
        this.txtBxTargetProfit = txtTargetProfit;
        this.txtBxStopLs = txtStopLs;
		
		targetProfitValue = targetProfitVal;
		targetStpLsValue = targetStpLsVal;
		targetStpLsUpByValue = targetStpLsUpByVal;
		noOfLot2SaleAtPftValue = noOfLot2SaleAtPftVal;
		noOfLot2SaleAtStplsValue = noOfLot2SaleAtStplsVal;
    	this.waittime = waitimeinsec * 1000;
    	this.orderpicktime = orderpicktime;
    }

	@Override
	protected Object doInBackground() throws Exception {
		int cnt = 0;
        OkHttpClient client4prc = new OkHttpClient.Builder().hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        }).connectTimeout(2, TimeUnit.SECONDS)
                .readTimeout(2, TimeUnit.SECONDS)
                .writeTimeout(2, TimeUnit.SECONDS)
                .build();
        RequestBody body = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"token\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
        okhttp3.Request.Builder reqBuilder = new Request.Builder()
                .url("https://api.shoonya.com/NorenWClientTP/GetQuotes").addHeader("Content-Type", "application/json");
        
        while(isCancelled() == false && cnt<54000) {
        	String ltp = "";
        	try {
                Request postRequest = reqBuilder.method("POST", body).build();
                Response response = client4prc.newCall(postRequest).execute();
                JSONObject json = new JSONObject(response.body().string());
                ltp = json.getString("lp");
                Double curValue = Double.valueOf(ltp);
                //System.out.println(curValue+"<>"+targetStpLsValue+","+noOfLot2SaleAtStplsValue+"="+stplsPriceStartPointValueNow);
                if(curValue > 1 && noOfLot2SaleAtStplsValue > 0) {
                	//System.out.println(curValue+"=curValue<-->*stopLoss1stTriggerPrcValueLocal="+stopLoss1stTriggerPrcValueLocal);
                    int updateUiFields = 0;
                    if(curValue <= targetStpLsValue) {
                        //place market order sale
                    	int quantity = StockMarketUtil.loadPositionBook(scripToken);
                		if(quantity < 1)
                			quantity = noOfLot2SaleAtStplsValue * qtyIn1LotIdValue;
                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+quantity+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
                        Request postRequest4sale = new Request.Builder()
                                .url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
                                .method("POST", body4sale)
                                .addHeader("Content-Type", "application/json").build();
                        client4prc.newCall(postRequest4sale).execute();
                        targetStpLsValue = -10.0;
                        targetProfitValue = 1000000.0;
                    	targetStpLsUpByValue = 0.4;
                    	noOfLot2SaleAtPftValue = 1;
                    	noOfLot2SaleAtStplsValue = 0;
                        updateUiFields = -1;
                    }else if(curValue >= targetProfitValue && noOfLot2SaleAtStplsValue > 0) {
                        //place market order sale
                        int quantity = noOfLot2SaleAtPftValue * qtyIn1LotIdValue;
                        RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+quantity+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
                        Request postRequest4sale = new Request.Builder()
                                .url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
                                .method("POST", body4sale)
                                .addHeader("Content-Type", "application/json").build();
                        client4prc.newCall(postRequest4sale).execute();
                        noOfLot2SaleAtStplsValue = noOfLot2SaleAtStplsValue - noOfLot2SaleAtPftValue;
                        targetProfitValue = curValue + targetStpLsUpByValue;
                        updateUiFields = 5;
                    }
                  //checkwait time and cancel rest order
                	if(this.waittime > -1) {
                		if((System.currentTimeMillis() - orderpicktime) > this.waittime) {
	                		StockMarketUtil.cancelAllOrder(StockMarketUtil.getorderbookOrderNumber("B", scripToken));
	                		int qty = StockMarketUtil.loadPositionBook(scripToken);
	                		if(qty == this.noOfLot2SaleAtStplsValue) {
	                			this.targetProfitValue = (this.targetStpLsValue + this.targetProfitValue) / 2;
	                		}else {
	                			if(qty > -1) {
		                			this.targetStpLsValue = curValue - this.targetStpLsUpByValue;
		                			this.noOfLot2SaleAtStplsValue = qty;
	                			}
	                		}
	                		this.waittime = -2;
	                		for(int i=0; i<15; i++) {
	                			App.localOrderArr[i] = null;
	                		}
	                		updateUiFields = 5;
	                        JOptionPane.showMessageDialog(null, "Wait time over!!!");
	                		//load cancel orders//load position
                		}else {
                			if(curValue > (this.targetProfitValue)) {
	                			int qty = StockMarketUtil.loadPositionBook(scripToken);
	                			if(qty > 0) {
	                				//sell at market
	                				RequestBody body4sale = RequestBody.create("jData={\r\n\"uid\":\"FA66519\",\r\n\"actid\":\"FA66519\",\r\n\"exch\":\"NFO\",\r\n\"prctyp\":\"MKT\",\n" +
	    	                                "\"prc\":\"0\",\r\n\"ret\":\"DAY\",\r\n\"prd\":\"M\",\r\n\"qty\":\""+qty+"\",\r\n\"trantype\":\"S\",\r\n\"tsym\":\""+scripToken+"\"\r\n}&jKey="+loginToken, mediaType_JSON);
	    	                        Request postRequest4sale = new Request.Builder()
	    	                                .url("https://api.shoonya.com/NorenWClientTP/PlaceOrder")
	    	                                .method("POST", body4sale)
	    	                                .addHeader("Content-Type", "application/json").build();
	    	                        App.client.newCall(postRequest4sale).execute();
	    	                        this.noOfLot2SaleAtStplsValue = this.noOfLot2SaleAtStplsValue - qty;
	    	                        updateUiFields = 5;
	                			}
	                			System.out.println(qty+"--->wttime"+this.targetProfitValue+"-->"+this.targetStpLsValue);
                			}
                		}
                	}
                	if(this.waittime == -2 && this.noOfLot2SaleAtStplsValue > 0) {
                		Double tmp = curValue - this.targetStpLsUpByValue;
                        if(tmp > this.targetStpLsValue) {
                        	this.targetStpLsValue = tmp;
                        	System.out.println("----------------==>"+this.targetStpLsValue);
                        }
                        if(curValue >= this.targetProfitValue) {
                        	this.targetStpLsUpByValue = this.targetStpLsUpByValue - (curValue*.008);
                        	if(this.targetStpLsUpByValue < 0.40) {
                        		this.targetStpLsUpByValue = 0.40;
                        	}
                        	this.targetProfitValue = curValue + this.targetStpLsUpByValue;
                        	updateUiFields = 5;
                        	System.out.println("--->****"+this.targetProfitValue+"-->"+this.targetStpLsValue);
                        }
                	}

                    if(updateUiFields > 0 || updateUiFields == -1) {
                    	javax.swing.SwingUtilities.invokeLater(new Runnable() {
            		        public void run() {
            		        	String stpVal = targetStpLsValue+"";
            		        	stpVal = stpVal.length() > 5 ? stpVal.substring(0, 5) : stpVal;
                            	txtBxStopLs.setText(stpVal);
                            	String stpTVal = targetProfitValue+"";
                            	stpTVal = stpTVal.length() > 5 ? stpTVal.substring(0, 5) : stpTVal;
                            	txtBxTargetProfit.setText(stpTVal);
                            	txtNoOfLotStpLs.setText(noOfLot2SaleAtStplsValue+"");
            		        }
            		    });
                    }
                }else {
                	break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
			cnt = cnt + 1;
        	if(cnt%30 ==0 || cnt%52==0) { //if(curval <= stoplossforpositionload && this.totqty > 0) {
        		int qty = StockMarketUtil.loadPositionBook(scripToken);
        		if(qty > -1) {
        			this.noOfLot2SaleAtStplsValue = qty;
        		}
        	}
		}
		return null;
	}

}
