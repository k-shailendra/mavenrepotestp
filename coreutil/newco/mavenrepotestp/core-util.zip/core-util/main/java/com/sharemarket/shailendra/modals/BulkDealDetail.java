package com.sharemarket.shailendra.modals;

import java.util.Date;

public class BulkDealDetail {
	private Date dt;
    private String dtD;
    private String nsecode;
    private String sector;
    private String fpiclientname;
    private Integer fpinetbqty=0;
    private Integer fpinetsqty=0;
    private Double fpiavgbval=0.0;
    private Double fpiavgsval=0.0;
    
    private Integer qty=0;
    private String exchange;
    private String buyorsale;
    private String clienttype;   //f-fpi,s-special,o-other,sf-specialfpi
	public Date getDt() {
		return dt;
	}
	public void setDt(Date dt) {
		this.dt = dt;
	}
	public String getDtD() {
		return dtD;
	}
	public void setDtD(String dtD) {
		this.dtD = dtD;
	}
	public String getNsecode() {
		return nsecode;
	}
	public void setNsecode(String nsecode) {
		this.nsecode = nsecode;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getFpiclientname() {
		return fpiclientname;
	}
	public void setFpiclientname(String fpiclientname) {
		this.fpiclientname = fpiclientname;
	}
	public Integer getFpinetbqty() {
		return fpinetbqty;
	}
	public void setFpinetbqty(Integer fpinetbqty) {
		this.fpinetbqty = fpinetbqty;
	}
	public Integer getFpinetsqty() {
		return fpinetsqty;
	}
	public void setFpinetsqty(Integer fpinetsqty) {
		this.fpinetsqty = fpinetsqty;
	}
	public Double getFpiavgbval() {
		return fpiavgbval;
	}
	public void setFpiavgbval(Double fpiavgbval) {
		this.fpiavgbval = fpiavgbval;
	}
	public Double getFpiavgsval() {
		return fpiavgsval;
	}
	public void setFpiavgsval(Double fpiavgsval) {
		this.fpiavgsval = fpiavgsval;
	}
	public Integer getQty() {
		return qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public String getExchange() {
		return exchange;
	}
	public void setExchange(String exchange) {
		this.exchange = exchange;
	}
	public String getBuyorsale() {
		return buyorsale;
	}
	public void setBuyorsale(String buyorsale) {
		this.buyorsale = buyorsale;
	}
	public String getClienttype() {
		return clienttype;
	}
	public void setClienttype(String clienttype) {
		this.clienttype = clienttype;
	}
    
    
}
