package com.sharemarket.shailendra;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class RepositoryClass {
	
	public static final Map<String, String> finvasiaTokenMap3Min = new HashMap<String, String>();
	public static final Map<String, String> finvasiaTokenMap15Min = new HashMap<String, String>();
	public static final Properties moneycontrolTokenProperties15Min = new Properties();
	public static final Map<String, String> myScripsToFinvasiaTokenMap = new HashMap<String, String>();
	
	//public static String TPSeries = "https://shoonyatrade.finvasia.com/NorenWClientTP/TPSeries";
	public static String TPSeries = "https://api.shoonya.com/NorenWClientTP/TPSeries";
	//public static String searchScrip ="https://shoonyatrade.finvasia.com/NorenWClientTP/SearchScrip";
	public static String searchScrip ="https://api.shoonya.com/NorenWClientTP/SearchScrip";
	
	//public static String placeOrder = "https://shoonyatrade.finvasia.com/NorenWClientTP/PlaceOrder";
	public static String placeOrder = "https://api.shoonya.com/NorenWClientTP/PlaceOrder";
	
	//public static String positionbook = "https://shoonyatrade.finvasia.com/NorenWClientTP/PositionBook";
	public static String positionbook = "https://api.shoonya.com/NorenWClientTP/PositionBook";
	
	//public static String orderbook = "https://shoonyatrade.finvasia.com/NorenWClientTP/OrderBook";
	public static String orderbook = "https://api.shoonya.com/NorenWClientTP/OrderBook";
	
	//public static String cancelorder = "https://shoonyatrade.finvasia.com/NorenWClientTP/CancelOrder";
	public static String cancelorder = "https://api.shoonya.com/NorenWClientTP/CancelOrder";
}
